# File saved with Nlview 7.8.0 2024-04-26 e1825d835c VDI=44 GEI=38 GUI=JA:21.0 threadsafe
# 
# non-default properties - (restore without -noprops)
property -colorscheme classic
property attrcolor #000000
property attrfontsize 8
property autobundle 1
property backgroundcolor #ffffff
property boxcolor0 #000000
property boxcolor1 #000000
property boxcolor2 #000000
property boxinstcolor #000000
property boxpincolor #000000
property buscolor #008000
property closeenough 5
property createnetattrdsp 2048
property decorate 1
property elidetext 40
property fillcolor1 #ffffcc
property fillcolor2 #dfebf8
property fillcolor3 #f0f0f0
property gatecellname 2
property instattrmax 30
property instdrag 15
property instorder 1
property marksize 12
property maxfontsize 15
property maxzoom 6.25
property netcolor #19b400
property objecthighlight0 #ff00ff
property objecthighlight1 #ffff00
property objecthighlight2 #00ff00
property objecthighlight3 #0095ff
property objecthighlight4 #8000ff
property objecthighlight5 #ffc800
property objecthighlight7 #00ffff
property objecthighlight8 #ff00ff
property objecthighlight9 #ccccff
property objecthighlight10 #0ead00
property objecthighlight11 #cefc00
property objecthighlight12 #9e2dbe
property objecthighlight13 #ba6a29
property objecthighlight14 #fc0188
property objecthighlight15 #02f990
property objecthighlight16 #f1b0fb
property objecthighlight17 #fec004
property objecthighlight18 #149bff
property objecthighlight19 #0000ff
property overlaycolor #19b400
property pbuscolor #000000
property pbusnamecolor #000000
property pinattrmax 20
property pinorder 2
property pinpermute 0
property portcolor #000000
property portnamecolor #000000
property ripindexfontsize 4
property rippercolor #000000
property rubberbandcolor #000000
property rubberbandfontsize 15
property selectattr 0
property selectionappearance 2
property selectioncolor #0000ff
property sheetheight 44
property sheetwidth 68
property showmarks 1
property shownetname 0
property showpagenumbers 1
property showripindex 1
property timelimit 1
#
module new riscv work:riscv:NOFILE -nosplit
load symbol alu work:alu:NOFILE HIERBOX pin E output.right pin GT output.right pin overflow output.right pin sign output.right pinBus A input.left [31:0] pinBus B input.left [31:0] pinBus aluSignals input.left [4:0] pinBus result output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol branchunit work:branchunit:NOFILE HIERBOX pin E input.left pin GT input.left pin clk input.left pin isBeq input.left pin isBgt input.left pin isBranchTaken output.right pin isUBranch input.left pin reset input.left boxcolor 1 fillcolor 2 minwidth 13%
load symbol addrmux work:abstract:NOFILE HIERBOX pin s0 input.left pinBus i0 input.left [31:0] pinBus i1 input.left [31:0] pinBus o output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol controlunit work:controlunit:NOFILE HIERBOX pin clk input.left pin isBeq output.right pin isBgt output.right pin isCall output.right pin isLd output.right pin isRet output.right pin isSt output.right pin isUBranch output.right pin isWb output.right pin reset input.left pinBus opcode input.left [4:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol datamemory work:datamemory:NOFILE HIERBOX pin MemRead input.left pin MemWrite input.left pin clk input.left pin reset input.left pinBus MemData_out output.right [31:0] pinBus Write_data input.left [31:0] pinBus read_address input.left [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol flagregister work:flagregister:NOFILE HIERBOX pin E output.right pin E_in input.left pin GT output.right pin GT_in input.left pin clk input.left pin overflow output.right pin overflow_in input.left pin reset input.left pin sign output.right pin sign_in input.left boxcolor 1 fillcolor 2 minwidth 13%
load symbol immediatebranch work:immediatebranch:NOFILE HIERBOX pinBus addrout input.left [31:0] pinBus branchtarget output.right [31:0] pinBus immx output.right [31:0] pinBus instruction input.left [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol instructionfetch work:instructionfetch:NOFILE HIERBOX pin clk input.left pin isImmediate output.right pin reset input.left pinBus immediate output.right [17:0] pinBus instruction input.left [31:0] pinBus opcode output.right [4:0] pinBus ra output.right [3:0] pinBus rd output.right [3:0] pinBus rs1 output.right [3:0] pinBus rs2 output.right [3:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol instructionmemory work:instructionmemory:NOFILE HIERBOX pin clk input.left pin reset input.left pinBus addrout input.left [31:0] pinBus instruction output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol memoryunit work:memoryunit:NOFILE HIERBOX pin MemRead output.right pin MemWrite output.right pin clk input.left pin isLd input.left pin isSt input.left pin reset input.left pinBus address output.right [31:0] pinBus ldResult output.right [31:0] pinBus mar output.right [31:0] pinBus mdr output.right [31:0] pinBus memData input.left [31:0] pinBus op2 input.left [31:0] pinBus result input.left [31:0] pinBus writeData output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol regmux work:regmux:NOFILE HIERBOX pin s0 input.left pinBus i0 input.left [3:0] pinBus i1 input.left [3:0] pinBus o output.right [3:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol regmux work:abstract:NOFILE HIERBOX pin s0 input.left pinBus i0 input.left [3:0] pinBus i1 input.left [3:0] pinBus o output.right [3:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol mux4to1 work:mux4to1:NOFILE HIERBOX pin s0 input.left pin s1 input.left pinBus i0 input.left [31:0] pinBus i1 input.left [31:0] pinBus i2 input.left [31:0] pinBus o output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol pc work:pc:NOFILE HIERBOX pin clk input.left pin reset input.left pinBus addrin input.left [31:0] pinBus addrout output.right [31:0] pinBus pcplus4 output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol addrmux work:addrmux:NOFILE HIERBOX pin s0 input.left pinBus i0 input.left [31:0] pinBus i1 input.left [31:0] pinBus o output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol registerfile work:registerfile:NOFILE HIERBOX pin clk input.left pin isWb input.left pin reset input.left pinBus mux1 input.left [3:0] pinBus mux2 input.left [3:0] pinBus mux3 input.left [3:0] pinBus op1 output.right [31:0] pinBus op2 output.right [31:0] pinBus writedata input.left [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load port clk input -pg 1 -lvl 0 -x 0 -y 370
load port reset input -pg 1 -lvl 0 -x 0 -y 510
load inst ALU alu work:alu:NOFILE -autohide -attr @cell(#000000) alu -pinBusAttr A @name A[31:0] -pinBusAttr B @name B[31:0] -pinBusAttr aluSignals @name aluSignals[4:0] -pinBusAttr result @name result[31:0] -pg 1 -lvl 11 -x 3880 -y 600
load inst BRANCHUNIT branchunit work:branchunit:NOFILE -autohide -attr @cell(#000000) branchunit -pg 1 -lvl 2 -x 590 -y 400
load inst BRMUX addrmux work:abstract:NOFILE -autohide -attr @cell(#000000) addrmux -pinBusAttr i0 @name i0[31:0] -pinBusAttr i1 @name i1[31:0] -pinBusAttr o @name o[31:0] -pg 1 -lvl 2 -x 590 -y 860
load inst CONTROLUNIT controlunit work:controlunit:NOFILE -autohide -attr @cell(#000000) controlunit -pinBusAttr opcode @name opcode[4:0] -pg 1 -lvl 7 -x 2270 -y 400
load inst DATAMEMORY datamemory work:datamemory:NOFILE -autohide -attr @cell(#000000) datamemory -pinBusAttr MemData_out @name MemData_out[31:0] -pinBusAttr Write_data @name Write_data[31:0] -pinBusAttr read_address @name read_address[31:0] -pg 1 -lvl 7 -x 2270 -y 80
load inst FLAGREGISTER flagregister work:flagregister:NOFILE -autohide -attr @cell(#000000) flagregister -pinAttr overflow @attr n/c -pinAttr sign @attr n/c -pg 1 -lvl 1 -x 180 -y 420
load inst IMMEDIATEBRANCH immediatebranch work:immediatebranch:NOFILE -autohide -attr @cell(#000000) immediatebranch -pinBusAttr addrout @name addrout[31:0] -pinBusAttr branchtarget @name branchtarget[31:0] -pinBusAttr immx @name immx[31:0] -pinBusAttr instruction @name instruction[31:0] -pg 1 -lvl 1 -x 180 -y 960
load inst IMMUX addrmux work:abstract:NOFILE -autohide -attr @cell(#000000) addrmux -pinBusAttr i0 @name i0[31:0] -pinBusAttr i1 @name i1[31:0] -pinBusAttr o @name o[31:0] -pg 1 -lvl 10 -x 3560 -y 880
load inst INSTRUCTIONFETCH instructionfetch work:instructionfetch:NOFILE -autohide -attr @cell(#000000) instructionfetch -pinBusAttr immediate @name immediate[17:0] -pinBusAttr immediate @attr n/c -pinBusAttr instruction @name instruction[31:0] -pinBusAttr opcode @name opcode[4:0] -pinBusAttr ra @name ra[3:0] -pinBusAttr rd @name rd[3:0] -pinBusAttr rs1 @name rs1[3:0] -pinBusAttr rs2 @name rs2[3:0] -pg 1 -lvl 6 -x 1870 -y 820
load inst INSTRUCTIONMEMORY instructionmemory work:instructionmemory:NOFILE -autohide -attr @cell(#000000) instructionmemory -pinBusAttr addrout @name addrout[31:0] -pinBusAttr instruction @name instruction[31:0] -pg 1 -lvl 5 -x 1530 -y 840
load inst MEMORYUNIT memoryunit work:memoryunit:NOFILE -autohide -attr @cell(#000000) memoryunit -pinBusAttr address @name address[31:0] -pinBusAttr ldResult @name ldResult[31:0] -pinBusAttr mar @name mar[31:0] -pinBusAttr mar @attr n/c -pinBusAttr mdr @name mdr[31:0] -pinBusAttr mdr @attr n/c -pinBusAttr memData @name memData[31:0] -pinBusAttr op2 @name op2[31:0] -pinBusAttr result @name result[31:0] -pinBusAttr writeData @name writeData[31:0] -pg 1 -lvl 8 -x 2830 -y 100
load inst MUX1 regmux work:regmux:NOFILE -autohide -attr @cell(#000000) regmux -pinBusAttr i0 @name i0[3:0] -pinBusAttr i1 @name i1[3:0] -pinBusAttr o @name o[3:0] -pg 1 -lvl 9 -x 3190 -y 620
load inst MUX2 regmux work:abstract:NOFILE -autohide -attr @cell(#000000) regmux -pinBusAttr i0 @name i0[3:0] -pinBusAttr i1 @name i1[3:0] -pinBusAttr o @name o[3:0] -pg 1 -lvl 9 -x 3190 -y 840
load inst MUX3 regmux work:abstract:NOFILE -autohide -attr @cell(#000000) regmux -pinBusAttr i0 @name i0[3:0] -pinBusAttr i1 @name i1[3:0] -pinBusAttr o @name o[3:0] -pg 1 -lvl 9 -x 3190 -y 1000
load inst MUX4TO1 mux4to1 work:mux4to1:NOFILE -autohide -attr @cell(#000000) mux4to1 -pinBusAttr i0 @name i0[31:0] -pinBusAttr i1 @name i1[31:0] -pinBusAttr i2 @name i2[31:0] -pinBusAttr o @name o[31:0] -pg 1 -lvl 9 -x 3190 -y 280
load inst PC pc work:pc:NOFILE -autohide -attr @cell(#000000) pc -pinBusAttr addrin @name addrin[31:0] -pinBusAttr addrout @name addrout[31:0] -pinBusAttr pcplus4 @name pcplus4[31:0] -pg 1 -lvl 4 -x 1170 -y 660
load inst PCMUX addrmux work:addrmux:NOFILE -autohide -attr @cell(#000000) addrmux -pinBusAttr i0 @name i0[31:0] -pinBusAttr i1 @name i1[31:0] -pinBusAttr o @name o[31:0] -pg 1 -lvl 3 -x 920 -y 620
load inst REGISTERFILE registerfile work:registerfile:NOFILE -autohide -attr @cell(#000000) registerfile -pinBusAttr mux1 @name mux1[3:0] -pinBusAttr mux2 @name mux2[3:0] -pinBusAttr mux3 @name mux3[3:0] -pinBusAttr op1 @name op1[31:0] -pinBusAttr op2 @name op2[31:0] -pinBusAttr writedata @name writedata[31:0] -pg 1 -lvl 10 -x 3560 -y 520
load net B_top[0] -attr @rip o[0] -pin ALU B[0] -pin IMMUX o[0]
load net B_top[10] -attr @rip o[10] -pin ALU B[10] -pin IMMUX o[10]
load net B_top[11] -attr @rip o[11] -pin ALU B[11] -pin IMMUX o[11]
load net B_top[12] -attr @rip o[12] -pin ALU B[12] -pin IMMUX o[12]
load net B_top[13] -attr @rip o[13] -pin ALU B[13] -pin IMMUX o[13]
load net B_top[14] -attr @rip o[14] -pin ALU B[14] -pin IMMUX o[14]
load net B_top[15] -attr @rip o[15] -pin ALU B[15] -pin IMMUX o[15]
load net B_top[16] -attr @rip o[16] -pin ALU B[16] -pin IMMUX o[16]
load net B_top[17] -attr @rip o[17] -pin ALU B[17] -pin IMMUX o[17]
load net B_top[18] -attr @rip o[18] -pin ALU B[18] -pin IMMUX o[18]
load net B_top[19] -attr @rip o[19] -pin ALU B[19] -pin IMMUX o[19]
load net B_top[1] -attr @rip o[1] -pin ALU B[1] -pin IMMUX o[1]
load net B_top[20] -attr @rip o[20] -pin ALU B[20] -pin IMMUX o[20]
load net B_top[21] -attr @rip o[21] -pin ALU B[21] -pin IMMUX o[21]
load net B_top[22] -attr @rip o[22] -pin ALU B[22] -pin IMMUX o[22]
load net B_top[23] -attr @rip o[23] -pin ALU B[23] -pin IMMUX o[23]
load net B_top[24] -attr @rip o[24] -pin ALU B[24] -pin IMMUX o[24]
load net B_top[25] -attr @rip o[25] -pin ALU B[25] -pin IMMUX o[25]
load net B_top[26] -attr @rip o[26] -pin ALU B[26] -pin IMMUX o[26]
load net B_top[27] -attr @rip o[27] -pin ALU B[27] -pin IMMUX o[27]
load net B_top[28] -attr @rip o[28] -pin ALU B[28] -pin IMMUX o[28]
load net B_top[29] -attr @rip o[29] -pin ALU B[29] -pin IMMUX o[29]
load net B_top[2] -attr @rip o[2] -pin ALU B[2] -pin IMMUX o[2]
load net B_top[30] -attr @rip o[30] -pin ALU B[30] -pin IMMUX o[30]
load net B_top[31] -attr @rip o[31] -pin ALU B[31] -pin IMMUX o[31]
load net B_top[3] -attr @rip o[3] -pin ALU B[3] -pin IMMUX o[3]
load net B_top[4] -attr @rip o[4] -pin ALU B[4] -pin IMMUX o[4]
load net B_top[5] -attr @rip o[5] -pin ALU B[5] -pin IMMUX o[5]
load net B_top[6] -attr @rip o[6] -pin ALU B[6] -pin IMMUX o[6]
load net B_top[7] -attr @rip o[7] -pin ALU B[7] -pin IMMUX o[7]
load net B_top[8] -attr @rip o[8] -pin ALU B[8] -pin IMMUX o[8]
load net B_top[9] -attr @rip o[9] -pin ALU B[9] -pin IMMUX o[9]
load net E_in_top -pin ALU E -pin FLAGREGISTER E_in
netloc E_in_top 1 0 12 40 330 NJ 330 NJ 330 NJ 330 NJ 330 NJ 330 NJ 330 2590J 450 NJ 450 NJ 450 NJ 450 4080
load net E_top -pin BRANCHUNIT E -pin FLAGREGISTER E
netloc E_top 1 1 1 380 410n
load net GT_in_top -pin ALU GT -pin FLAGREGISTER GT_in
netloc GT_in_top 1 0 12 60 350 NJ 350 NJ 350 NJ 350 NJ 350 NJ 350 NJ 350 2570J 470 NJ 470 NJ 470 NJ 470 4040
load net GT_top -pin BRANCHUNIT GT -pin FLAGREGISTER GT
netloc GT_top 1 1 1 400 430n
load net MemRead_top -pin DATAMEMORY MemRead -pin MEMORYUNIT MemRead
netloc MemRead_top 1 6 3 2030 10 NJ 10 3110
load net MemWrite_top -pin DATAMEMORY MemWrite -pin MEMORYUNIT MemWrite
netloc MemWrite_top 1 6 3 2130 30 NJ 30 3010
load net addrin_top[0] -attr @rip o[0] -pin PC addrin[0] -pin PCMUX o[0]
load net addrin_top[10] -attr @rip o[10] -pin PC addrin[10] -pin PCMUX o[10]
load net addrin_top[11] -attr @rip o[11] -pin PC addrin[11] -pin PCMUX o[11]
load net addrin_top[12] -attr @rip o[12] -pin PC addrin[12] -pin PCMUX o[12]
load net addrin_top[13] -attr @rip o[13] -pin PC addrin[13] -pin PCMUX o[13]
load net addrin_top[14] -attr @rip o[14] -pin PC addrin[14] -pin PCMUX o[14]
load net addrin_top[15] -attr @rip o[15] -pin PC addrin[15] -pin PCMUX o[15]
load net addrin_top[16] -attr @rip o[16] -pin PC addrin[16] -pin PCMUX o[16]
load net addrin_top[17] -attr @rip o[17] -pin PC addrin[17] -pin PCMUX o[17]
load net addrin_top[18] -attr @rip o[18] -pin PC addrin[18] -pin PCMUX o[18]
load net addrin_top[19] -attr @rip o[19] -pin PC addrin[19] -pin PCMUX o[19]
load net addrin_top[1] -attr @rip o[1] -pin PC addrin[1] -pin PCMUX o[1]
load net addrin_top[20] -attr @rip o[20] -pin PC addrin[20] -pin PCMUX o[20]
load net addrin_top[21] -attr @rip o[21] -pin PC addrin[21] -pin PCMUX o[21]
load net addrin_top[22] -attr @rip o[22] -pin PC addrin[22] -pin PCMUX o[22]
load net addrin_top[23] -attr @rip o[23] -pin PC addrin[23] -pin PCMUX o[23]
load net addrin_top[24] -attr @rip o[24] -pin PC addrin[24] -pin PCMUX o[24]
load net addrin_top[25] -attr @rip o[25] -pin PC addrin[25] -pin PCMUX o[25]
load net addrin_top[26] -attr @rip o[26] -pin PC addrin[26] -pin PCMUX o[26]
load net addrin_top[27] -attr @rip o[27] -pin PC addrin[27] -pin PCMUX o[27]
load net addrin_top[28] -attr @rip o[28] -pin PC addrin[28] -pin PCMUX o[28]
load net addrin_top[29] -attr @rip o[29] -pin PC addrin[29] -pin PCMUX o[29]
load net addrin_top[2] -attr @rip o[2] -pin PC addrin[2] -pin PCMUX o[2]
load net addrin_top[30] -attr @rip o[30] -pin PC addrin[30] -pin PCMUX o[30]
load net addrin_top[31] -attr @rip o[31] -pin PC addrin[31] -pin PCMUX o[31]
load net addrin_top[3] -attr @rip o[3] -pin PC addrin[3] -pin PCMUX o[3]
load net addrin_top[4] -attr @rip o[4] -pin PC addrin[4] -pin PCMUX o[4]
load net addrin_top[5] -attr @rip o[5] -pin PC addrin[5] -pin PCMUX o[5]
load net addrin_top[6] -attr @rip o[6] -pin PC addrin[6] -pin PCMUX o[6]
load net addrin_top[7] -attr @rip o[7] -pin PC addrin[7] -pin PCMUX o[7]
load net addrin_top[8] -attr @rip o[8] -pin PC addrin[8] -pin PCMUX o[8]
load net addrin_top[9] -attr @rip o[9] -pin PC addrin[9] -pin PCMUX o[9]
load net addrout_top[0] -attr @rip addrout[0] -pin IMMEDIATEBRANCH addrout[0] -pin INSTRUCTIONMEMORY addrout[0] -pin PC addrout[0]
load net addrout_top[10] -attr @rip addrout[10] -pin IMMEDIATEBRANCH addrout[10] -pin INSTRUCTIONMEMORY addrout[10] -pin PC addrout[10]
load net addrout_top[11] -attr @rip addrout[11] -pin IMMEDIATEBRANCH addrout[11] -pin INSTRUCTIONMEMORY addrout[11] -pin PC addrout[11]
load net addrout_top[12] -attr @rip addrout[12] -pin IMMEDIATEBRANCH addrout[12] -pin INSTRUCTIONMEMORY addrout[12] -pin PC addrout[12]
load net addrout_top[13] -attr @rip addrout[13] -pin IMMEDIATEBRANCH addrout[13] -pin INSTRUCTIONMEMORY addrout[13] -pin PC addrout[13]
load net addrout_top[14] -attr @rip addrout[14] -pin IMMEDIATEBRANCH addrout[14] -pin INSTRUCTIONMEMORY addrout[14] -pin PC addrout[14]
load net addrout_top[15] -attr @rip addrout[15] -pin IMMEDIATEBRANCH addrout[15] -pin INSTRUCTIONMEMORY addrout[15] -pin PC addrout[15]
load net addrout_top[16] -attr @rip addrout[16] -pin IMMEDIATEBRANCH addrout[16] -pin INSTRUCTIONMEMORY addrout[16] -pin PC addrout[16]
load net addrout_top[17] -attr @rip addrout[17] -pin IMMEDIATEBRANCH addrout[17] -pin INSTRUCTIONMEMORY addrout[17] -pin PC addrout[17]
load net addrout_top[18] -attr @rip addrout[18] -pin IMMEDIATEBRANCH addrout[18] -pin INSTRUCTIONMEMORY addrout[18] -pin PC addrout[18]
load net addrout_top[19] -attr @rip addrout[19] -pin IMMEDIATEBRANCH addrout[19] -pin INSTRUCTIONMEMORY addrout[19] -pin PC addrout[19]
load net addrout_top[1] -attr @rip addrout[1] -pin IMMEDIATEBRANCH addrout[1] -pin INSTRUCTIONMEMORY addrout[1] -pin PC addrout[1]
load net addrout_top[20] -attr @rip addrout[20] -pin IMMEDIATEBRANCH addrout[20] -pin INSTRUCTIONMEMORY addrout[20] -pin PC addrout[20]
load net addrout_top[21] -attr @rip addrout[21] -pin IMMEDIATEBRANCH addrout[21] -pin INSTRUCTIONMEMORY addrout[21] -pin PC addrout[21]
load net addrout_top[22] -attr @rip addrout[22] -pin IMMEDIATEBRANCH addrout[22] -pin INSTRUCTIONMEMORY addrout[22] -pin PC addrout[22]
load net addrout_top[23] -attr @rip addrout[23] -pin IMMEDIATEBRANCH addrout[23] -pin INSTRUCTIONMEMORY addrout[23] -pin PC addrout[23]
load net addrout_top[24] -attr @rip addrout[24] -pin IMMEDIATEBRANCH addrout[24] -pin INSTRUCTIONMEMORY addrout[24] -pin PC addrout[24]
load net addrout_top[25] -attr @rip addrout[25] -pin IMMEDIATEBRANCH addrout[25] -pin INSTRUCTIONMEMORY addrout[25] -pin PC addrout[25]
load net addrout_top[26] -attr @rip addrout[26] -pin IMMEDIATEBRANCH addrout[26] -pin INSTRUCTIONMEMORY addrout[26] -pin PC addrout[26]
load net addrout_top[27] -attr @rip addrout[27] -pin IMMEDIATEBRANCH addrout[27] -pin INSTRUCTIONMEMORY addrout[27] -pin PC addrout[27]
load net addrout_top[28] -attr @rip addrout[28] -pin IMMEDIATEBRANCH addrout[28] -pin INSTRUCTIONMEMORY addrout[28] -pin PC addrout[28]
load net addrout_top[29] -attr @rip addrout[29] -pin IMMEDIATEBRANCH addrout[29] -pin INSTRUCTIONMEMORY addrout[29] -pin PC addrout[29]
load net addrout_top[2] -attr @rip addrout[2] -pin IMMEDIATEBRANCH addrout[2] -pin INSTRUCTIONMEMORY addrout[2] -pin PC addrout[2]
load net addrout_top[30] -attr @rip addrout[30] -pin IMMEDIATEBRANCH addrout[30] -pin INSTRUCTIONMEMORY addrout[30] -pin PC addrout[30]
load net addrout_top[31] -attr @rip addrout[31] -pin IMMEDIATEBRANCH addrout[31] -pin INSTRUCTIONMEMORY addrout[31] -pin PC addrout[31]
load net addrout_top[3] -attr @rip addrout[3] -pin IMMEDIATEBRANCH addrout[3] -pin INSTRUCTIONMEMORY addrout[3] -pin PC addrout[3]
load net addrout_top[4] -attr @rip addrout[4] -pin IMMEDIATEBRANCH addrout[4] -pin INSTRUCTIONMEMORY addrout[4] -pin PC addrout[4]
load net addrout_top[5] -attr @rip addrout[5] -pin IMMEDIATEBRANCH addrout[5] -pin INSTRUCTIONMEMORY addrout[5] -pin PC addrout[5]
load net addrout_top[6] -attr @rip addrout[6] -pin IMMEDIATEBRANCH addrout[6] -pin INSTRUCTIONMEMORY addrout[6] -pin PC addrout[6]
load net addrout_top[7] -attr @rip addrout[7] -pin IMMEDIATEBRANCH addrout[7] -pin INSTRUCTIONMEMORY addrout[7] -pin PC addrout[7]
load net addrout_top[8] -attr @rip addrout[8] -pin IMMEDIATEBRANCH addrout[8] -pin INSTRUCTIONMEMORY addrout[8] -pin PC addrout[8]
load net addrout_top[9] -attr @rip addrout[9] -pin IMMEDIATEBRANCH addrout[9] -pin INSTRUCTIONMEMORY addrout[9] -pin PC addrout[9]
load net branchaddr_top[0] -attr @rip o[0] -pin BRMUX o[0] -pin PCMUX i1[0]
load net branchaddr_top[10] -attr @rip o[10] -pin BRMUX o[10] -pin PCMUX i1[10]
load net branchaddr_top[11] -attr @rip o[11] -pin BRMUX o[11] -pin PCMUX i1[11]
load net branchaddr_top[12] -attr @rip o[12] -pin BRMUX o[12] -pin PCMUX i1[12]
load net branchaddr_top[13] -attr @rip o[13] -pin BRMUX o[13] -pin PCMUX i1[13]
load net branchaddr_top[14] -attr @rip o[14] -pin BRMUX o[14] -pin PCMUX i1[14]
load net branchaddr_top[15] -attr @rip o[15] -pin BRMUX o[15] -pin PCMUX i1[15]
load net branchaddr_top[16] -attr @rip o[16] -pin BRMUX o[16] -pin PCMUX i1[16]
load net branchaddr_top[17] -attr @rip o[17] -pin BRMUX o[17] -pin PCMUX i1[17]
load net branchaddr_top[18] -attr @rip o[18] -pin BRMUX o[18] -pin PCMUX i1[18]
load net branchaddr_top[19] -attr @rip o[19] -pin BRMUX o[19] -pin PCMUX i1[19]
load net branchaddr_top[1] -attr @rip o[1] -pin BRMUX o[1] -pin PCMUX i1[1]
load net branchaddr_top[20] -attr @rip o[20] -pin BRMUX o[20] -pin PCMUX i1[20]
load net branchaddr_top[21] -attr @rip o[21] -pin BRMUX o[21] -pin PCMUX i1[21]
load net branchaddr_top[22] -attr @rip o[22] -pin BRMUX o[22] -pin PCMUX i1[22]
load net branchaddr_top[23] -attr @rip o[23] -pin BRMUX o[23] -pin PCMUX i1[23]
load net branchaddr_top[24] -attr @rip o[24] -pin BRMUX o[24] -pin PCMUX i1[24]
load net branchaddr_top[25] -attr @rip o[25] -pin BRMUX o[25] -pin PCMUX i1[25]
load net branchaddr_top[26] -attr @rip o[26] -pin BRMUX o[26] -pin PCMUX i1[26]
load net branchaddr_top[27] -attr @rip o[27] -pin BRMUX o[27] -pin PCMUX i1[27]
load net branchaddr_top[28] -attr @rip o[28] -pin BRMUX o[28] -pin PCMUX i1[28]
load net branchaddr_top[29] -attr @rip o[29] -pin BRMUX o[29] -pin PCMUX i1[29]
load net branchaddr_top[2] -attr @rip o[2] -pin BRMUX o[2] -pin PCMUX i1[2]
load net branchaddr_top[30] -attr @rip o[30] -pin BRMUX o[30] -pin PCMUX i1[30]
load net branchaddr_top[31] -attr @rip o[31] -pin BRMUX o[31] -pin PCMUX i1[31]
load net branchaddr_top[3] -attr @rip o[3] -pin BRMUX o[3] -pin PCMUX i1[3]
load net branchaddr_top[4] -attr @rip o[4] -pin BRMUX o[4] -pin PCMUX i1[4]
load net branchaddr_top[5] -attr @rip o[5] -pin BRMUX o[5] -pin PCMUX i1[5]
load net branchaddr_top[6] -attr @rip o[6] -pin BRMUX o[6] -pin PCMUX i1[6]
load net branchaddr_top[7] -attr @rip o[7] -pin BRMUX o[7] -pin PCMUX i1[7]
load net branchaddr_top[8] -attr @rip o[8] -pin BRMUX o[8] -pin PCMUX i1[8]
load net branchaddr_top[9] -attr @rip o[9] -pin BRMUX o[9] -pin PCMUX i1[9]
load net branchtarget_top[0] -attr @rip branchtarget[0] -pin BRMUX i0[0] -pin IMMEDIATEBRANCH branchtarget[0]
load net branchtarget_top[10] -attr @rip branchtarget[10] -pin BRMUX i0[10] -pin IMMEDIATEBRANCH branchtarget[10]
load net branchtarget_top[11] -attr @rip branchtarget[11] -pin BRMUX i0[11] -pin IMMEDIATEBRANCH branchtarget[11]
load net branchtarget_top[12] -attr @rip branchtarget[12] -pin BRMUX i0[12] -pin IMMEDIATEBRANCH branchtarget[12]
load net branchtarget_top[13] -attr @rip branchtarget[13] -pin BRMUX i0[13] -pin IMMEDIATEBRANCH branchtarget[13]
load net branchtarget_top[14] -attr @rip branchtarget[14] -pin BRMUX i0[14] -pin IMMEDIATEBRANCH branchtarget[14]
load net branchtarget_top[15] -attr @rip branchtarget[15] -pin BRMUX i0[15] -pin IMMEDIATEBRANCH branchtarget[15]
load net branchtarget_top[16] -attr @rip branchtarget[16] -pin BRMUX i0[16] -pin IMMEDIATEBRANCH branchtarget[16]
load net branchtarget_top[17] -attr @rip branchtarget[17] -pin BRMUX i0[17] -pin IMMEDIATEBRANCH branchtarget[17]
load net branchtarget_top[18] -attr @rip branchtarget[18] -pin BRMUX i0[18] -pin IMMEDIATEBRANCH branchtarget[18]
load net branchtarget_top[19] -attr @rip branchtarget[19] -pin BRMUX i0[19] -pin IMMEDIATEBRANCH branchtarget[19]
load net branchtarget_top[1] -attr @rip branchtarget[1] -pin BRMUX i0[1] -pin IMMEDIATEBRANCH branchtarget[1]
load net branchtarget_top[20] -attr @rip branchtarget[20] -pin BRMUX i0[20] -pin IMMEDIATEBRANCH branchtarget[20]
load net branchtarget_top[21] -attr @rip branchtarget[21] -pin BRMUX i0[21] -pin IMMEDIATEBRANCH branchtarget[21]
load net branchtarget_top[22] -attr @rip branchtarget[22] -pin BRMUX i0[22] -pin IMMEDIATEBRANCH branchtarget[22]
load net branchtarget_top[23] -attr @rip branchtarget[23] -pin BRMUX i0[23] -pin IMMEDIATEBRANCH branchtarget[23]
load net branchtarget_top[24] -attr @rip branchtarget[24] -pin BRMUX i0[24] -pin IMMEDIATEBRANCH branchtarget[24]
load net branchtarget_top[25] -attr @rip branchtarget[25] -pin BRMUX i0[25] -pin IMMEDIATEBRANCH branchtarget[25]
load net branchtarget_top[26] -attr @rip branchtarget[26] -pin BRMUX i0[26] -pin IMMEDIATEBRANCH branchtarget[26]
load net branchtarget_top[27] -attr @rip branchtarget[27] -pin BRMUX i0[27] -pin IMMEDIATEBRANCH branchtarget[27]
load net branchtarget_top[28] -attr @rip branchtarget[28] -pin BRMUX i0[28] -pin IMMEDIATEBRANCH branchtarget[28]
load net branchtarget_top[29] -attr @rip branchtarget[29] -pin BRMUX i0[29] -pin IMMEDIATEBRANCH branchtarget[29]
load net branchtarget_top[2] -attr @rip branchtarget[2] -pin BRMUX i0[2] -pin IMMEDIATEBRANCH branchtarget[2]
load net branchtarget_top[30] -attr @rip branchtarget[30] -pin BRMUX i0[30] -pin IMMEDIATEBRANCH branchtarget[30]
load net branchtarget_top[31] -attr @rip branchtarget[31] -pin BRMUX i0[31] -pin IMMEDIATEBRANCH branchtarget[31]
load net branchtarget_top[3] -attr @rip branchtarget[3] -pin BRMUX i0[3] -pin IMMEDIATEBRANCH branchtarget[3]
load net branchtarget_top[4] -attr @rip branchtarget[4] -pin BRMUX i0[4] -pin IMMEDIATEBRANCH branchtarget[4]
load net branchtarget_top[5] -attr @rip branchtarget[5] -pin BRMUX i0[5] -pin IMMEDIATEBRANCH branchtarget[5]
load net branchtarget_top[6] -attr @rip branchtarget[6] -pin BRMUX i0[6] -pin IMMEDIATEBRANCH branchtarget[6]
load net branchtarget_top[7] -attr @rip branchtarget[7] -pin BRMUX i0[7] -pin IMMEDIATEBRANCH branchtarget[7]
load net branchtarget_top[8] -attr @rip branchtarget[8] -pin BRMUX i0[8] -pin IMMEDIATEBRANCH branchtarget[8]
load net branchtarget_top[9] -attr @rip branchtarget[9] -pin BRMUX i0[9] -pin IMMEDIATEBRANCH branchtarget[9]
load net clk -pin BRANCHUNIT clk -pin CONTROLUNIT clk -pin DATAMEMORY clk -pin FLAGREGISTER clk -pin INSTRUCTIONFETCH clk -pin INSTRUCTIONMEMORY clk -pin MEMORYUNIT clk -pin PC clk -pin REGISTERFILE clk -port clk
netloc clk 1 0 10 20 370 420 710 NJ 710 1050 830 1420 790 1750 450 2030 230 2610 530 NJ 530 NJ
load net immx_top[0] -attr @rip immx[0] -pin IMMEDIATEBRANCH immx[0] -pin IMMUX i1[0]
load net immx_top[10] -attr @rip immx[10] -pin IMMEDIATEBRANCH immx[10] -pin IMMUX i1[10]
load net immx_top[11] -attr @rip immx[11] -pin IMMEDIATEBRANCH immx[11] -pin IMMUX i1[11]
load net immx_top[12] -attr @rip immx[12] -pin IMMEDIATEBRANCH immx[12] -pin IMMUX i1[12]
load net immx_top[13] -attr @rip immx[13] -pin IMMEDIATEBRANCH immx[13] -pin IMMUX i1[13]
load net immx_top[14] -attr @rip immx[14] -pin IMMEDIATEBRANCH immx[14] -pin IMMUX i1[14]
load net immx_top[15] -attr @rip immx[15] -pin IMMEDIATEBRANCH immx[15] -pin IMMUX i1[15]
load net immx_top[16] -attr @rip immx[16] -pin IMMEDIATEBRANCH immx[16] -pin IMMUX i1[16]
load net immx_top[17] -attr @rip immx[17] -pin IMMEDIATEBRANCH immx[17] -pin IMMUX i1[17]
load net immx_top[18] -attr @rip immx[18] -pin IMMEDIATEBRANCH immx[18] -pin IMMUX i1[18]
load net immx_top[19] -attr @rip immx[19] -pin IMMEDIATEBRANCH immx[19] -pin IMMUX i1[19]
load net immx_top[1] -attr @rip immx[1] -pin IMMEDIATEBRANCH immx[1] -pin IMMUX i1[1]
load net immx_top[20] -attr @rip immx[20] -pin IMMEDIATEBRANCH immx[20] -pin IMMUX i1[20]
load net immx_top[21] -attr @rip immx[21] -pin IMMEDIATEBRANCH immx[21] -pin IMMUX i1[21]
load net immx_top[22] -attr @rip immx[22] -pin IMMEDIATEBRANCH immx[22] -pin IMMUX i1[22]
load net immx_top[23] -attr @rip immx[23] -pin IMMEDIATEBRANCH immx[23] -pin IMMUX i1[23]
load net immx_top[24] -attr @rip immx[24] -pin IMMEDIATEBRANCH immx[24] -pin IMMUX i1[24]
load net immx_top[25] -attr @rip immx[25] -pin IMMEDIATEBRANCH immx[25] -pin IMMUX i1[25]
load net immx_top[26] -attr @rip immx[26] -pin IMMEDIATEBRANCH immx[26] -pin IMMUX i1[26]
load net immx_top[27] -attr @rip immx[27] -pin IMMEDIATEBRANCH immx[27] -pin IMMUX i1[27]
load net immx_top[28] -attr @rip immx[28] -pin IMMEDIATEBRANCH immx[28] -pin IMMUX i1[28]
load net immx_top[29] -attr @rip immx[29] -pin IMMEDIATEBRANCH immx[29] -pin IMMUX i1[29]
load net immx_top[2] -attr @rip immx[2] -pin IMMEDIATEBRANCH immx[2] -pin IMMUX i1[2]
load net immx_top[30] -attr @rip immx[30] -pin IMMEDIATEBRANCH immx[30] -pin IMMUX i1[30]
load net immx_top[31] -attr @rip immx[31] -pin IMMEDIATEBRANCH immx[31] -pin IMMUX i1[31]
load net immx_top[3] -attr @rip immx[3] -pin IMMEDIATEBRANCH immx[3] -pin IMMUX i1[3]
load net immx_top[4] -attr @rip immx[4] -pin IMMEDIATEBRANCH immx[4] -pin IMMUX i1[4]
load net immx_top[5] -attr @rip immx[5] -pin IMMEDIATEBRANCH immx[5] -pin IMMUX i1[5]
load net immx_top[6] -attr @rip immx[6] -pin IMMEDIATEBRANCH immx[6] -pin IMMUX i1[6]
load net immx_top[7] -attr @rip immx[7] -pin IMMEDIATEBRANCH immx[7] -pin IMMUX i1[7]
load net immx_top[8] -attr @rip immx[8] -pin IMMEDIATEBRANCH immx[8] -pin IMMUX i1[8]
load net immx_top[9] -attr @rip immx[9] -pin IMMEDIATEBRANCH immx[9] -pin IMMUX i1[9]
load net instruction_top[0] -attr @rip instruction[0] -pin IMMEDIATEBRANCH instruction[0] -pin INSTRUCTIONFETCH instruction[0] -pin INSTRUCTIONMEMORY instruction[0]
load net instruction_top[10] -attr @rip instruction[10] -pin IMMEDIATEBRANCH instruction[10] -pin INSTRUCTIONFETCH instruction[10] -pin INSTRUCTIONMEMORY instruction[10]
load net instruction_top[11] -attr @rip instruction[11] -pin IMMEDIATEBRANCH instruction[11] -pin INSTRUCTIONFETCH instruction[11] -pin INSTRUCTIONMEMORY instruction[11]
load net instruction_top[12] -attr @rip instruction[12] -pin IMMEDIATEBRANCH instruction[12] -pin INSTRUCTIONFETCH instruction[12] -pin INSTRUCTIONMEMORY instruction[12]
load net instruction_top[13] -attr @rip instruction[13] -pin IMMEDIATEBRANCH instruction[13] -pin INSTRUCTIONFETCH instruction[13] -pin INSTRUCTIONMEMORY instruction[13]
load net instruction_top[14] -attr @rip instruction[14] -pin IMMEDIATEBRANCH instruction[14] -pin INSTRUCTIONFETCH instruction[14] -pin INSTRUCTIONMEMORY instruction[14]
load net instruction_top[15] -attr @rip instruction[15] -pin IMMEDIATEBRANCH instruction[15] -pin INSTRUCTIONFETCH instruction[15] -pin INSTRUCTIONMEMORY instruction[15]
load net instruction_top[16] -attr @rip instruction[16] -pin IMMEDIATEBRANCH instruction[16] -pin INSTRUCTIONFETCH instruction[16] -pin INSTRUCTIONMEMORY instruction[16]
load net instruction_top[17] -attr @rip instruction[17] -pin IMMEDIATEBRANCH instruction[17] -pin INSTRUCTIONFETCH instruction[17] -pin INSTRUCTIONMEMORY instruction[17]
load net instruction_top[18] -attr @rip instruction[18] -pin IMMEDIATEBRANCH instruction[18] -pin INSTRUCTIONFETCH instruction[18] -pin INSTRUCTIONMEMORY instruction[18]
load net instruction_top[19] -attr @rip instruction[19] -pin IMMEDIATEBRANCH instruction[19] -pin INSTRUCTIONFETCH instruction[19] -pin INSTRUCTIONMEMORY instruction[19]
load net instruction_top[1] -attr @rip instruction[1] -pin IMMEDIATEBRANCH instruction[1] -pin INSTRUCTIONFETCH instruction[1] -pin INSTRUCTIONMEMORY instruction[1]
load net instruction_top[20] -attr @rip instruction[20] -pin IMMEDIATEBRANCH instruction[20] -pin INSTRUCTIONFETCH instruction[20] -pin INSTRUCTIONMEMORY instruction[20]
load net instruction_top[21] -attr @rip instruction[21] -pin IMMEDIATEBRANCH instruction[21] -pin INSTRUCTIONFETCH instruction[21] -pin INSTRUCTIONMEMORY instruction[21]
load net instruction_top[22] -attr @rip instruction[22] -pin IMMEDIATEBRANCH instruction[22] -pin INSTRUCTIONFETCH instruction[22] -pin INSTRUCTIONMEMORY instruction[22]
load net instruction_top[23] -attr @rip instruction[23] -pin IMMEDIATEBRANCH instruction[23] -pin INSTRUCTIONFETCH instruction[23] -pin INSTRUCTIONMEMORY instruction[23]
load net instruction_top[24] -attr @rip instruction[24] -pin IMMEDIATEBRANCH instruction[24] -pin INSTRUCTIONFETCH instruction[24] -pin INSTRUCTIONMEMORY instruction[24]
load net instruction_top[25] -attr @rip instruction[25] -pin IMMEDIATEBRANCH instruction[25] -pin INSTRUCTIONFETCH instruction[25] -pin INSTRUCTIONMEMORY instruction[25]
load net instruction_top[26] -attr @rip instruction[26] -pin IMMEDIATEBRANCH instruction[26] -pin INSTRUCTIONFETCH instruction[26] -pin INSTRUCTIONMEMORY instruction[26]
load net instruction_top[27] -attr @rip instruction[27] -pin IMMEDIATEBRANCH instruction[27] -pin INSTRUCTIONFETCH instruction[27] -pin INSTRUCTIONMEMORY instruction[27]
load net instruction_top[28] -attr @rip instruction[28] -pin IMMEDIATEBRANCH instruction[28] -pin INSTRUCTIONFETCH instruction[28] -pin INSTRUCTIONMEMORY instruction[28]
load net instruction_top[29] -attr @rip instruction[29] -pin IMMEDIATEBRANCH instruction[29] -pin INSTRUCTIONFETCH instruction[29] -pin INSTRUCTIONMEMORY instruction[29]
load net instruction_top[2] -attr @rip instruction[2] -pin IMMEDIATEBRANCH instruction[2] -pin INSTRUCTIONFETCH instruction[2] -pin INSTRUCTIONMEMORY instruction[2]
load net instruction_top[30] -attr @rip instruction[30] -pin IMMEDIATEBRANCH instruction[30] -pin INSTRUCTIONFETCH instruction[30] -pin INSTRUCTIONMEMORY instruction[30]
load net instruction_top[31] -attr @rip instruction[31] -pin IMMEDIATEBRANCH instruction[31] -pin INSTRUCTIONFETCH instruction[31] -pin INSTRUCTIONMEMORY instruction[31]
load net instruction_top[3] -attr @rip instruction[3] -pin IMMEDIATEBRANCH instruction[3] -pin INSTRUCTIONFETCH instruction[3] -pin INSTRUCTIONMEMORY instruction[3]
load net instruction_top[4] -attr @rip instruction[4] -pin IMMEDIATEBRANCH instruction[4] -pin INSTRUCTIONFETCH instruction[4] -pin INSTRUCTIONMEMORY instruction[4]
load net instruction_top[5] -attr @rip instruction[5] -pin IMMEDIATEBRANCH instruction[5] -pin INSTRUCTIONFETCH instruction[5] -pin INSTRUCTIONMEMORY instruction[5]
load net instruction_top[6] -attr @rip instruction[6] -pin IMMEDIATEBRANCH instruction[6] -pin INSTRUCTIONFETCH instruction[6] -pin INSTRUCTIONMEMORY instruction[6]
load net instruction_top[7] -attr @rip instruction[7] -pin IMMEDIATEBRANCH instruction[7] -pin INSTRUCTIONFETCH instruction[7] -pin INSTRUCTIONMEMORY instruction[7]
load net instruction_top[8] -attr @rip instruction[8] -pin IMMEDIATEBRANCH instruction[8] -pin INSTRUCTIONFETCH instruction[8] -pin INSTRUCTIONMEMORY instruction[8]
load net instruction_top[9] -attr @rip instruction[9] -pin IMMEDIATEBRANCH instruction[9] -pin INSTRUCTIONFETCH instruction[9] -pin INSTRUCTIONMEMORY instruction[9]
load net isBeq_top -pin BRANCHUNIT isBeq -pin CONTROLUNIT isBeq
netloc isBeq_top 1 1 7 460 570 760J 510 NJ 510 NJ 510 NJ 510 2130J 590 2510
load net isBgt_top -pin BRANCHUNIT isBgt -pin CONTROLUNIT isBgt
netloc isBgt_top 1 1 7 480 590 780J 530 NJ 530 NJ 530 NJ 530 2070J 610 2490
load net isBranchTaken_top -pin BRANCHUNIT isBranchTaken -pin PCMUX s0
netloc isBranchTaken_top 1 2 1 800 470n
load net isCall_top -pin CONTROLUNIT isCall -pin MUX3 s0 -pin MUX4TO1 s0
netloc isCall_top 1 7 2 2550 990 3030
load net isImmediate_top -pin IMMUX s0 -pin INSTRUCTIONFETCH isImmediate
netloc isImmediate_top 1 6 4 2130 930 NJ 930 NJ 930 NJ
load net isLd_top -pin CONTROLUNIT isLd -pin MEMORYUNIT isLd -pin MUX4TO1 s1
netloc isLd_top 1 7 2 2530 370 NJ
load net isRet_top -pin BRMUX s0 -pin CONTROLUNIT isRet -pin MUX2 s0
netloc isRet_top 1 1 8 500 970 NJ 970 NJ 970 NJ 970 NJ 970 2090J 910 2530 890 NJ
load net isSt_top -pin CONTROLUNIT isSt -pin MEMORYUNIT isSt -pin MUX1 s0
netloc isSt_top 1 7 2 2630 670 NJ
load net isUBranch_top -pin BRANCHUNIT isUBranch -pin CONTROLUNIT isUBranch
netloc isUBranch_top 1 1 7 500 610 820J 550 NJ 550 NJ 550 NJ 550 2050J 630 2470
load net isWb_top -pin CONTROLUNIT isWb -pin REGISTERFILE isWb
netloc isWb_top 1 7 3 N 550 NJ 550 NJ
load net memdataout_top[0] -attr @rip MemData_out[0] -pin DATAMEMORY MemData_out[0] -pin MEMORYUNIT memData[0]
load net memdataout_top[10] -attr @rip MemData_out[10] -pin DATAMEMORY MemData_out[10] -pin MEMORYUNIT memData[10]
load net memdataout_top[11] -attr @rip MemData_out[11] -pin DATAMEMORY MemData_out[11] -pin MEMORYUNIT memData[11]
load net memdataout_top[12] -attr @rip MemData_out[12] -pin DATAMEMORY MemData_out[12] -pin MEMORYUNIT memData[12]
load net memdataout_top[13] -attr @rip MemData_out[13] -pin DATAMEMORY MemData_out[13] -pin MEMORYUNIT memData[13]
load net memdataout_top[14] -attr @rip MemData_out[14] -pin DATAMEMORY MemData_out[14] -pin MEMORYUNIT memData[14]
load net memdataout_top[15] -attr @rip MemData_out[15] -pin DATAMEMORY MemData_out[15] -pin MEMORYUNIT memData[15]
load net memdataout_top[16] -attr @rip MemData_out[16] -pin DATAMEMORY MemData_out[16] -pin MEMORYUNIT memData[16]
load net memdataout_top[17] -attr @rip MemData_out[17] -pin DATAMEMORY MemData_out[17] -pin MEMORYUNIT memData[17]
load net memdataout_top[18] -attr @rip MemData_out[18] -pin DATAMEMORY MemData_out[18] -pin MEMORYUNIT memData[18]
load net memdataout_top[19] -attr @rip MemData_out[19] -pin DATAMEMORY MemData_out[19] -pin MEMORYUNIT memData[19]
load net memdataout_top[1] -attr @rip MemData_out[1] -pin DATAMEMORY MemData_out[1] -pin MEMORYUNIT memData[1]
load net memdataout_top[20] -attr @rip MemData_out[20] -pin DATAMEMORY MemData_out[20] -pin MEMORYUNIT memData[20]
load net memdataout_top[21] -attr @rip MemData_out[21] -pin DATAMEMORY MemData_out[21] -pin MEMORYUNIT memData[21]
load net memdataout_top[22] -attr @rip MemData_out[22] -pin DATAMEMORY MemData_out[22] -pin MEMORYUNIT memData[22]
load net memdataout_top[23] -attr @rip MemData_out[23] -pin DATAMEMORY MemData_out[23] -pin MEMORYUNIT memData[23]
load net memdataout_top[24] -attr @rip MemData_out[24] -pin DATAMEMORY MemData_out[24] -pin MEMORYUNIT memData[24]
load net memdataout_top[25] -attr @rip MemData_out[25] -pin DATAMEMORY MemData_out[25] -pin MEMORYUNIT memData[25]
load net memdataout_top[26] -attr @rip MemData_out[26] -pin DATAMEMORY MemData_out[26] -pin MEMORYUNIT memData[26]
load net memdataout_top[27] -attr @rip MemData_out[27] -pin DATAMEMORY MemData_out[27] -pin MEMORYUNIT memData[27]
load net memdataout_top[28] -attr @rip MemData_out[28] -pin DATAMEMORY MemData_out[28] -pin MEMORYUNIT memData[28]
load net memdataout_top[29] -attr @rip MemData_out[29] -pin DATAMEMORY MemData_out[29] -pin MEMORYUNIT memData[29]
load net memdataout_top[2] -attr @rip MemData_out[2] -pin DATAMEMORY MemData_out[2] -pin MEMORYUNIT memData[2]
load net memdataout_top[30] -attr @rip MemData_out[30] -pin DATAMEMORY MemData_out[30] -pin MEMORYUNIT memData[30]
load net memdataout_top[31] -attr @rip MemData_out[31] -pin DATAMEMORY MemData_out[31] -pin MEMORYUNIT memData[31]
load net memdataout_top[3] -attr @rip MemData_out[3] -pin DATAMEMORY MemData_out[3] -pin MEMORYUNIT memData[3]
load net memdataout_top[4] -attr @rip MemData_out[4] -pin DATAMEMORY MemData_out[4] -pin MEMORYUNIT memData[4]
load net memdataout_top[5] -attr @rip MemData_out[5] -pin DATAMEMORY MemData_out[5] -pin MEMORYUNIT memData[5]
load net memdataout_top[6] -attr @rip MemData_out[6] -pin DATAMEMORY MemData_out[6] -pin MEMORYUNIT memData[6]
load net memdataout_top[7] -attr @rip MemData_out[7] -pin DATAMEMORY MemData_out[7] -pin MEMORYUNIT memData[7]
load net memdataout_top[8] -attr @rip MemData_out[8] -pin DATAMEMORY MemData_out[8] -pin MEMORYUNIT memData[8]
load net memdataout_top[9] -attr @rip MemData_out[9] -pin DATAMEMORY MemData_out[9] -pin MEMORYUNIT memData[9]
load net mux1_top[0] -attr @rip o[0] -pin MUX1 o[0] -pin REGISTERFILE mux1[0]
load net mux1_top[1] -attr @rip o[1] -pin MUX1 o[1] -pin REGISTERFILE mux1[1]
load net mux1_top[2] -attr @rip o[2] -pin MUX1 o[2] -pin REGISTERFILE mux1[2]
load net mux1_top[3] -attr @rip o[3] -pin MUX1 o[3] -pin REGISTERFILE mux1[3]
load net mux2_top[0] -attr @rip o[0] -pin MUX2 o[0] -pin REGISTERFILE mux2[0]
load net mux2_top[1] -attr @rip o[1] -pin MUX2 o[1] -pin REGISTERFILE mux2[1]
load net mux2_top[2] -attr @rip o[2] -pin MUX2 o[2] -pin REGISTERFILE mux2[2]
load net mux2_top[3] -attr @rip o[3] -pin MUX2 o[3] -pin REGISTERFILE mux2[3]
load net mux3_top[0] -attr @rip o[0] -pin MUX3 o[0] -pin REGISTERFILE mux3[0]
load net mux3_top[1] -attr @rip o[1] -pin MUX3 o[1] -pin REGISTERFILE mux3[1]
load net mux3_top[2] -attr @rip o[2] -pin MUX3 o[2] -pin REGISTERFILE mux3[2]
load net mux3_top[3] -attr @rip o[3] -pin MUX3 o[3] -pin REGISTERFILE mux3[3]
load net op1_top[0] -attr @rip op1[0] -pin ALU A[0] -pin BRMUX i1[0] -pin REGISTERFILE op1[0]
load net op1_top[10] -attr @rip op1[10] -pin ALU A[10] -pin BRMUX i1[10] -pin REGISTERFILE op1[10]
load net op1_top[11] -attr @rip op1[11] -pin ALU A[11] -pin BRMUX i1[11] -pin REGISTERFILE op1[11]
load net op1_top[12] -attr @rip op1[12] -pin ALU A[12] -pin BRMUX i1[12] -pin REGISTERFILE op1[12]
load net op1_top[13] -attr @rip op1[13] -pin ALU A[13] -pin BRMUX i1[13] -pin REGISTERFILE op1[13]
load net op1_top[14] -attr @rip op1[14] -pin ALU A[14] -pin BRMUX i1[14] -pin REGISTERFILE op1[14]
load net op1_top[15] -attr @rip op1[15] -pin ALU A[15] -pin BRMUX i1[15] -pin REGISTERFILE op1[15]
load net op1_top[16] -attr @rip op1[16] -pin ALU A[16] -pin BRMUX i1[16] -pin REGISTERFILE op1[16]
load net op1_top[17] -attr @rip op1[17] -pin ALU A[17] -pin BRMUX i1[17] -pin REGISTERFILE op1[17]
load net op1_top[18] -attr @rip op1[18] -pin ALU A[18] -pin BRMUX i1[18] -pin REGISTERFILE op1[18]
load net op1_top[19] -attr @rip op1[19] -pin ALU A[19] -pin BRMUX i1[19] -pin REGISTERFILE op1[19]
load net op1_top[1] -attr @rip op1[1] -pin ALU A[1] -pin BRMUX i1[1] -pin REGISTERFILE op1[1]
load net op1_top[20] -attr @rip op1[20] -pin ALU A[20] -pin BRMUX i1[20] -pin REGISTERFILE op1[20]
load net op1_top[21] -attr @rip op1[21] -pin ALU A[21] -pin BRMUX i1[21] -pin REGISTERFILE op1[21]
load net op1_top[22] -attr @rip op1[22] -pin ALU A[22] -pin BRMUX i1[22] -pin REGISTERFILE op1[22]
load net op1_top[23] -attr @rip op1[23] -pin ALU A[23] -pin BRMUX i1[23] -pin REGISTERFILE op1[23]
load net op1_top[24] -attr @rip op1[24] -pin ALU A[24] -pin BRMUX i1[24] -pin REGISTERFILE op1[24]
load net op1_top[25] -attr @rip op1[25] -pin ALU A[25] -pin BRMUX i1[25] -pin REGISTERFILE op1[25]
load net op1_top[26] -attr @rip op1[26] -pin ALU A[26] -pin BRMUX i1[26] -pin REGISTERFILE op1[26]
load net op1_top[27] -attr @rip op1[27] -pin ALU A[27] -pin BRMUX i1[27] -pin REGISTERFILE op1[27]
load net op1_top[28] -attr @rip op1[28] -pin ALU A[28] -pin BRMUX i1[28] -pin REGISTERFILE op1[28]
load net op1_top[29] -attr @rip op1[29] -pin ALU A[29] -pin BRMUX i1[29] -pin REGISTERFILE op1[29]
load net op1_top[2] -attr @rip op1[2] -pin ALU A[2] -pin BRMUX i1[2] -pin REGISTERFILE op1[2]
load net op1_top[30] -attr @rip op1[30] -pin ALU A[30] -pin BRMUX i1[30] -pin REGISTERFILE op1[30]
load net op1_top[31] -attr @rip op1[31] -pin ALU A[31] -pin BRMUX i1[31] -pin REGISTERFILE op1[31]
load net op1_top[3] -attr @rip op1[3] -pin ALU A[3] -pin BRMUX i1[3] -pin REGISTERFILE op1[3]
load net op1_top[4] -attr @rip op1[4] -pin ALU A[4] -pin BRMUX i1[4] -pin REGISTERFILE op1[4]
load net op1_top[5] -attr @rip op1[5] -pin ALU A[5] -pin BRMUX i1[5] -pin REGISTERFILE op1[5]
load net op1_top[6] -attr @rip op1[6] -pin ALU A[6] -pin BRMUX i1[6] -pin REGISTERFILE op1[6]
load net op1_top[7] -attr @rip op1[7] -pin ALU A[7] -pin BRMUX i1[7] -pin REGISTERFILE op1[7]
load net op1_top[8] -attr @rip op1[8] -pin ALU A[8] -pin BRMUX i1[8] -pin REGISTERFILE op1[8]
load net op1_top[9] -attr @rip op1[9] -pin ALU A[9] -pin BRMUX i1[9] -pin REGISTERFILE op1[9]
load net op2_top[0] -attr @rip op2[0] -pin IMMUX i0[0] -pin MEMORYUNIT op2[0] -pin REGISTERFILE op2[0]
load net op2_top[10] -attr @rip op2[10] -pin IMMUX i0[10] -pin MEMORYUNIT op2[10] -pin REGISTERFILE op2[10]
load net op2_top[11] -attr @rip op2[11] -pin IMMUX i0[11] -pin MEMORYUNIT op2[11] -pin REGISTERFILE op2[11]
load net op2_top[12] -attr @rip op2[12] -pin IMMUX i0[12] -pin MEMORYUNIT op2[12] -pin REGISTERFILE op2[12]
load net op2_top[13] -attr @rip op2[13] -pin IMMUX i0[13] -pin MEMORYUNIT op2[13] -pin REGISTERFILE op2[13]
load net op2_top[14] -attr @rip op2[14] -pin IMMUX i0[14] -pin MEMORYUNIT op2[14] -pin REGISTERFILE op2[14]
load net op2_top[15] -attr @rip op2[15] -pin IMMUX i0[15] -pin MEMORYUNIT op2[15] -pin REGISTERFILE op2[15]
load net op2_top[16] -attr @rip op2[16] -pin IMMUX i0[16] -pin MEMORYUNIT op2[16] -pin REGISTERFILE op2[16]
load net op2_top[17] -attr @rip op2[17] -pin IMMUX i0[17] -pin MEMORYUNIT op2[17] -pin REGISTERFILE op2[17]
load net op2_top[18] -attr @rip op2[18] -pin IMMUX i0[18] -pin MEMORYUNIT op2[18] -pin REGISTERFILE op2[18]
load net op2_top[19] -attr @rip op2[19] -pin IMMUX i0[19] -pin MEMORYUNIT op2[19] -pin REGISTERFILE op2[19]
load net op2_top[1] -attr @rip op2[1] -pin IMMUX i0[1] -pin MEMORYUNIT op2[1] -pin REGISTERFILE op2[1]
load net op2_top[20] -attr @rip op2[20] -pin IMMUX i0[20] -pin MEMORYUNIT op2[20] -pin REGISTERFILE op2[20]
load net op2_top[21] -attr @rip op2[21] -pin IMMUX i0[21] -pin MEMORYUNIT op2[21] -pin REGISTERFILE op2[21]
load net op2_top[22] -attr @rip op2[22] -pin IMMUX i0[22] -pin MEMORYUNIT op2[22] -pin REGISTERFILE op2[22]
load net op2_top[23] -attr @rip op2[23] -pin IMMUX i0[23] -pin MEMORYUNIT op2[23] -pin REGISTERFILE op2[23]
load net op2_top[24] -attr @rip op2[24] -pin IMMUX i0[24] -pin MEMORYUNIT op2[24] -pin REGISTERFILE op2[24]
load net op2_top[25] -attr @rip op2[25] -pin IMMUX i0[25] -pin MEMORYUNIT op2[25] -pin REGISTERFILE op2[25]
load net op2_top[26] -attr @rip op2[26] -pin IMMUX i0[26] -pin MEMORYUNIT op2[26] -pin REGISTERFILE op2[26]
load net op2_top[27] -attr @rip op2[27] -pin IMMUX i0[27] -pin MEMORYUNIT op2[27] -pin REGISTERFILE op2[27]
load net op2_top[28] -attr @rip op2[28] -pin IMMUX i0[28] -pin MEMORYUNIT op2[28] -pin REGISTERFILE op2[28]
load net op2_top[29] -attr @rip op2[29] -pin IMMUX i0[29] -pin MEMORYUNIT op2[29] -pin REGISTERFILE op2[29]
load net op2_top[2] -attr @rip op2[2] -pin IMMUX i0[2] -pin MEMORYUNIT op2[2] -pin REGISTERFILE op2[2]
load net op2_top[30] -attr @rip op2[30] -pin IMMUX i0[30] -pin MEMORYUNIT op2[30] -pin REGISTERFILE op2[30]
load net op2_top[31] -attr @rip op2[31] -pin IMMUX i0[31] -pin MEMORYUNIT op2[31] -pin REGISTERFILE op2[31]
load net op2_top[3] -attr @rip op2[3] -pin IMMUX i0[3] -pin MEMORYUNIT op2[3] -pin REGISTERFILE op2[3]
load net op2_top[4] -attr @rip op2[4] -pin IMMUX i0[4] -pin MEMORYUNIT op2[4] -pin REGISTERFILE op2[4]
load net op2_top[5] -attr @rip op2[5] -pin IMMUX i0[5] -pin MEMORYUNIT op2[5] -pin REGISTERFILE op2[5]
load net op2_top[6] -attr @rip op2[6] -pin IMMUX i0[6] -pin MEMORYUNIT op2[6] -pin REGISTERFILE op2[6]
load net op2_top[7] -attr @rip op2[7] -pin IMMUX i0[7] -pin MEMORYUNIT op2[7] -pin REGISTERFILE op2[7]
load net op2_top[8] -attr @rip op2[8] -pin IMMUX i0[8] -pin MEMORYUNIT op2[8] -pin REGISTERFILE op2[8]
load net op2_top[9] -attr @rip op2[9] -pin IMMUX i0[9] -pin MEMORYUNIT op2[9] -pin REGISTERFILE op2[9]
load net opcode_top[0] -attr @rip opcode[0] -pin ALU aluSignals[0] -pin CONTROLUNIT opcode[0] -pin INSTRUCTIONFETCH opcode[0]
load net opcode_top[1] -attr @rip opcode[1] -pin ALU aluSignals[1] -pin CONTROLUNIT opcode[1] -pin INSTRUCTIONFETCH opcode[1]
load net opcode_top[2] -attr @rip opcode[2] -pin ALU aluSignals[2] -pin CONTROLUNIT opcode[2] -pin INSTRUCTIONFETCH opcode[2]
load net opcode_top[3] -attr @rip opcode[3] -pin ALU aluSignals[3] -pin CONTROLUNIT opcode[3] -pin INSTRUCTIONFETCH opcode[3]
load net opcode_top[4] -attr @rip opcode[4] -pin ALU aluSignals[4] -pin CONTROLUNIT opcode[4] -pin INSTRUCTIONFETCH opcode[4]
load net overflow_in_top -pin ALU overflow -pin FLAGREGISTER overflow_in
netloc overflow_in_top 1 0 12 60 770 NJ 770 NJ 770 NJ 770 1360J 750 NJ 750 NJ 750 NJ 750 3070J 730 NJ 730 NJ 730 4080
load net pcplus4_top[0] -attr @rip pcplus4[0] -pin MUX4TO1 i2[0] -pin PC pcplus4[0] -pin PCMUX i0[0]
load net pcplus4_top[10] -attr @rip pcplus4[10] -pin MUX4TO1 i2[10] -pin PC pcplus4[10] -pin PCMUX i0[10]
load net pcplus4_top[11] -attr @rip pcplus4[11] -pin MUX4TO1 i2[11] -pin PC pcplus4[11] -pin PCMUX i0[11]
load net pcplus4_top[12] -attr @rip pcplus4[12] -pin MUX4TO1 i2[12] -pin PC pcplus4[12] -pin PCMUX i0[12]
load net pcplus4_top[13] -attr @rip pcplus4[13] -pin MUX4TO1 i2[13] -pin PC pcplus4[13] -pin PCMUX i0[13]
load net pcplus4_top[14] -attr @rip pcplus4[14] -pin MUX4TO1 i2[14] -pin PC pcplus4[14] -pin PCMUX i0[14]
load net pcplus4_top[15] -attr @rip pcplus4[15] -pin MUX4TO1 i2[15] -pin PC pcplus4[15] -pin PCMUX i0[15]
load net pcplus4_top[16] -attr @rip pcplus4[16] -pin MUX4TO1 i2[16] -pin PC pcplus4[16] -pin PCMUX i0[16]
load net pcplus4_top[17] -attr @rip pcplus4[17] -pin MUX4TO1 i2[17] -pin PC pcplus4[17] -pin PCMUX i0[17]
load net pcplus4_top[18] -attr @rip pcplus4[18] -pin MUX4TO1 i2[18] -pin PC pcplus4[18] -pin PCMUX i0[18]
load net pcplus4_top[19] -attr @rip pcplus4[19] -pin MUX4TO1 i2[19] -pin PC pcplus4[19] -pin PCMUX i0[19]
load net pcplus4_top[1] -attr @rip pcplus4[1] -pin MUX4TO1 i2[1] -pin PC pcplus4[1] -pin PCMUX i0[1]
load net pcplus4_top[20] -attr @rip pcplus4[20] -pin MUX4TO1 i2[20] -pin PC pcplus4[20] -pin PCMUX i0[20]
load net pcplus4_top[21] -attr @rip pcplus4[21] -pin MUX4TO1 i2[21] -pin PC pcplus4[21] -pin PCMUX i0[21]
load net pcplus4_top[22] -attr @rip pcplus4[22] -pin MUX4TO1 i2[22] -pin PC pcplus4[22] -pin PCMUX i0[22]
load net pcplus4_top[23] -attr @rip pcplus4[23] -pin MUX4TO1 i2[23] -pin PC pcplus4[23] -pin PCMUX i0[23]
load net pcplus4_top[24] -attr @rip pcplus4[24] -pin MUX4TO1 i2[24] -pin PC pcplus4[24] -pin PCMUX i0[24]
load net pcplus4_top[25] -attr @rip pcplus4[25] -pin MUX4TO1 i2[25] -pin PC pcplus4[25] -pin PCMUX i0[25]
load net pcplus4_top[26] -attr @rip pcplus4[26] -pin MUX4TO1 i2[26] -pin PC pcplus4[26] -pin PCMUX i0[26]
load net pcplus4_top[27] -attr @rip pcplus4[27] -pin MUX4TO1 i2[27] -pin PC pcplus4[27] -pin PCMUX i0[27]
load net pcplus4_top[28] -attr @rip pcplus4[28] -pin MUX4TO1 i2[28] -pin PC pcplus4[28] -pin PCMUX i0[28]
load net pcplus4_top[29] -attr @rip pcplus4[29] -pin MUX4TO1 i2[29] -pin PC pcplus4[29] -pin PCMUX i0[29]
load net pcplus4_top[2] -attr @rip pcplus4[2] -pin MUX4TO1 i2[2] -pin PC pcplus4[2] -pin PCMUX i0[2]
load net pcplus4_top[30] -attr @rip pcplus4[30] -pin MUX4TO1 i2[30] -pin PC pcplus4[30] -pin PCMUX i0[30]
load net pcplus4_top[31] -attr @rip pcplus4[31] -pin MUX4TO1 i2[31] -pin PC pcplus4[31] -pin PCMUX i0[31]
load net pcplus4_top[3] -attr @rip pcplus4[3] -pin MUX4TO1 i2[3] -pin PC pcplus4[3] -pin PCMUX i0[3]
load net pcplus4_top[4] -attr @rip pcplus4[4] -pin MUX4TO1 i2[4] -pin PC pcplus4[4] -pin PCMUX i0[4]
load net pcplus4_top[5] -attr @rip pcplus4[5] -pin MUX4TO1 i2[5] -pin PC pcplus4[5] -pin PCMUX i0[5]
load net pcplus4_top[6] -attr @rip pcplus4[6] -pin MUX4TO1 i2[6] -pin PC pcplus4[6] -pin PCMUX i0[6]
load net pcplus4_top[7] -attr @rip pcplus4[7] -pin MUX4TO1 i2[7] -pin PC pcplus4[7] -pin PCMUX i0[7]
load net pcplus4_top[8] -attr @rip pcplus4[8] -pin MUX4TO1 i2[8] -pin PC pcplus4[8] -pin PCMUX i0[8]
load net pcplus4_top[9] -attr @rip pcplus4[9] -pin MUX4TO1 i2[9] -pin PC pcplus4[9] -pin PCMUX i0[9]
load net ra_top[0] -attr @rip ra[0] -pin INSTRUCTIONFETCH ra[0] -pin MUX2 i1[0] -pin MUX3 i1[0]
load net ra_top[1] -attr @rip ra[1] -pin INSTRUCTIONFETCH ra[1] -pin MUX2 i1[1] -pin MUX3 i1[1]
load net ra_top[2] -attr @rip ra[2] -pin INSTRUCTIONFETCH ra[2] -pin MUX2 i1[2] -pin MUX3 i1[2]
load net ra_top[3] -attr @rip ra[3] -pin INSTRUCTIONFETCH ra[3] -pin MUX2 i1[3] -pin MUX3 i1[3]
load net rd_top[0] -attr @rip rd[0] -pin INSTRUCTIONFETCH rd[0] -pin MUX1 i1[0] -pin MUX3 i0[0]
load net rd_top[1] -attr @rip rd[1] -pin INSTRUCTIONFETCH rd[1] -pin MUX1 i1[1] -pin MUX3 i0[1]
load net rd_top[2] -attr @rip rd[2] -pin INSTRUCTIONFETCH rd[2] -pin MUX1 i1[2] -pin MUX3 i0[2]
load net rd_top[3] -attr @rip rd[3] -pin INSTRUCTIONFETCH rd[3] -pin MUX1 i1[3] -pin MUX3 i0[3]
load net read_address_top[0] -attr @rip address[0] -pin DATAMEMORY read_address[0] -pin MEMORYUNIT address[0]
load net read_address_top[10] -attr @rip address[10] -pin DATAMEMORY read_address[10] -pin MEMORYUNIT address[10]
load net read_address_top[11] -attr @rip address[11] -pin DATAMEMORY read_address[11] -pin MEMORYUNIT address[11]
load net read_address_top[12] -attr @rip address[12] -pin DATAMEMORY read_address[12] -pin MEMORYUNIT address[12]
load net read_address_top[13] -attr @rip address[13] -pin DATAMEMORY read_address[13] -pin MEMORYUNIT address[13]
load net read_address_top[14] -attr @rip address[14] -pin DATAMEMORY read_address[14] -pin MEMORYUNIT address[14]
load net read_address_top[15] -attr @rip address[15] -pin DATAMEMORY read_address[15] -pin MEMORYUNIT address[15]
load net read_address_top[16] -attr @rip address[16] -pin DATAMEMORY read_address[16] -pin MEMORYUNIT address[16]
load net read_address_top[17] -attr @rip address[17] -pin DATAMEMORY read_address[17] -pin MEMORYUNIT address[17]
load net read_address_top[18] -attr @rip address[18] -pin DATAMEMORY read_address[18] -pin MEMORYUNIT address[18]
load net read_address_top[19] -attr @rip address[19] -pin DATAMEMORY read_address[19] -pin MEMORYUNIT address[19]
load net read_address_top[1] -attr @rip address[1] -pin DATAMEMORY read_address[1] -pin MEMORYUNIT address[1]
load net read_address_top[20] -attr @rip address[20] -pin DATAMEMORY read_address[20] -pin MEMORYUNIT address[20]
load net read_address_top[21] -attr @rip address[21] -pin DATAMEMORY read_address[21] -pin MEMORYUNIT address[21]
load net read_address_top[22] -attr @rip address[22] -pin DATAMEMORY read_address[22] -pin MEMORYUNIT address[22]
load net read_address_top[23] -attr @rip address[23] -pin DATAMEMORY read_address[23] -pin MEMORYUNIT address[23]
load net read_address_top[24] -attr @rip address[24] -pin DATAMEMORY read_address[24] -pin MEMORYUNIT address[24]
load net read_address_top[25] -attr @rip address[25] -pin DATAMEMORY read_address[25] -pin MEMORYUNIT address[25]
load net read_address_top[26] -attr @rip address[26] -pin DATAMEMORY read_address[26] -pin MEMORYUNIT address[26]
load net read_address_top[27] -attr @rip address[27] -pin DATAMEMORY read_address[27] -pin MEMORYUNIT address[27]
load net read_address_top[28] -attr @rip address[28] -pin DATAMEMORY read_address[28] -pin MEMORYUNIT address[28]
load net read_address_top[29] -attr @rip address[29] -pin DATAMEMORY read_address[29] -pin MEMORYUNIT address[29]
load net read_address_top[2] -attr @rip address[2] -pin DATAMEMORY read_address[2] -pin MEMORYUNIT address[2]
load net read_address_top[30] -attr @rip address[30] -pin DATAMEMORY read_address[30] -pin MEMORYUNIT address[30]
load net read_address_top[31] -attr @rip address[31] -pin DATAMEMORY read_address[31] -pin MEMORYUNIT address[31]
load net read_address_top[3] -attr @rip address[3] -pin DATAMEMORY read_address[3] -pin MEMORYUNIT address[3]
load net read_address_top[4] -attr @rip address[4] -pin DATAMEMORY read_address[4] -pin MEMORYUNIT address[4]
load net read_address_top[5] -attr @rip address[5] -pin DATAMEMORY read_address[5] -pin MEMORYUNIT address[5]
load net read_address_top[6] -attr @rip address[6] -pin DATAMEMORY read_address[6] -pin MEMORYUNIT address[6]
load net read_address_top[7] -attr @rip address[7] -pin DATAMEMORY read_address[7] -pin MEMORYUNIT address[7]
load net read_address_top[8] -attr @rip address[8] -pin DATAMEMORY read_address[8] -pin MEMORYUNIT address[8]
load net read_address_top[9] -attr @rip address[9] -pin DATAMEMORY read_address[9] -pin MEMORYUNIT address[9]
load net reset -pin BRANCHUNIT reset -pin CONTROLUNIT reset -pin DATAMEMORY reset -pin FLAGREGISTER reset -pin INSTRUCTIONFETCH reset -pin INSTRUCTIONMEMORY reset -pin MEMORYUNIT reset -pin PC reset -pin REGISTERFILE reset -port reset
netloc reset 1 0 10 20 570 440 730 NJ 730 1070 850 1340 930 1730 490 2050 250 2670 410 NJ 410 3380
load net result_top[0] -attr @rip result[0] -pin ALU result[0] -pin MEMORYUNIT result[0] -pin MUX4TO1 i0[0]
load net result_top[10] -attr @rip result[10] -pin ALU result[10] -pin MEMORYUNIT result[10] -pin MUX4TO1 i0[10]
load net result_top[11] -attr @rip result[11] -pin ALU result[11] -pin MEMORYUNIT result[11] -pin MUX4TO1 i0[11]
load net result_top[12] -attr @rip result[12] -pin ALU result[12] -pin MEMORYUNIT result[12] -pin MUX4TO1 i0[12]
load net result_top[13] -attr @rip result[13] -pin ALU result[13] -pin MEMORYUNIT result[13] -pin MUX4TO1 i0[13]
load net result_top[14] -attr @rip result[14] -pin ALU result[14] -pin MEMORYUNIT result[14] -pin MUX4TO1 i0[14]
load net result_top[15] -attr @rip result[15] -pin ALU result[15] -pin MEMORYUNIT result[15] -pin MUX4TO1 i0[15]
load net result_top[16] -attr @rip result[16] -pin ALU result[16] -pin MEMORYUNIT result[16] -pin MUX4TO1 i0[16]
load net result_top[17] -attr @rip result[17] -pin ALU result[17] -pin MEMORYUNIT result[17] -pin MUX4TO1 i0[17]
load net result_top[18] -attr @rip result[18] -pin ALU result[18] -pin MEMORYUNIT result[18] -pin MUX4TO1 i0[18]
load net result_top[19] -attr @rip result[19] -pin ALU result[19] -pin MEMORYUNIT result[19] -pin MUX4TO1 i0[19]
load net result_top[1] -attr @rip result[1] -pin ALU result[1] -pin MEMORYUNIT result[1] -pin MUX4TO1 i0[1]
load net result_top[20] -attr @rip result[20] -pin ALU result[20] -pin MEMORYUNIT result[20] -pin MUX4TO1 i0[20]
load net result_top[21] -attr @rip result[21] -pin ALU result[21] -pin MEMORYUNIT result[21] -pin MUX4TO1 i0[21]
load net result_top[22] -attr @rip result[22] -pin ALU result[22] -pin MEMORYUNIT result[22] -pin MUX4TO1 i0[22]
load net result_top[23] -attr @rip result[23] -pin ALU result[23] -pin MEMORYUNIT result[23] -pin MUX4TO1 i0[23]
load net result_top[24] -attr @rip result[24] -pin ALU result[24] -pin MEMORYUNIT result[24] -pin MUX4TO1 i0[24]
load net result_top[25] -attr @rip result[25] -pin ALU result[25] -pin MEMORYUNIT result[25] -pin MUX4TO1 i0[25]
load net result_top[26] -attr @rip result[26] -pin ALU result[26] -pin MEMORYUNIT result[26] -pin MUX4TO1 i0[26]
load net result_top[27] -attr @rip result[27] -pin ALU result[27] -pin MEMORYUNIT result[27] -pin MUX4TO1 i0[27]
load net result_top[28] -attr @rip result[28] -pin ALU result[28] -pin MEMORYUNIT result[28] -pin MUX4TO1 i0[28]
load net result_top[29] -attr @rip result[29] -pin ALU result[29] -pin MEMORYUNIT result[29] -pin MUX4TO1 i0[29]
load net result_top[2] -attr @rip result[2] -pin ALU result[2] -pin MEMORYUNIT result[2] -pin MUX4TO1 i0[2]
load net result_top[30] -attr @rip result[30] -pin ALU result[30] -pin MEMORYUNIT result[30] -pin MUX4TO1 i0[30]
load net result_top[31] -attr @rip result[31] -pin ALU result[31] -pin MEMORYUNIT result[31] -pin MUX4TO1 i0[31]
load net result_top[3] -attr @rip result[3] -pin ALU result[3] -pin MEMORYUNIT result[3] -pin MUX4TO1 i0[3]
load net result_top[4] -attr @rip result[4] -pin ALU result[4] -pin MEMORYUNIT result[4] -pin MUX4TO1 i0[4]
load net result_top[5] -attr @rip result[5] -pin ALU result[5] -pin MEMORYUNIT result[5] -pin MUX4TO1 i0[5]
load net result_top[6] -attr @rip result[6] -pin ALU result[6] -pin MEMORYUNIT result[6] -pin MUX4TO1 i0[6]
load net result_top[7] -attr @rip result[7] -pin ALU result[7] -pin MEMORYUNIT result[7] -pin MUX4TO1 i0[7]
load net result_top[8] -attr @rip result[8] -pin ALU result[8] -pin MEMORYUNIT result[8] -pin MUX4TO1 i0[8]
load net result_top[9] -attr @rip result[9] -pin ALU result[9] -pin MEMORYUNIT result[9] -pin MUX4TO1 i0[9]
load net rs1_top[0] -attr @rip rs1[0] -pin INSTRUCTIONFETCH rs1[0] -pin MUX2 i0[0]
load net rs1_top[1] -attr @rip rs1[1] -pin INSTRUCTIONFETCH rs1[1] -pin MUX2 i0[1]
load net rs1_top[2] -attr @rip rs1[2] -pin INSTRUCTIONFETCH rs1[2] -pin MUX2 i0[2]
load net rs1_top[3] -attr @rip rs1[3] -pin INSTRUCTIONFETCH rs1[3] -pin MUX2 i0[3]
load net rs2_top[0] -attr @rip rs2[0] -pin INSTRUCTIONFETCH rs2[0] -pin MUX1 i0[0]
load net rs2_top[1] -attr @rip rs2[1] -pin INSTRUCTIONFETCH rs2[1] -pin MUX1 i0[1]
load net rs2_top[2] -attr @rip rs2[2] -pin INSTRUCTIONFETCH rs2[2] -pin MUX1 i0[2]
load net rs2_top[3] -attr @rip rs2[3] -pin INSTRUCTIONFETCH rs2[3] -pin MUX1 i0[3]
load net sign_in_top -pin ALU sign -pin FLAGREGISTER sign_in
netloc sign_in_top 1 0 12 40 790 NJ 790 NJ 790 NJ 790 1400J 770 NJ 770 NJ 770 NJ 770 NJ 770 NJ 770 NJ 770 4040
load net source_top[0] -attr @rip ldResult[0] -pin MEMORYUNIT ldResult[0] -pin MUX4TO1 i1[0]
load net source_top[10] -attr @rip ldResult[10] -pin MEMORYUNIT ldResult[10] -pin MUX4TO1 i1[10]
load net source_top[11] -attr @rip ldResult[11] -pin MEMORYUNIT ldResult[11] -pin MUX4TO1 i1[11]
load net source_top[12] -attr @rip ldResult[12] -pin MEMORYUNIT ldResult[12] -pin MUX4TO1 i1[12]
load net source_top[13] -attr @rip ldResult[13] -pin MEMORYUNIT ldResult[13] -pin MUX4TO1 i1[13]
load net source_top[14] -attr @rip ldResult[14] -pin MEMORYUNIT ldResult[14] -pin MUX4TO1 i1[14]
load net source_top[15] -attr @rip ldResult[15] -pin MEMORYUNIT ldResult[15] -pin MUX4TO1 i1[15]
load net source_top[16] -attr @rip ldResult[16] -pin MEMORYUNIT ldResult[16] -pin MUX4TO1 i1[16]
load net source_top[17] -attr @rip ldResult[17] -pin MEMORYUNIT ldResult[17] -pin MUX4TO1 i1[17]
load net source_top[18] -attr @rip ldResult[18] -pin MEMORYUNIT ldResult[18] -pin MUX4TO1 i1[18]
load net source_top[19] -attr @rip ldResult[19] -pin MEMORYUNIT ldResult[19] -pin MUX4TO1 i1[19]
load net source_top[1] -attr @rip ldResult[1] -pin MEMORYUNIT ldResult[1] -pin MUX4TO1 i1[1]
load net source_top[20] -attr @rip ldResult[20] -pin MEMORYUNIT ldResult[20] -pin MUX4TO1 i1[20]
load net source_top[21] -attr @rip ldResult[21] -pin MEMORYUNIT ldResult[21] -pin MUX4TO1 i1[21]
load net source_top[22] -attr @rip ldResult[22] -pin MEMORYUNIT ldResult[22] -pin MUX4TO1 i1[22]
load net source_top[23] -attr @rip ldResult[23] -pin MEMORYUNIT ldResult[23] -pin MUX4TO1 i1[23]
load net source_top[24] -attr @rip ldResult[24] -pin MEMORYUNIT ldResult[24] -pin MUX4TO1 i1[24]
load net source_top[25] -attr @rip ldResult[25] -pin MEMORYUNIT ldResult[25] -pin MUX4TO1 i1[25]
load net source_top[26] -attr @rip ldResult[26] -pin MEMORYUNIT ldResult[26] -pin MUX4TO1 i1[26]
load net source_top[27] -attr @rip ldResult[27] -pin MEMORYUNIT ldResult[27] -pin MUX4TO1 i1[27]
load net source_top[28] -attr @rip ldResult[28] -pin MEMORYUNIT ldResult[28] -pin MUX4TO1 i1[28]
load net source_top[29] -attr @rip ldResult[29] -pin MEMORYUNIT ldResult[29] -pin MUX4TO1 i1[29]
load net source_top[2] -attr @rip ldResult[2] -pin MEMORYUNIT ldResult[2] -pin MUX4TO1 i1[2]
load net source_top[30] -attr @rip ldResult[30] -pin MEMORYUNIT ldResult[30] -pin MUX4TO1 i1[30]
load net source_top[31] -attr @rip ldResult[31] -pin MEMORYUNIT ldResult[31] -pin MUX4TO1 i1[31]
load net source_top[3] -attr @rip ldResult[3] -pin MEMORYUNIT ldResult[3] -pin MUX4TO1 i1[3]
load net source_top[4] -attr @rip ldResult[4] -pin MEMORYUNIT ldResult[4] -pin MUX4TO1 i1[4]
load net source_top[5] -attr @rip ldResult[5] -pin MEMORYUNIT ldResult[5] -pin MUX4TO1 i1[5]
load net source_top[6] -attr @rip ldResult[6] -pin MEMORYUNIT ldResult[6] -pin MUX4TO1 i1[6]
load net source_top[7] -attr @rip ldResult[7] -pin MEMORYUNIT ldResult[7] -pin MUX4TO1 i1[7]
load net source_top[8] -attr @rip ldResult[8] -pin MEMORYUNIT ldResult[8] -pin MUX4TO1 i1[8]
load net source_top[9] -attr @rip ldResult[9] -pin MEMORYUNIT ldResult[9] -pin MUX4TO1 i1[9]
load net write_data_top[0] -attr @rip writeData[0] -pin DATAMEMORY Write_data[0] -pin MEMORYUNIT writeData[0]
load net write_data_top[10] -attr @rip writeData[10] -pin DATAMEMORY Write_data[10] -pin MEMORYUNIT writeData[10]
load net write_data_top[11] -attr @rip writeData[11] -pin DATAMEMORY Write_data[11] -pin MEMORYUNIT writeData[11]
load net write_data_top[12] -attr @rip writeData[12] -pin DATAMEMORY Write_data[12] -pin MEMORYUNIT writeData[12]
load net write_data_top[13] -attr @rip writeData[13] -pin DATAMEMORY Write_data[13] -pin MEMORYUNIT writeData[13]
load net write_data_top[14] -attr @rip writeData[14] -pin DATAMEMORY Write_data[14] -pin MEMORYUNIT writeData[14]
load net write_data_top[15] -attr @rip writeData[15] -pin DATAMEMORY Write_data[15] -pin MEMORYUNIT writeData[15]
load net write_data_top[16] -attr @rip writeData[16] -pin DATAMEMORY Write_data[16] -pin MEMORYUNIT writeData[16]
load net write_data_top[17] -attr @rip writeData[17] -pin DATAMEMORY Write_data[17] -pin MEMORYUNIT writeData[17]
load net write_data_top[18] -attr @rip writeData[18] -pin DATAMEMORY Write_data[18] -pin MEMORYUNIT writeData[18]
load net write_data_top[19] -attr @rip writeData[19] -pin DATAMEMORY Write_data[19] -pin MEMORYUNIT writeData[19]
load net write_data_top[1] -attr @rip writeData[1] -pin DATAMEMORY Write_data[1] -pin MEMORYUNIT writeData[1]
load net write_data_top[20] -attr @rip writeData[20] -pin DATAMEMORY Write_data[20] -pin MEMORYUNIT writeData[20]
load net write_data_top[21] -attr @rip writeData[21] -pin DATAMEMORY Write_data[21] -pin MEMORYUNIT writeData[21]
load net write_data_top[22] -attr @rip writeData[22] -pin DATAMEMORY Write_data[22] -pin MEMORYUNIT writeData[22]
load net write_data_top[23] -attr @rip writeData[23] -pin DATAMEMORY Write_data[23] -pin MEMORYUNIT writeData[23]
load net write_data_top[24] -attr @rip writeData[24] -pin DATAMEMORY Write_data[24] -pin MEMORYUNIT writeData[24]
load net write_data_top[25] -attr @rip writeData[25] -pin DATAMEMORY Write_data[25] -pin MEMORYUNIT writeData[25]
load net write_data_top[26] -attr @rip writeData[26] -pin DATAMEMORY Write_data[26] -pin MEMORYUNIT writeData[26]
load net write_data_top[27] -attr @rip writeData[27] -pin DATAMEMORY Write_data[27] -pin MEMORYUNIT writeData[27]
load net write_data_top[28] -attr @rip writeData[28] -pin DATAMEMORY Write_data[28] -pin MEMORYUNIT writeData[28]
load net write_data_top[29] -attr @rip writeData[29] -pin DATAMEMORY Write_data[29] -pin MEMORYUNIT writeData[29]
load net write_data_top[2] -attr @rip writeData[2] -pin DATAMEMORY Write_data[2] -pin MEMORYUNIT writeData[2]
load net write_data_top[30] -attr @rip writeData[30] -pin DATAMEMORY Write_data[30] -pin MEMORYUNIT writeData[30]
load net write_data_top[31] -attr @rip writeData[31] -pin DATAMEMORY Write_data[31] -pin MEMORYUNIT writeData[31]
load net write_data_top[3] -attr @rip writeData[3] -pin DATAMEMORY Write_data[3] -pin MEMORYUNIT writeData[3]
load net write_data_top[4] -attr @rip writeData[4] -pin DATAMEMORY Write_data[4] -pin MEMORYUNIT writeData[4]
load net write_data_top[5] -attr @rip writeData[5] -pin DATAMEMORY Write_data[5] -pin MEMORYUNIT writeData[5]
load net write_data_top[6] -attr @rip writeData[6] -pin DATAMEMORY Write_data[6] -pin MEMORYUNIT writeData[6]
load net write_data_top[7] -attr @rip writeData[7] -pin DATAMEMORY Write_data[7] -pin MEMORYUNIT writeData[7]
load net write_data_top[8] -attr @rip writeData[8] -pin DATAMEMORY Write_data[8] -pin MEMORYUNIT writeData[8]
load net write_data_top[9] -attr @rip writeData[9] -pin DATAMEMORY Write_data[9] -pin MEMORYUNIT writeData[9]
load net writedata_top[0] -attr @rip o[0] -pin MUX4TO1 o[0] -pin REGISTERFILE writedata[0]
load net writedata_top[10] -attr @rip o[10] -pin MUX4TO1 o[10] -pin REGISTERFILE writedata[10]
load net writedata_top[11] -attr @rip o[11] -pin MUX4TO1 o[11] -pin REGISTERFILE writedata[11]
load net writedata_top[12] -attr @rip o[12] -pin MUX4TO1 o[12] -pin REGISTERFILE writedata[12]
load net writedata_top[13] -attr @rip o[13] -pin MUX4TO1 o[13] -pin REGISTERFILE writedata[13]
load net writedata_top[14] -attr @rip o[14] -pin MUX4TO1 o[14] -pin REGISTERFILE writedata[14]
load net writedata_top[15] -attr @rip o[15] -pin MUX4TO1 o[15] -pin REGISTERFILE writedata[15]
load net writedata_top[16] -attr @rip o[16] -pin MUX4TO1 o[16] -pin REGISTERFILE writedata[16]
load net writedata_top[17] -attr @rip o[17] -pin MUX4TO1 o[17] -pin REGISTERFILE writedata[17]
load net writedata_top[18] -attr @rip o[18] -pin MUX4TO1 o[18] -pin REGISTERFILE writedata[18]
load net writedata_top[19] -attr @rip o[19] -pin MUX4TO1 o[19] -pin REGISTERFILE writedata[19]
load net writedata_top[1] -attr @rip o[1] -pin MUX4TO1 o[1] -pin REGISTERFILE writedata[1]
load net writedata_top[20] -attr @rip o[20] -pin MUX4TO1 o[20] -pin REGISTERFILE writedata[20]
load net writedata_top[21] -attr @rip o[21] -pin MUX4TO1 o[21] -pin REGISTERFILE writedata[21]
load net writedata_top[22] -attr @rip o[22] -pin MUX4TO1 o[22] -pin REGISTERFILE writedata[22]
load net writedata_top[23] -attr @rip o[23] -pin MUX4TO1 o[23] -pin REGISTERFILE writedata[23]
load net writedata_top[24] -attr @rip o[24] -pin MUX4TO1 o[24] -pin REGISTERFILE writedata[24]
load net writedata_top[25] -attr @rip o[25] -pin MUX4TO1 o[25] -pin REGISTERFILE writedata[25]
load net writedata_top[26] -attr @rip o[26] -pin MUX4TO1 o[26] -pin REGISTERFILE writedata[26]
load net writedata_top[27] -attr @rip o[27] -pin MUX4TO1 o[27] -pin REGISTERFILE writedata[27]
load net writedata_top[28] -attr @rip o[28] -pin MUX4TO1 o[28] -pin REGISTERFILE writedata[28]
load net writedata_top[29] -attr @rip o[29] -pin MUX4TO1 o[29] -pin REGISTERFILE writedata[29]
load net writedata_top[2] -attr @rip o[2] -pin MUX4TO1 o[2] -pin REGISTERFILE writedata[2]
load net writedata_top[30] -attr @rip o[30] -pin MUX4TO1 o[30] -pin REGISTERFILE writedata[30]
load net writedata_top[31] -attr @rip o[31] -pin MUX4TO1 o[31] -pin REGISTERFILE writedata[31]
load net writedata_top[3] -attr @rip o[3] -pin MUX4TO1 o[3] -pin REGISTERFILE writedata[3]
load net writedata_top[4] -attr @rip o[4] -pin MUX4TO1 o[4] -pin REGISTERFILE writedata[4]
load net writedata_top[5] -attr @rip o[5] -pin MUX4TO1 o[5] -pin REGISTERFILE writedata[5]
load net writedata_top[6] -attr @rip o[6] -pin MUX4TO1 o[6] -pin REGISTERFILE writedata[6]
load net writedata_top[7] -attr @rip o[7] -pin MUX4TO1 o[7] -pin REGISTERFILE writedata[7]
load net writedata_top[8] -attr @rip o[8] -pin MUX4TO1 o[8] -pin REGISTERFILE writedata[8]
load net writedata_top[9] -attr @rip o[9] -pin MUX4TO1 o[9] -pin REGISTERFILE writedata[9]
load netBundle @result_top 32 result_top[31] result_top[30] result_top[29] result_top[28] result_top[27] result_top[26] result_top[25] result_top[24] result_top[23] result_top[22] result_top[21] result_top[20] result_top[19] result_top[18] result_top[17] result_top[16] result_top[15] result_top[14] result_top[13] result_top[12] result_top[11] result_top[10] result_top[9] result_top[8] result_top[7] result_top[6] result_top[5] result_top[4] result_top[3] result_top[2] result_top[1] result_top[0] -autobundled
netbloc @result_top 1 7 5 2710 310 3090 750 NJ 750 NJ 750 4060
load netBundle @branchaddr_top 32 branchaddr_top[31] branchaddr_top[30] branchaddr_top[29] branchaddr_top[28] branchaddr_top[27] branchaddr_top[26] branchaddr_top[25] branchaddr_top[24] branchaddr_top[23] branchaddr_top[22] branchaddr_top[21] branchaddr_top[20] branchaddr_top[19] branchaddr_top[18] branchaddr_top[17] branchaddr_top[16] branchaddr_top[15] branchaddr_top[14] branchaddr_top[13] branchaddr_top[12] branchaddr_top[11] branchaddr_top[10] branchaddr_top[9] branchaddr_top[8] branchaddr_top[7] branchaddr_top[6] branchaddr_top[5] branchaddr_top[4] branchaddr_top[3] branchaddr_top[2] branchaddr_top[1] branchaddr_top[0] -autobundled
netbloc @branchaddr_top 1 2 1 840 650n
load netBundle @memdataout_top 32 memdataout_top[31] memdataout_top[30] memdataout_top[29] memdataout_top[28] memdataout_top[27] memdataout_top[26] memdataout_top[25] memdataout_top[24] memdataout_top[23] memdataout_top[22] memdataout_top[21] memdataout_top[20] memdataout_top[19] memdataout_top[18] memdataout_top[17] memdataout_top[16] memdataout_top[15] memdataout_top[14] memdataout_top[13] memdataout_top[12] memdataout_top[11] memdataout_top[10] memdataout_top[9] memdataout_top[8] memdataout_top[7] memdataout_top[6] memdataout_top[5] memdataout_top[4] memdataout_top[3] memdataout_top[2] memdataout_top[1] memdataout_top[0] -autobundled
netbloc @memdataout_top 1 7 1 2510 130n
load netBundle @branchtarget_top 32 branchtarget_top[31] branchtarget_top[30] branchtarget_top[29] branchtarget_top[28] branchtarget_top[27] branchtarget_top[26] branchtarget_top[25] branchtarget_top[24] branchtarget_top[23] branchtarget_top[22] branchtarget_top[21] branchtarget_top[20] branchtarget_top[19] branchtarget_top[18] branchtarget_top[17] branchtarget_top[16] branchtarget_top[15] branchtarget_top[14] branchtarget_top[13] branchtarget_top[12] branchtarget_top[11] branchtarget_top[10] branchtarget_top[9] branchtarget_top[8] branchtarget_top[7] branchtarget_top[6] branchtarget_top[5] branchtarget_top[4] branchtarget_top[3] branchtarget_top[2] branchtarget_top[1] branchtarget_top[0] -autobundled
netbloc @branchtarget_top 1 1 1 460 870n
load netBundle @immx_top 32 immx_top[31] immx_top[30] immx_top[29] immx_top[28] immx_top[27] immx_top[26] immx_top[25] immx_top[24] immx_top[23] immx_top[22] immx_top[21] immx_top[20] immx_top[19] immx_top[18] immx_top[17] immx_top[16] immx_top[15] immx_top[14] immx_top[13] immx_top[12] immx_top[11] immx_top[10] immx_top[9] immx_top[8] immx_top[7] immx_top[6] immx_top[5] immx_top[4] immx_top[3] immx_top[2] immx_top[1] immx_top[0] -autobundled
netbloc @immx_top 1 1 9 NJ 990 NJ 990 NJ 990 NJ 990 NJ 990 2130J 950 NJ 950 NJ 950 3440
load netBundle @B_top 32 B_top[31] B_top[30] B_top[29] B_top[28] B_top[27] B_top[26] B_top[25] B_top[24] B_top[23] B_top[22] B_top[21] B_top[20] B_top[19] B_top[18] B_top[17] B_top[16] B_top[15] B_top[14] B_top[13] B_top[12] B_top[11] B_top[10] B_top[9] B_top[8] B_top[7] B_top[6] B_top[5] B_top[4] B_top[3] B_top[2] B_top[1] B_top[0] -autobundled
netbloc @B_top 1 10 1 3750 650n
load netBundle @opcode_top 5 opcode_top[4] opcode_top[3] opcode_top[2] opcode_top[1] opcode_top[0] -autobundled
netbloc @opcode_top 1 6 5 2030 790 NJ 790 NJ 790 NJ 790 3770
load netBundle @ra_top 4 ra_top[3] ra_top[2] ra_top[1] ra_top[0] -autobundled
netbloc @ra_top 1 6 3 N 870 NJ 870 3010
load netBundle @rd_top 4 rd_top[3] rd_top[2] rd_top[1] rd_top[0] -autobundled
netbloc @rd_top 1 6 3 2110 970 NJ 970 3110
load netBundle @rs1_top 4 rs1_top[3] rs1_top[2] rs1_top[1] rs1_top[0] -autobundled
netbloc @rs1_top 1 6 3 2070 850 NJ 850 NJ
load netBundle @rs2_top 4 rs2_top[3] rs2_top[2] rs2_top[1] rs2_top[0] -autobundled
netbloc @rs2_top 1 6 3 2050 650 NJ 650 3010J
load netBundle @instruction_top 32 instruction_top[31] instruction_top[30] instruction_top[29] instruction_top[28] instruction_top[27] instruction_top[26] instruction_top[25] instruction_top[24] instruction_top[23] instruction_top[22] instruction_top[21] instruction_top[20] instruction_top[19] instruction_top[18] instruction_top[17] instruction_top[16] instruction_top[15] instruction_top[14] instruction_top[13] instruction_top[12] instruction_top[11] instruction_top[10] instruction_top[9] instruction_top[8] instruction_top[7] instruction_top[6] instruction_top[5] instruction_top[4] instruction_top[3] instruction_top[2] instruction_top[1] instruction_top[0] -autobundled
netbloc @instruction_top 1 0 6 40 910 380J 950 NJ 950 NJ 950 NJ 950 1710
load netBundle @read_address_top 32 read_address_top[31] read_address_top[30] read_address_top[29] read_address_top[28] read_address_top[27] read_address_top[26] read_address_top[25] read_address_top[24] read_address_top[23] read_address_top[22] read_address_top[21] read_address_top[20] read_address_top[19] read_address_top[18] read_address_top[17] read_address_top[16] read_address_top[15] read_address_top[14] read_address_top[13] read_address_top[12] read_address_top[11] read_address_top[10] read_address_top[9] read_address_top[8] read_address_top[7] read_address_top[6] read_address_top[5] read_address_top[4] read_address_top[3] read_address_top[2] read_address_top[1] read_address_top[0] -autobundled
netbloc @read_address_top 1 6 3 2130 270 NJ 270 3090
load netBundle @source_top 32 source_top[31] source_top[30] source_top[29] source_top[28] source_top[27] source_top[26] source_top[25] source_top[24] source_top[23] source_top[22] source_top[21] source_top[20] source_top[19] source_top[18] source_top[17] source_top[16] source_top[15] source_top[14] source_top[13] source_top[12] source_top[11] source_top[10] source_top[9] source_top[8] source_top[7] source_top[6] source_top[5] source_top[4] source_top[3] source_top[2] source_top[1] source_top[0] -autobundled
netbloc @source_top 1 8 1 3110 190n
load netBundle @write_data_top 32 write_data_top[31] write_data_top[30] write_data_top[29] write_data_top[28] write_data_top[27] write_data_top[26] write_data_top[25] write_data_top[24] write_data_top[23] write_data_top[22] write_data_top[21] write_data_top[20] write_data_top[19] write_data_top[18] write_data_top[17] write_data_top[16] write_data_top[15] write_data_top[14] write_data_top[13] write_data_top[12] write_data_top[11] write_data_top[10] write_data_top[9] write_data_top[8] write_data_top[7] write_data_top[6] write_data_top[5] write_data_top[4] write_data_top[3] write_data_top[2] write_data_top[1] write_data_top[0] -autobundled
netbloc @write_data_top 1 6 3 2070 290 NJ 290 3010
load netBundle @mux1_top 4 mux1_top[3] mux1_top[2] mux1_top[1] mux1_top[0] -autobundled
netbloc @mux1_top 1 9 1 3320 570n
load netBundle @mux2_top 4 mux2_top[3] mux2_top[2] mux2_top[1] mux2_top[0] -autobundled
netbloc @mux2_top 1 9 1 3360 590n
load netBundle @mux3_top 4 mux3_top[3] mux3_top[2] mux3_top[1] mux3_top[0] -autobundled
netbloc @mux3_top 1 9 1 3420 610n
load netBundle @writedata_top 32 writedata_top[31] writedata_top[30] writedata_top[29] writedata_top[28] writedata_top[27] writedata_top[26] writedata_top[25] writedata_top[24] writedata_top[23] writedata_top[22] writedata_top[21] writedata_top[20] writedata_top[19] writedata_top[18] writedata_top[17] writedata_top[16] writedata_top[15] writedata_top[14] writedata_top[13] writedata_top[12] writedata_top[11] writedata_top[10] writedata_top[9] writedata_top[8] writedata_top[7] writedata_top[6] writedata_top[5] writedata_top[4] writedata_top[3] writedata_top[2] writedata_top[1] writedata_top[0] -autobundled
netbloc @writedata_top 1 9 1 3400 330n
load netBundle @addrout_top 32 addrout_top[31] addrout_top[30] addrout_top[29] addrout_top[28] addrout_top[27] addrout_top[26] addrout_top[25] addrout_top[24] addrout_top[23] addrout_top[22] addrout_top[21] addrout_top[20] addrout_top[19] addrout_top[18] addrout_top[17] addrout_top[16] addrout_top[15] addrout_top[14] addrout_top[13] addrout_top[12] addrout_top[11] addrout_top[10] addrout_top[9] addrout_top[8] addrout_top[7] addrout_top[6] addrout_top[5] addrout_top[4] addrout_top[3] addrout_top[2] addrout_top[1] addrout_top[0] -autobundled
netbloc @addrout_top 1 0 5 60 810 NJ 810 NJ 810 NJ 810 1380
load netBundle @pcplus4_top 32 pcplus4_top[31] pcplus4_top[30] pcplus4_top[29] pcplus4_top[28] pcplus4_top[27] pcplus4_top[26] pcplus4_top[25] pcplus4_top[24] pcplus4_top[23] pcplus4_top[22] pcplus4_top[21] pcplus4_top[20] pcplus4_top[19] pcplus4_top[18] pcplus4_top[17] pcplus4_top[16] pcplus4_top[15] pcplus4_top[14] pcplus4_top[13] pcplus4_top[12] pcplus4_top[11] pcplus4_top[10] pcplus4_top[9] pcplus4_top[8] pcplus4_top[7] pcplus4_top[6] pcplus4_top[5] pcplus4_top[4] pcplus4_top[3] pcplus4_top[2] pcplus4_top[1] pcplus4_top[0] -autobundled
netbloc @pcplus4_top 1 2 7 840 570 NJ 570 1340 310 NJ 310 NJ 310 2650J 330 NJ
load netBundle @addrin_top 32 addrin_top[31] addrin_top[30] addrin_top[29] addrin_top[28] addrin_top[27] addrin_top[26] addrin_top[25] addrin_top[24] addrin_top[23] addrin_top[22] addrin_top[21] addrin_top[20] addrin_top[19] addrin_top[18] addrin_top[17] addrin_top[16] addrin_top[15] addrin_top[14] addrin_top[13] addrin_top[12] addrin_top[11] addrin_top[10] addrin_top[9] addrin_top[8] addrin_top[7] addrin_top[6] addrin_top[5] addrin_top[4] addrin_top[3] addrin_top[2] addrin_top[1] addrin_top[0] -autobundled
netbloc @addrin_top 1 3 1 1050 650n
load netBundle @op1_top 32 op1_top[31] op1_top[30] op1_top[29] op1_top[28] op1_top[27] op1_top[26] op1_top[25] op1_top[24] op1_top[23] op1_top[22] op1_top[21] op1_top[20] op1_top[19] op1_top[18] op1_top[17] op1_top[16] op1_top[15] op1_top[14] op1_top[13] op1_top[12] op1_top[11] op1_top[10] op1_top[9] op1_top[8] op1_top[7] op1_top[6] op1_top[5] op1_top[4] op1_top[3] op1_top[2] op1_top[1] op1_top[0] -autobundled
netbloc @op1_top 1 1 10 500 750 NJ 750 NJ 750 1340J 730 NJ 730 NJ 730 NJ 730 3050J 710 NJ 710 3730
load netBundle @op2_top 32 op2_top[31] op2_top[30] op2_top[29] op2_top[28] op2_top[27] op2_top[26] op2_top[25] op2_top[24] op2_top[23] op2_top[22] op2_top[21] op2_top[20] op2_top[19] op2_top[18] op2_top[17] op2_top[16] op2_top[15] op2_top[14] op2_top[13] op2_top[12] op2_top[11] op2_top[10] op2_top[9] op2_top[8] op2_top[7] op2_top[6] op2_top[5] op2_top[4] op2_top[3] op2_top[2] op2_top[1] op2_top[0] -autobundled
netbloc @op2_top 1 7 4 2690 430 NJ 430 3340 690 3710
levelinfo -pg 1 0 180 590 920 1170 1530 1870 2270 2830 3190 3560 3880 4100
pagesize -pg 1 -db -bbox -sgen -80 0 4100 1090
show
fullfit
#
# initialize ictrl to current module riscv work:riscv:NOFILE
ictrl init topinfo |
