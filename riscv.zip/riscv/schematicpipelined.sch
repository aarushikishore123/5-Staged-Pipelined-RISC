# File saved with Nlview 7.8.0 2024-04-26 e1825d835c VDI=44 GEI=38 GUI=JA:21.0 threadsafe
# 
# non-default properties - (restore without -noprops)
property -colorscheme classic
property attrcolor #000000
property attrfontsize 8
property autobundle 1
property backgroundcolor #ffffff
property boxcolor0 #000000
property boxcolor1 #000000
property boxcolor2 #000000
property boxinstcolor #000000
property boxpincolor #000000
property buscolor #008000
property closeenough 5
property createnetattrdsp 2048
property decorate 1
property elidetext 40
property fillcolor1 #ffffcc
property fillcolor2 #dfebf8
property fillcolor3 #f0f0f0
property gatecellname 2
property instattrmax 30
property instdrag 15
property instorder 1
property marksize 12
property maxfontsize 15
property maxzoom 6.25
property netcolor #19b400
property objecthighlight0 #ff00ff
property objecthighlight1 #ffff00
property objecthighlight2 #00ff00
property objecthighlight3 #0095ff
property objecthighlight4 #8000ff
property objecthighlight5 #ffc800
property objecthighlight7 #00ffff
property objecthighlight8 #ff00ff
property objecthighlight9 #ccccff
property objecthighlight10 #0ead00
property objecthighlight11 #cefc00
property objecthighlight12 #9e2dbe
property objecthighlight13 #ba6a29
property objecthighlight14 #fc0188
property objecthighlight15 #02f990
property objecthighlight16 #f1b0fb
property objecthighlight17 #fec004
property objecthighlight18 #149bff
property objecthighlight19 #0000ff
property overlaycolor #19b400
property pbuscolor #000000
property pbusnamecolor #000000
property pinattrmax 20
property pinorder 2
property pinpermute 0
property portcolor #000000
property portnamecolor #000000
property ripindexfontsize 4
property rippercolor #000000
property rubberbandcolor #000000
property rubberbandfontsize 15
property selectattr 0
property selectionappearance 2
property selectioncolor #0000ff
property sheetheight 44
property sheetwidth 68
property showmarks 1
property shownetname 0
property showpagenumbers 1
property showripindex 1
property timelimit 1
#
module new riscv work:riscv:NOFILE -nosplit
load symbol alu work:alu:NOFILE HIERBOX pin E output.right pin GT output.right pin overflow output.right pin sign output.right pinBus A input.left [31:0] pinBus B input.left [31:0] pinBus aluSignals input.left [4:0] pinBus result output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol branchunit work:branchunit:NOFILE HIERBOX pin E input.left pin GT input.left pin clk input.left pin isBeq input.left pin isBgt input.left pin isBranchTaken output.right pin isUBranch input.left pin reset input.left boxcolor 1 fillcolor 2 minwidth 13%
load symbol addrmux work:abstract:NOFILE HIERBOX pin s0 input.left pinBus i0 input.left [31:0] pinBus i1 input.left [31:0] pinBus o output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol controlunit work:controlunit:NOFILE HIERBOX pin clk input.left pin isBeq output.right pin isBgt output.right pin isCall output.right pin isLd output.right pin isRet output.right pin isSt output.right pin isUBranch output.right pin isWb output.right pin reset input.left pinBus opcode input.left [4:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol datamemory work:datamemory:NOFILE HIERBOX pin MemRead input.left pin MemWrite input.left pin clk input.left pin reset input.left pinBus MemData_out output.right [31:0] pinBus Write_data input.left [31:0] pinBus read_address input.left [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol EXMA_regi work:EXMA_regi:NOFILE HIERBOX pin EXisCall input.left pin EXisLd input.left pin EXisSt input.left pin EXisWb input.left pin MAisCall output.right pin MAisLd output.right pin MAisSt output.right pin MAisWb output.right pin clk input.left pin reset input.left pinBus EXaddrout input.left [31:0] pinBus EXop2 input.left [31:0] pinBus EXra input.left [3:0] pinBus EXrd input.left [3:0] pinBus EXresult input.left [31:0] pinBus MAaddrout output.right [31:0] pinBus MAop2 output.right [31:0] pinBus MAra output.right [3:0] pinBus MArd output.right [3:0] pinBus MAresult output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol flagregister work:flagregister:NOFILE HIERBOX pin E output.right pin E_in input.left pin GT output.right pin GT_in input.left pin clk input.left pin overflow output.right pin overflow_in input.left pin reset input.left pin sign output.right pin sign_in input.left boxcolor 1 fillcolor 2 minwidth 13%
load symbol hazardunit work:hazardunit:NOFILE HIERBOX pin RegWriteM input.left pin RegWriteW input.left pin reset input.left pinBus ForwardAE output.right [1:0] pinBus ForwardBE output.right [1:0] pinBus RD_M input.left [4:0] pinBus RD_W input.left [4:0] pinBus Rs1_E input.left [4:0] pinBus Rs2_E input.left [4:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol IFOF_regi work:IFOF_regi:NOFILE HIERBOX pin IFisImmediate input.left pin OFisImmediate output.right pin clk input.left pin reset input.left pinBus IFaddrout input.left [31:0] pinBus IFinstruction input.left [31:0] pinBus IFopcode input.left [4:0] pinBus IFra input.left [3:0] pinBus IFrd input.left [3:0] pinBus IFrs1 input.left [3:0] pinBus IFrs2 input.left [3:0] pinBus OFaddrout output.right [31:0] pinBus OFinstruction output.right [31:0] pinBus OFopcode output.right [4:0] pinBus OFra output.right [3:0] pinBus OFrd output.right [3:0] pinBus OFrs1 output.right [3:0] pinBus OFrs2 output.right [3:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol immediatebranch work:immediatebranch:NOFILE HIERBOX pinBus addrout input.left [31:0] pinBus branchtarget output.right [31:0] pinBus immx output.right [31:0] pinBus instruction input.left [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol instructionfetch work:instructionfetch:NOFILE HIERBOX pin clk input.left pin isImmediate output.right pin reset input.left pinBus instruction input.left [31:0] pinBus opcode output.right [4:0] pinBus ra output.right [3:0] pinBus rd output.right [3:0] pinBus rs1 output.right [3:0] pinBus rs2 output.right [3:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol instructionmemory work:instructionmemory:NOFILE HIERBOX pin clk input.left pin reset input.left pinBus addrout input.left [31:0] pinBus instruction output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol MARW_regi work:MARW_regi:NOFILE HIERBOX pin MAisCall input.left pin MAisLd input.left pin MAisWb input.left pin RWisCall output.right pin RWisLd output.right pin RWisWb output.right pin clk input.left pin reset input.left pinBus MAaddrout input.left [31:0] pinBus MAinstruction input.left [31:0] pinBus MAldResult input.left [31:0] pinBus MAra input.left [3:0] pinBus MArd input.left [3:0] pinBus MAresult input.left [31:0] pinBus RWaddrout output.right [31:0] pinBus RWinstruction output.right [31:0] pinBus RWldResult output.right [31:0] pinBus RWra output.right [3:0] pinBus RWrd output.right [3:0] pinBus RWresult output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol memoryunit work:memoryunit:NOFILE HIERBOX pin MemRead output.right pin MemWrite output.right pin clk input.left pin isLd input.left pin isSt input.left pin reset input.left pinBus address output.right [31:0] pinBus ldResult output.right [31:0] pinBus mar output.right [31:0] pinBus mdr output.right [31:0] pinBus memData input.left [31:0] pinBus op2 input.left [31:0] pinBus result input.left [31:0] pinBus writeData output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol regmux work:regmux:NOFILE HIERBOX pin s0 input.left pinBus i0 input.left [3:0] pinBus i1 input.left [3:0] pinBus o output.right [3:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol regmux work:abstract:NOFILE HIERBOX pin s0 input.left pinBus i0 input.left [3:0] pinBus i1 input.left [3:0] pinBus o output.right [3:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol mux4to1 work:mux4to1:NOFILE HIERBOX pin s0 input.left pin s1 input.left pinBus i0 input.left [31:0] pinBus i1 input.left [31:0] pinBus i2 input.left [31:0] pinBus o output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol OFEX_regi work:OFEX_regi:NOFILE HIERBOX pin EXisBeq output.right pin EXisBgt output.right pin EXisCall output.right pin EXisLd output.right pin EXisRet output.right pin EXisSt output.right pin EXisUBranch output.right pin EXisWb output.right pin OFisBeq input.left pin OFisBgt input.left pin OFisCall input.left pin OFisLd input.left pin OFisRet input.left pin OFisSt input.left pin OFisUBranch input.left pin OFisWb input.left pin clk input.left pin reset input.left pinBus EXA output.right [31:0] pinBus EXB output.right [31:0] pinBus EXaddrout output.right [31:0] pinBus EXbranchtarget output.right [31:0] pinBus EXop2 output.right [31:0] pinBus EXopcode output.right [4:0] pinBus EXra output.right [3:0] pinBus EXrd output.right [3:0] pinBus OFA input.left [31:0] pinBus OFB input.left [31:0] pinBus OFaddrout input.left [31:0] pinBus OFbranchtarget input.left [31:0] pinBus OFop2 input.left [31:0] pinBus OFopcode input.left [4:0] pinBus OFra input.left [3:0] pinBus OFrd input.left [3:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol pc work:pc:NOFILE HIERBOX pin clk input.left pin reset input.left pinBus addrin input.left [31:0] pinBus addrout output.right [31:0] pinBus pcplus4 output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol pc work:abstract:NOFILE HIERBOX pin clk input.left pin reset input.left pinBus addrin input.left [31:0] pinBus addrout output.right [31:0] pinBus pcplus4 output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol addrmux work:addrmux:NOFILE HIERBOX pin s0 input.left pinBus i0 input.left [31:0] pinBus i1 input.left [31:0] pinBus o output.right [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load symbol registerfile work:registerfile:NOFILE HIERBOX pin clk input.left pin isWb input.left pin reset input.left pinBus mux1 input.left [3:0] pinBus mux2 input.left [3:0] pinBus mux3 input.left [3:0] pinBus op1 output.right [31:0] pinBus op2 output.right [31:0] pinBus writedata input.left [31:0] boxcolor 1 fillcolor 2 minwidth 13%
load port clk input -pg 1 -lvl 0 -x 0 -y 390
load port reset input -pg 1 -lvl 0 -x 0 -y 430
load inst ALU alu work:alu:NOFILE -autohide -attr @cell(#000000) alu -pinBusAttr A @name A[31:0] -pinBusAttr B @name B[31:0] -pinBusAttr aluSignals @name aluSignals[4:0] -pinBusAttr result @name result[31:0] -pg 1 -lvl 17 -x 6940 -y 410
load inst BRANCHUNIT branchunit work:branchunit:NOFILE -autohide -attr @cell(#000000) branchunit -pg 1 -lvl 2 -x 460 -y 560
load inst BRMUX addrmux work:abstract:NOFILE -autohide -attr @cell(#000000) addrmux -pinBusAttr i0 @name i0[31:0] -pinBusAttr i1 @name i1[31:0] -pinBusAttr o @name o[31:0] -pg 1 -lvl 2 -x 460 -y 120
load inst CONTROLUNIT controlunit work:controlunit:NOFILE -autohide -attr @cell(#000000) controlunit -pinBusAttr opcode @name opcode[4:0] -pg 1 -lvl 8 -x 2650 -y 360
load inst DATAMEMORY datamemory work:datamemory:NOFILE -autohide -attr @cell(#000000) datamemory -pinBusAttr MemData_out @name MemData_out[31:0] -pinBusAttr Write_data @name Write_data[31:0] -pinBusAttr read_address @name read_address[31:0] -pg 1 -lvl 9 -x 3100 -y 1630
load inst EXMA_REGI EXMA_regi work:EXMA_regi:NOFILE -autohide -attr @cell(#000000) EXMA_regi -pinBusAttr EXaddrout @name EXaddrout[31:0] -pinBusAttr EXop2 @name EXop2[31:0] -pinBusAttr EXra @name EXra[3:0] -pinBusAttr EXrd @name EXrd[3:0] -pinBusAttr EXresult @name EXresult[31:0] -pinBusAttr MAaddrout @name MAaddrout[31:0] -pinBusAttr MAop2 @name MAop2[31:0] -pinBusAttr MAra @name MAra[3:0] -pinBusAttr MAra @attr n/c -pinBusAttr MArd @name MArd[3:0] -pinBusAttr MAresult @name MAresult[31:0] -pg 1 -lvl 9 -x 3100 -y 1210
load inst FLAGREGISTER flagregister work:flagregister:NOFILE -autohide -attr @cell(#000000) flagregister -pinAttr overflow @attr n/c -pinAttr sign @attr n/c -pg 1 -lvl 1 -x 180 -y 340
load inst HAZARDUNIT hazardunit work:hazardunit:NOFILE -autohide -attr @cell(#000000) hazardunit -pinAttr RegWriteM @attr n/c -pinAttr RegWriteW @attr n/c -pinBusAttr ForwardAE @name ForwardAE[1:0] -pinBusAttr ForwardAE @attr n/c -pinBusAttr ForwardBE @name ForwardBE[1:0] -pinBusAttr ForwardBE @attr n/c -pinBusAttr RD_M @name RD_M[4:0] -pinBusAttr RD_M @attr n/c -pinBusAttr RD_W @name RD_W[4:0] -pinBusAttr RD_W @attr n/c -pinBusAttr Rs1_E @name Rs1_E[4:0] -pinBusAttr Rs1_E @attr n/c -pinBusAttr Rs2_E @name Rs2_E[4:0] -pinBusAttr Rs2_E @attr n/c -pg 1 -lvl 17 -x 6940 -y 600
load inst IFOF_REGI IFOF_regi work:IFOF_regi:NOFILE -autohide -attr @cell(#000000) IFOF_regi -pinBusAttr IFaddrout @name IFaddrout[31:0] -pinBusAttr IFinstruction @name IFinstruction[31:0] -pinBusAttr IFopcode @name IFopcode[4:0] -pinBusAttr IFra @name IFra[3:0] -pinBusAttr IFrd @name IFrd[3:0] -pinBusAttr IFrs1 @name IFrs1[3:0] -pinBusAttr IFrs2 @name IFrs2[3:0] -pinBusAttr OFaddrout @name OFaddrout[31:0] -pinBusAttr OFinstruction @name OFinstruction[31:0] -pinBusAttr OFopcode @name OFopcode[4:0] -pinBusAttr OFra @name OFra[3:0] -pinBusAttr OFrd @name OFrd[3:0] -pinBusAttr OFrs1 @name OFrs1[3:0] -pinBusAttr OFrs2 @name OFrs2[3:0] -pg 1 -lvl 7 -x 2210 -y 380
load inst IMMEDIATEBRANCH immediatebranch work:immediatebranch:NOFILE -autohide -attr @cell(#000000) immediatebranch -pinBusAttr addrout @name addrout[31:0] -pinBusAttr branchtarget @name branchtarget[31:0] -pinBusAttr immx @name immx[31:0] -pinBusAttr instruction @name instruction[31:0] -pg 1 -lvl 14 -x 5280 -y 400
load inst IMMUX addrmux work:abstract:NOFILE -autohide -attr @cell(#000000) addrmux -pinBusAttr i0 @name i0[31:0] -pinBusAttr i1 @name i1[31:0] -pinBusAttr o @name o[31:0] -pg 1 -lvl 15 -x 5660 -y 420
load inst INSTRUCTIONFETCH instructionfetch work:instructionfetch:NOFILE -autohide -attr @cell(#000000) instructionfetch -pinBusAttr instruction @name instruction[31:0] -pinBusAttr opcode @name opcode[4:0] -pinBusAttr ra @name ra[3:0] -pinBusAttr rd @name rd[3:0] -pinBusAttr rs1 @name rs1[3:0] -pinBusAttr rs2 @name rs2[3:0] -pg 1 -lvl 6 -x 1740 -y 760
load inst INSTRUCTIONMEMORY instructionmemory work:instructionmemory:NOFILE -autohide -attr @cell(#000000) instructionmemory -pinBusAttr addrout @name addrout[31:0] -pinBusAttr instruction @name instruction[31:0] -pg 1 -lvl 5 -x 1400 -y 500
load inst MARW_REGI MARW_regi work:MARW_regi:NOFILE -autohide -attr @cell(#000000) MARW_regi -pinBusAttr MAaddrout @name MAaddrout[31:0] -pinBusAttr MAinstruction @name MAinstruction[31:0] -pinBusAttr MAinstruction @attr n/c -pinBusAttr MAldResult @name MAldResult[31:0] -pinBusAttr MAra @name MAra[3:0] -pinBusAttr MArd @name MArd[3:0] -pinBusAttr MAresult @name MAresult[31:0] -pinBusAttr RWaddrout @name RWaddrout[31:0] -pinBusAttr RWinstruction @name RWinstruction[31:0] -pinBusAttr RWinstruction @attr n/c -pinBusAttr RWldResult @name RWldResult[31:0] -pinBusAttr RWra @name RWra[3:0] -pinBusAttr RWrd @name RWrd[3:0] -pinBusAttr RWresult @name RWresult[31:0] -pg 1 -lvl 11 -x 4050 -y 1290
load inst MEMORYUNIT memoryunit work:memoryunit:NOFILE -autohide -attr @cell(#000000) memoryunit -pinBusAttr address @name address[31:0] -pinBusAttr ldResult @name ldResult[31:0] -pinBusAttr mar @name mar[31:0] -pinBusAttr mar @attr n/c -pinBusAttr mdr @name mdr[31:0] -pinBusAttr mdr @attr n/c -pinBusAttr memData @name memData[31:0] -pinBusAttr op2 @name op2[31:0] -pinBusAttr result @name result[31:0] -pinBusAttr writeData @name writeData[31:0] -pg 1 -lvl 10 -x 3580 -y 1590
load inst MUX1 regmux work:regmux:NOFILE -autohide -attr @cell(#000000) regmux -pinBusAttr i0 @name i0[3:0] -pinBusAttr i1 @name i1[3:0] -pinBusAttr o @name o[3:0] -pg 1 -lvl 13 -x 4870 -y 480
load inst MUX2 regmux work:abstract:NOFILE -autohide -attr @cell(#000000) regmux -pinBusAttr i0 @name i0[3:0] -pinBusAttr i1 @name i1[3:0] -pinBusAttr o @name o[3:0] -pg 1 -lvl 13 -x 4870 -y 780
load inst MUX3 regmux work:abstract:NOFILE -autohide -attr @cell(#000000) regmux -pinBusAttr i0 @name i0[3:0] -pinBusAttr i1 @name i1[3:0] -pinBusAttr o @name o[3:0] -pg 1 -lvl 13 -x 4870 -y 910
load inst MUX4TO1 mux4to1 work:mux4to1:NOFILE -autohide -attr @cell(#000000) mux4to1 -pinBusAttr i0 @name i0[31:0] -pinBusAttr i1 @name i1[31:0] -pinBusAttr i2 @name i2[31:0] -pinBusAttr o @name o[31:0] -pg 1 -lvl 13 -x 4870 -y 1290
load inst OFEX_REGI OFEX_regi work:OFEX_regi:NOFILE -autohide -attr @cell(#000000) OFEX_regi -pinAttr EXisLd @attr n/c -pinBusAttr EXA @name EXA[31:0] -pinBusAttr EXB @name EXB[31:0] -pinBusAttr EXaddrout @name EXaddrout[31:0] -pinBusAttr EXbranchtarget @name EXbranchtarget[31:0] -pinBusAttr EXop2 @name EXop2[31:0] -pinBusAttr EXopcode @name EXopcode[4:0] -pinBusAttr EXra @name EXra[3:0] -pinBusAttr EXrd @name EXrd[3:0] -pinBusAttr OFA @name OFA[31:0] -pinBusAttr OFB @name OFB[31:0] -pinBusAttr OFaddrout @name OFaddrout[31:0] -pinBusAttr OFbranchtarget @name OFbranchtarget[31:0] -pinBusAttr OFop2 @name OFop2[31:0] -pinBusAttr OFopcode @name OFopcode[4:0] -pinBusAttr OFra @name OFra[3:0] -pinBusAttr OFrd @name OFrd[3:0] -pg 1 -lvl 16 -x 6300 -y 60
load inst PC pc work:pc:NOFILE -autohide -attr @cell(#000000) pc -pinBusAttr addrin @name addrin[31:0] -pinBusAttr addrout @name addrout[31:0] -pinBusAttr pcplus4 @name pcplus4[31:0] -pg 1 -lvl 4 -x 1060 -y 420
load inst PC5 pc work:abstract:NOFILE -autohide -attr @cell(#000000) pc -pinBusAttr addrin @name addrin[31:0] -pinBusAttr addrout @name addrout[31:0] -pinBusAttr addrout @attr n/c -pinBusAttr pcplus4 @name pcplus4[31:0] -pg 1 -lvl 12 -x 4500 -y 1430
load inst PCMUX addrmux work:addrmux:NOFILE -autohide -attr @cell(#000000) addrmux -pinBusAttr i0 @name i0[31:0] -pinBusAttr i1 @name i1[31:0] -pinBusAttr o @name o[31:0] -pg 1 -lvl 3 -x 770 -y 380
load inst REGISTERFILE registerfile work:registerfile:NOFILE -autohide -attr @cell(#000000) registerfile -pinBusAttr mux1 @name mux1[3:0] -pinBusAttr mux2 @name mux2[3:0] -pinBusAttr mux3 @name mux3[3:0] -pinBusAttr op1 @name op1[31:0] -pinBusAttr op2 @name op2[31:0] -pinBusAttr writedata @name writedata[31:0] -pg 1 -lvl 14 -x 5280 -y 890
load net <const0> -ground -pin ALU A[31] -pin ALU A[30] -pin ALU A[29] -pin ALU A[28] -pin ALU A[27] -pin ALU A[26] -pin ALU A[25] -pin ALU A[24] -pin ALU A[23] -pin ALU A[22] -pin ALU A[21] -pin ALU A[20] -pin ALU A[19] -pin ALU A[18] -pin ALU A[17] -pin ALU A[16] -pin ALU A[15] -pin ALU A[14] -pin ALU A[13] -pin ALU A[12] -pin ALU A[11] -pin ALU A[10] -pin ALU A[9] -pin ALU A[8] -pin ALU A[7] -pin ALU A[6] -pin ALU A[5] -pin ALU A[4] -pin ALU B[31] -pin ALU B[30] -pin ALU B[29] -pin ALU B[28] -pin ALU B[27] -pin ALU B[26] -pin ALU B[25] -pin ALU B[24] -pin ALU B[23] -pin ALU B[22] -pin ALU B[21] -pin ALU B[20] -pin ALU B[19] -pin ALU B[18] -pin ALU B[17] -pin ALU B[16] -pin ALU B[15] -pin ALU B[14] -pin ALU B[13] -pin ALU B[12] -pin ALU B[11] -pin ALU B[10] -pin ALU B[9] -pin ALU B[8] -pin ALU B[7] -pin ALU B[6] -pin ALU B[5] -pin ALU B[4] -pin BRMUX i1[31] -pin BRMUX i1[30] -pin BRMUX i1[29] -pin BRMUX i1[28] -pin BRMUX i1[27] -pin BRMUX i1[26] -pin BRMUX i1[25] -pin BRMUX i1[24] -pin BRMUX i1[23] -pin BRMUX i1[22] -pin BRMUX i1[21] -pin BRMUX i1[20] -pin BRMUX i1[19] -pin BRMUX i1[18] -pin BRMUX i1[17] -pin BRMUX i1[16] -pin BRMUX i1[15] -pin BRMUX i1[14] -pin BRMUX i1[13] -pin BRMUX i1[12] -pin BRMUX i1[11] -pin BRMUX i1[10] -pin BRMUX i1[9] -pin BRMUX i1[8] -pin BRMUX i1[7] -pin BRMUX i1[6] -pin BRMUX i1[5] -pin BRMUX i1[4] -pin EXMA_REGI EXop2[31] -pin EXMA_REGI EXop2[30] -pin EXMA_REGI EXop2[29] -pin EXMA_REGI EXop2[28] -pin EXMA_REGI EXop2[27] -pin EXMA_REGI EXop2[26] -pin EXMA_REGI EXop2[25] -pin EXMA_REGI EXop2[24] -pin EXMA_REGI EXop2[23] -pin EXMA_REGI EXop2[22] -pin EXMA_REGI EXop2[21] -pin EXMA_REGI EXop2[20] -pin EXMA_REGI EXop2[19] -pin EXMA_REGI EXop2[18] -pin EXMA_REGI EXop2[17] -pin EXMA_REGI EXop2[16] -pin EXMA_REGI EXop2[15] -pin EXMA_REGI EXop2[14] -pin EXMA_REGI EXop2[13] -pin EXMA_REGI EXop2[12] -pin EXMA_REGI EXop2[11] -pin EXMA_REGI EXop2[10] -pin EXMA_REGI EXop2[9] -pin EXMA_REGI EXop2[8] -pin EXMA_REGI EXop2[7] -pin EXMA_REGI EXop2[6] -pin EXMA_REGI EXop2[5] -pin EXMA_REGI EXop2[4] -pin MEMORYUNIT op2[31] -pin MEMORYUNIT op2[30] -pin MEMORYUNIT op2[29] -pin MEMORYUNIT op2[28] -pin MEMORYUNIT op2[27] -pin MEMORYUNIT op2[26] -pin MEMORYUNIT op2[25] -pin MEMORYUNIT op2[24] -pin MEMORYUNIT op2[23] -pin MEMORYUNIT op2[22] -pin MEMORYUNIT op2[21] -pin MEMORYUNIT op2[20] -pin MEMORYUNIT op2[19] -pin MEMORYUNIT op2[18] -pin MEMORYUNIT op2[17] -pin MEMORYUNIT op2[16] -pin MEMORYUNIT op2[15] -pin MEMORYUNIT op2[14] -pin MEMORYUNIT op2[13] -pin MEMORYUNIT op2[12] -pin MEMORYUNIT op2[11] -pin MEMORYUNIT op2[10] -pin MEMORYUNIT op2[9] -pin MEMORYUNIT op2[8] -pin MEMORYUNIT op2[7] -pin MEMORYUNIT op2[6] -pin MEMORYUNIT op2[5] -pin MEMORYUNIT op2[4] -pin PC5 addrin[31] -pin PC5 addrin[30] -pin PC5 addrin[29] -pin PC5 addrin[28] -pin PC5 addrin[27] -pin PC5 addrin[26] -pin PC5 addrin[25] -pin PC5 addrin[24] -pin PC5 addrin[23] -pin PC5 addrin[22] -pin PC5 addrin[21] -pin PC5 addrin[20] -pin PC5 addrin[19] -pin PC5 addrin[18] -pin PC5 addrin[17] -pin PC5 addrin[16] -pin PC5 addrin[15] -pin PC5 addrin[14] -pin PC5 addrin[13] -pin PC5 addrin[12] -pin PC5 addrin[11] -pin PC5 addrin[10] -pin PC5 addrin[9] -pin PC5 addrin[8] -pin PC5 addrin[7] -pin PC5 addrin[6] -pin PC5 addrin[5] -pin PC5 addrin[4] -pin PC5 addrin[3] -pin PC5 addrin[2] -pin PC5 addrin[1]
load net B1_top[0] -attr @rip EXB[0] -pin ALU B[0] -pin OFEX_REGI EXB[0]
load net B1_top[1] -attr @rip EXB[1] -pin ALU B[1] -pin OFEX_REGI EXB[1]
load net B1_top[2] -attr @rip EXB[2] -pin ALU B[2] -pin OFEX_REGI EXB[2]
load net B1_top[3] -attr @rip EXB[3] -pin ALU B[3] -pin OFEX_REGI EXB[3]
load net B_top[0] -attr @rip o[0] -pin IMMUX o[0] -pin OFEX_REGI OFB[0]
load net B_top[10] -attr @rip o[10] -pin IMMUX o[10] -pin OFEX_REGI OFB[10]
load net B_top[11] -attr @rip o[11] -pin IMMUX o[11] -pin OFEX_REGI OFB[11]
load net B_top[12] -attr @rip o[12] -pin IMMUX o[12] -pin OFEX_REGI OFB[12]
load net B_top[13] -attr @rip o[13] -pin IMMUX o[13] -pin OFEX_REGI OFB[13]
load net B_top[14] -attr @rip o[14] -pin IMMUX o[14] -pin OFEX_REGI OFB[14]
load net B_top[15] -attr @rip o[15] -pin IMMUX o[15] -pin OFEX_REGI OFB[15]
load net B_top[16] -attr @rip o[16] -pin IMMUX o[16] -pin OFEX_REGI OFB[16]
load net B_top[17] -attr @rip o[17] -pin IMMUX o[17] -pin OFEX_REGI OFB[17]
load net B_top[18] -attr @rip o[18] -pin IMMUX o[18] -pin OFEX_REGI OFB[18]
load net B_top[19] -attr @rip o[19] -pin IMMUX o[19] -pin OFEX_REGI OFB[19]
load net B_top[1] -attr @rip o[1] -pin IMMUX o[1] -pin OFEX_REGI OFB[1]
load net B_top[20] -attr @rip o[20] -pin IMMUX o[20] -pin OFEX_REGI OFB[20]
load net B_top[21] -attr @rip o[21] -pin IMMUX o[21] -pin OFEX_REGI OFB[21]
load net B_top[22] -attr @rip o[22] -pin IMMUX o[22] -pin OFEX_REGI OFB[22]
load net B_top[23] -attr @rip o[23] -pin IMMUX o[23] -pin OFEX_REGI OFB[23]
load net B_top[24] -attr @rip o[24] -pin IMMUX o[24] -pin OFEX_REGI OFB[24]
load net B_top[25] -attr @rip o[25] -pin IMMUX o[25] -pin OFEX_REGI OFB[25]
load net B_top[26] -attr @rip o[26] -pin IMMUX o[26] -pin OFEX_REGI OFB[26]
load net B_top[27] -attr @rip o[27] -pin IMMUX o[27] -pin OFEX_REGI OFB[27]
load net B_top[28] -attr @rip o[28] -pin IMMUX o[28] -pin OFEX_REGI OFB[28]
load net B_top[29] -attr @rip o[29] -pin IMMUX o[29] -pin OFEX_REGI OFB[29]
load net B_top[2] -attr @rip o[2] -pin IMMUX o[2] -pin OFEX_REGI OFB[2]
load net B_top[30] -attr @rip o[30] -pin IMMUX o[30] -pin OFEX_REGI OFB[30]
load net B_top[31] -attr @rip o[31] -pin IMMUX o[31] -pin OFEX_REGI OFB[31]
load net B_top[3] -attr @rip o[3] -pin IMMUX o[3] -pin OFEX_REGI OFB[3]
load net B_top[4] -attr @rip o[4] -pin IMMUX o[4] -pin OFEX_REGI OFB[4]
load net B_top[5] -attr @rip o[5] -pin IMMUX o[5] -pin OFEX_REGI OFB[5]
load net B_top[6] -attr @rip o[6] -pin IMMUX o[6] -pin OFEX_REGI OFB[6]
load net B_top[7] -attr @rip o[7] -pin IMMUX o[7] -pin OFEX_REGI OFB[7]
load net B_top[8] -attr @rip o[8] -pin IMMUX o[8] -pin OFEX_REGI OFB[8]
load net B_top[9] -attr @rip o[9] -pin IMMUX o[9] -pin OFEX_REGI OFB[9]
load net E_in_top -pin ALU E -pin FLAGREGISTER E_in
netloc E_in_top 1 0 18 40 270 NJ 270 NJ 270 NJ 270 NJ 270 NJ 270 NJ 270 NJ 270 NJ 270 NJ 270 NJ 270 NJ 270 NJ 270 NJ 270 NJ 270 5950J 510 6770J 340 7140
load net E_top -pin BRANCHUNIT E -pin FLAGREGISTER E
netloc E_top 1 1 1 350 390n
load net GT_in_top -pin ALU GT -pin FLAGREGISTER GT_in
netloc GT_in_top 1 0 18 80 290 NJ 290 NJ 290 NJ 290 NJ 290 NJ 290 NJ 290 NJ 290 NJ 290 NJ 290 NJ 290 NJ 290 NJ 290 NJ 290 NJ 290 5990J 530 6810J 360 7100
load net GT_top -pin BRANCHUNIT GT -pin FLAGREGISTER GT
netloc GT_top 1 1 1 310 410n
load net MemRead_top -pin DATAMEMORY MemRead -pin MEMORYUNIT MemRead
netloc MemRead_top 1 8 3 2940 1540 NJ 1540 3760
load net MemWrite_top -pin DATAMEMORY MemWrite -pin MEMORYUNIT MemWrite
netloc MemWrite_top 1 8 3 2840 1780 NJ 1780 3840
load net addrin_top[0] -attr @rip o[0] -pin PC addrin[0] -pin PCMUX o[0]
load net addrin_top[10] -attr @rip o[10] -pin PC addrin[10] -pin PCMUX o[10]
load net addrin_top[11] -attr @rip o[11] -pin PC addrin[11] -pin PCMUX o[11]
load net addrin_top[12] -attr @rip o[12] -pin PC addrin[12] -pin PCMUX o[12]
load net addrin_top[13] -attr @rip o[13] -pin PC addrin[13] -pin PCMUX o[13]
load net addrin_top[14] -attr @rip o[14] -pin PC addrin[14] -pin PCMUX o[14]
load net addrin_top[15] -attr @rip o[15] -pin PC addrin[15] -pin PCMUX o[15]
load net addrin_top[16] -attr @rip o[16] -pin PC addrin[16] -pin PCMUX o[16]
load net addrin_top[17] -attr @rip o[17] -pin PC addrin[17] -pin PCMUX o[17]
load net addrin_top[18] -attr @rip o[18] -pin PC addrin[18] -pin PCMUX o[18]
load net addrin_top[19] -attr @rip o[19] -pin PC addrin[19] -pin PCMUX o[19]
load net addrin_top[1] -attr @rip o[1] -pin PC addrin[1] -pin PCMUX o[1]
load net addrin_top[20] -attr @rip o[20] -pin PC addrin[20] -pin PCMUX o[20]
load net addrin_top[21] -attr @rip o[21] -pin PC addrin[21] -pin PCMUX o[21]
load net addrin_top[22] -attr @rip o[22] -pin PC addrin[22] -pin PCMUX o[22]
load net addrin_top[23] -attr @rip o[23] -pin PC addrin[23] -pin PCMUX o[23]
load net addrin_top[24] -attr @rip o[24] -pin PC addrin[24] -pin PCMUX o[24]
load net addrin_top[25] -attr @rip o[25] -pin PC addrin[25] -pin PCMUX o[25]
load net addrin_top[26] -attr @rip o[26] -pin PC addrin[26] -pin PCMUX o[26]
load net addrin_top[27] -attr @rip o[27] -pin PC addrin[27] -pin PCMUX o[27]
load net addrin_top[28] -attr @rip o[28] -pin PC addrin[28] -pin PCMUX o[28]
load net addrin_top[29] -attr @rip o[29] -pin PC addrin[29] -pin PCMUX o[29]
load net addrin_top[2] -attr @rip o[2] -pin PC addrin[2] -pin PCMUX o[2]
load net addrin_top[30] -attr @rip o[30] -pin PC addrin[30] -pin PCMUX o[30]
load net addrin_top[31] -attr @rip o[31] -pin PC addrin[31] -pin PCMUX o[31]
load net addrin_top[3] -attr @rip o[3] -pin PC addrin[3] -pin PCMUX o[3]
load net addrin_top[4] -attr @rip o[4] -pin PC addrin[4] -pin PCMUX o[4]
load net addrin_top[5] -attr @rip o[5] -pin PC addrin[5] -pin PCMUX o[5]
load net addrin_top[6] -attr @rip o[6] -pin PC addrin[6] -pin PCMUX o[6]
load net addrin_top[7] -attr @rip o[7] -pin PC addrin[7] -pin PCMUX o[7]
load net addrin_top[8] -attr @rip o[8] -pin PC addrin[8] -pin PCMUX o[8]
load net addrin_top[9] -attr @rip o[9] -pin PC addrin[9] -pin PCMUX o[9]
load net addrout1_top[0] -attr @rip OFaddrout[0] -pin IFOF_REGI OFaddrout[0] -pin IMMEDIATEBRANCH addrout[0] -pin OFEX_REGI OFaddrout[0]
load net addrout1_top[10] -attr @rip OFaddrout[10] -pin IFOF_REGI OFaddrout[10] -pin IMMEDIATEBRANCH addrout[10] -pin OFEX_REGI OFaddrout[10]
load net addrout1_top[11] -attr @rip OFaddrout[11] -pin IFOF_REGI OFaddrout[11] -pin IMMEDIATEBRANCH addrout[11] -pin OFEX_REGI OFaddrout[11]
load net addrout1_top[12] -attr @rip OFaddrout[12] -pin IFOF_REGI OFaddrout[12] -pin IMMEDIATEBRANCH addrout[12] -pin OFEX_REGI OFaddrout[12]
load net addrout1_top[13] -attr @rip OFaddrout[13] -pin IFOF_REGI OFaddrout[13] -pin IMMEDIATEBRANCH addrout[13] -pin OFEX_REGI OFaddrout[13]
load net addrout1_top[14] -attr @rip OFaddrout[14] -pin IFOF_REGI OFaddrout[14] -pin IMMEDIATEBRANCH addrout[14] -pin OFEX_REGI OFaddrout[14]
load net addrout1_top[15] -attr @rip OFaddrout[15] -pin IFOF_REGI OFaddrout[15] -pin IMMEDIATEBRANCH addrout[15] -pin OFEX_REGI OFaddrout[15]
load net addrout1_top[16] -attr @rip OFaddrout[16] -pin IFOF_REGI OFaddrout[16] -pin IMMEDIATEBRANCH addrout[16] -pin OFEX_REGI OFaddrout[16]
load net addrout1_top[17] -attr @rip OFaddrout[17] -pin IFOF_REGI OFaddrout[17] -pin IMMEDIATEBRANCH addrout[17] -pin OFEX_REGI OFaddrout[17]
load net addrout1_top[18] -attr @rip OFaddrout[18] -pin IFOF_REGI OFaddrout[18] -pin IMMEDIATEBRANCH addrout[18] -pin OFEX_REGI OFaddrout[18]
load net addrout1_top[19] -attr @rip OFaddrout[19] -pin IFOF_REGI OFaddrout[19] -pin IMMEDIATEBRANCH addrout[19] -pin OFEX_REGI OFaddrout[19]
load net addrout1_top[1] -attr @rip OFaddrout[1] -pin IFOF_REGI OFaddrout[1] -pin IMMEDIATEBRANCH addrout[1] -pin OFEX_REGI OFaddrout[1]
load net addrout1_top[20] -attr @rip OFaddrout[20] -pin IFOF_REGI OFaddrout[20] -pin IMMEDIATEBRANCH addrout[20] -pin OFEX_REGI OFaddrout[20]
load net addrout1_top[21] -attr @rip OFaddrout[21] -pin IFOF_REGI OFaddrout[21] -pin IMMEDIATEBRANCH addrout[21] -pin OFEX_REGI OFaddrout[21]
load net addrout1_top[22] -attr @rip OFaddrout[22] -pin IFOF_REGI OFaddrout[22] -pin IMMEDIATEBRANCH addrout[22] -pin OFEX_REGI OFaddrout[22]
load net addrout1_top[23] -attr @rip OFaddrout[23] -pin IFOF_REGI OFaddrout[23] -pin IMMEDIATEBRANCH addrout[23] -pin OFEX_REGI OFaddrout[23]
load net addrout1_top[24] -attr @rip OFaddrout[24] -pin IFOF_REGI OFaddrout[24] -pin IMMEDIATEBRANCH addrout[24] -pin OFEX_REGI OFaddrout[24]
load net addrout1_top[25] -attr @rip OFaddrout[25] -pin IFOF_REGI OFaddrout[25] -pin IMMEDIATEBRANCH addrout[25] -pin OFEX_REGI OFaddrout[25]
load net addrout1_top[26] -attr @rip OFaddrout[26] -pin IFOF_REGI OFaddrout[26] -pin IMMEDIATEBRANCH addrout[26] -pin OFEX_REGI OFaddrout[26]
load net addrout1_top[27] -attr @rip OFaddrout[27] -pin IFOF_REGI OFaddrout[27] -pin IMMEDIATEBRANCH addrout[27] -pin OFEX_REGI OFaddrout[27]
load net addrout1_top[28] -attr @rip OFaddrout[28] -pin IFOF_REGI OFaddrout[28] -pin IMMEDIATEBRANCH addrout[28] -pin OFEX_REGI OFaddrout[28]
load net addrout1_top[29] -attr @rip OFaddrout[29] -pin IFOF_REGI OFaddrout[29] -pin IMMEDIATEBRANCH addrout[29] -pin OFEX_REGI OFaddrout[29]
load net addrout1_top[2] -attr @rip OFaddrout[2] -pin IFOF_REGI OFaddrout[2] -pin IMMEDIATEBRANCH addrout[2] -pin OFEX_REGI OFaddrout[2]
load net addrout1_top[30] -attr @rip OFaddrout[30] -pin IFOF_REGI OFaddrout[30] -pin IMMEDIATEBRANCH addrout[30] -pin OFEX_REGI OFaddrout[30]
load net addrout1_top[31] -attr @rip OFaddrout[31] -pin IFOF_REGI OFaddrout[31] -pin IMMEDIATEBRANCH addrout[31] -pin OFEX_REGI OFaddrout[31]
load net addrout1_top[3] -attr @rip OFaddrout[3] -pin IFOF_REGI OFaddrout[3] -pin IMMEDIATEBRANCH addrout[3] -pin OFEX_REGI OFaddrout[3]
load net addrout1_top[4] -attr @rip OFaddrout[4] -pin IFOF_REGI OFaddrout[4] -pin IMMEDIATEBRANCH addrout[4] -pin OFEX_REGI OFaddrout[4]
load net addrout1_top[5] -attr @rip OFaddrout[5] -pin IFOF_REGI OFaddrout[5] -pin IMMEDIATEBRANCH addrout[5] -pin OFEX_REGI OFaddrout[5]
load net addrout1_top[6] -attr @rip OFaddrout[6] -pin IFOF_REGI OFaddrout[6] -pin IMMEDIATEBRANCH addrout[6] -pin OFEX_REGI OFaddrout[6]
load net addrout1_top[7] -attr @rip OFaddrout[7] -pin IFOF_REGI OFaddrout[7] -pin IMMEDIATEBRANCH addrout[7] -pin OFEX_REGI OFaddrout[7]
load net addrout1_top[8] -attr @rip OFaddrout[8] -pin IFOF_REGI OFaddrout[8] -pin IMMEDIATEBRANCH addrout[8] -pin OFEX_REGI OFaddrout[8]
load net addrout1_top[9] -attr @rip OFaddrout[9] -pin IFOF_REGI OFaddrout[9] -pin IMMEDIATEBRANCH addrout[9] -pin OFEX_REGI OFaddrout[9]
load net addrout2_top[0] -attr @rip EXaddrout[0] -pin EXMA_REGI EXaddrout[0] -pin OFEX_REGI EXaddrout[0]
load net addrout2_top[10] -attr @rip EXaddrout[10] -pin EXMA_REGI EXaddrout[10] -pin OFEX_REGI EXaddrout[10]
load net addrout2_top[11] -attr @rip EXaddrout[11] -pin EXMA_REGI EXaddrout[11] -pin OFEX_REGI EXaddrout[11]
load net addrout2_top[12] -attr @rip EXaddrout[12] -pin EXMA_REGI EXaddrout[12] -pin OFEX_REGI EXaddrout[12]
load net addrout2_top[13] -attr @rip EXaddrout[13] -pin EXMA_REGI EXaddrout[13] -pin OFEX_REGI EXaddrout[13]
load net addrout2_top[14] -attr @rip EXaddrout[14] -pin EXMA_REGI EXaddrout[14] -pin OFEX_REGI EXaddrout[14]
load net addrout2_top[15] -attr @rip EXaddrout[15] -pin EXMA_REGI EXaddrout[15] -pin OFEX_REGI EXaddrout[15]
load net addrout2_top[16] -attr @rip EXaddrout[16] -pin EXMA_REGI EXaddrout[16] -pin OFEX_REGI EXaddrout[16]
load net addrout2_top[17] -attr @rip EXaddrout[17] -pin EXMA_REGI EXaddrout[17] -pin OFEX_REGI EXaddrout[17]
load net addrout2_top[18] -attr @rip EXaddrout[18] -pin EXMA_REGI EXaddrout[18] -pin OFEX_REGI EXaddrout[18]
load net addrout2_top[19] -attr @rip EXaddrout[19] -pin EXMA_REGI EXaddrout[19] -pin OFEX_REGI EXaddrout[19]
load net addrout2_top[1] -attr @rip EXaddrout[1] -pin EXMA_REGI EXaddrout[1] -pin OFEX_REGI EXaddrout[1]
load net addrout2_top[20] -attr @rip EXaddrout[20] -pin EXMA_REGI EXaddrout[20] -pin OFEX_REGI EXaddrout[20]
load net addrout2_top[21] -attr @rip EXaddrout[21] -pin EXMA_REGI EXaddrout[21] -pin OFEX_REGI EXaddrout[21]
load net addrout2_top[22] -attr @rip EXaddrout[22] -pin EXMA_REGI EXaddrout[22] -pin OFEX_REGI EXaddrout[22]
load net addrout2_top[23] -attr @rip EXaddrout[23] -pin EXMA_REGI EXaddrout[23] -pin OFEX_REGI EXaddrout[23]
load net addrout2_top[24] -attr @rip EXaddrout[24] -pin EXMA_REGI EXaddrout[24] -pin OFEX_REGI EXaddrout[24]
load net addrout2_top[25] -attr @rip EXaddrout[25] -pin EXMA_REGI EXaddrout[25] -pin OFEX_REGI EXaddrout[25]
load net addrout2_top[26] -attr @rip EXaddrout[26] -pin EXMA_REGI EXaddrout[26] -pin OFEX_REGI EXaddrout[26]
load net addrout2_top[27] -attr @rip EXaddrout[27] -pin EXMA_REGI EXaddrout[27] -pin OFEX_REGI EXaddrout[27]
load net addrout2_top[28] -attr @rip EXaddrout[28] -pin EXMA_REGI EXaddrout[28] -pin OFEX_REGI EXaddrout[28]
load net addrout2_top[29] -attr @rip EXaddrout[29] -pin EXMA_REGI EXaddrout[29] -pin OFEX_REGI EXaddrout[29]
load net addrout2_top[2] -attr @rip EXaddrout[2] -pin EXMA_REGI EXaddrout[2] -pin OFEX_REGI EXaddrout[2]
load net addrout2_top[30] -attr @rip EXaddrout[30] -pin EXMA_REGI EXaddrout[30] -pin OFEX_REGI EXaddrout[30]
load net addrout2_top[31] -attr @rip EXaddrout[31] -pin EXMA_REGI EXaddrout[31] -pin OFEX_REGI EXaddrout[31]
load net addrout2_top[3] -attr @rip EXaddrout[3] -pin EXMA_REGI EXaddrout[3] -pin OFEX_REGI EXaddrout[3]
load net addrout2_top[4] -attr @rip EXaddrout[4] -pin EXMA_REGI EXaddrout[4] -pin OFEX_REGI EXaddrout[4]
load net addrout2_top[5] -attr @rip EXaddrout[5] -pin EXMA_REGI EXaddrout[5] -pin OFEX_REGI EXaddrout[5]
load net addrout2_top[6] -attr @rip EXaddrout[6] -pin EXMA_REGI EXaddrout[6] -pin OFEX_REGI EXaddrout[6]
load net addrout2_top[7] -attr @rip EXaddrout[7] -pin EXMA_REGI EXaddrout[7] -pin OFEX_REGI EXaddrout[7]
load net addrout2_top[8] -attr @rip EXaddrout[8] -pin EXMA_REGI EXaddrout[8] -pin OFEX_REGI EXaddrout[8]
load net addrout2_top[9] -attr @rip EXaddrout[9] -pin EXMA_REGI EXaddrout[9] -pin OFEX_REGI EXaddrout[9]
load net addrout3_top[0] -attr @rip MAaddrout[0] -pin EXMA_REGI MAaddrout[0] -pin MARW_REGI MAaddrout[0]
load net addrout3_top[10] -attr @rip MAaddrout[10] -pin EXMA_REGI MAaddrout[10] -pin MARW_REGI MAaddrout[10]
load net addrout3_top[11] -attr @rip MAaddrout[11] -pin EXMA_REGI MAaddrout[11] -pin MARW_REGI MAaddrout[11]
load net addrout3_top[12] -attr @rip MAaddrout[12] -pin EXMA_REGI MAaddrout[12] -pin MARW_REGI MAaddrout[12]
load net addrout3_top[13] -attr @rip MAaddrout[13] -pin EXMA_REGI MAaddrout[13] -pin MARW_REGI MAaddrout[13]
load net addrout3_top[14] -attr @rip MAaddrout[14] -pin EXMA_REGI MAaddrout[14] -pin MARW_REGI MAaddrout[14]
load net addrout3_top[15] -attr @rip MAaddrout[15] -pin EXMA_REGI MAaddrout[15] -pin MARW_REGI MAaddrout[15]
load net addrout3_top[16] -attr @rip MAaddrout[16] -pin EXMA_REGI MAaddrout[16] -pin MARW_REGI MAaddrout[16]
load net addrout3_top[17] -attr @rip MAaddrout[17] -pin EXMA_REGI MAaddrout[17] -pin MARW_REGI MAaddrout[17]
load net addrout3_top[18] -attr @rip MAaddrout[18] -pin EXMA_REGI MAaddrout[18] -pin MARW_REGI MAaddrout[18]
load net addrout3_top[19] -attr @rip MAaddrout[19] -pin EXMA_REGI MAaddrout[19] -pin MARW_REGI MAaddrout[19]
load net addrout3_top[1] -attr @rip MAaddrout[1] -pin EXMA_REGI MAaddrout[1] -pin MARW_REGI MAaddrout[1]
load net addrout3_top[20] -attr @rip MAaddrout[20] -pin EXMA_REGI MAaddrout[20] -pin MARW_REGI MAaddrout[20]
load net addrout3_top[21] -attr @rip MAaddrout[21] -pin EXMA_REGI MAaddrout[21] -pin MARW_REGI MAaddrout[21]
load net addrout3_top[22] -attr @rip MAaddrout[22] -pin EXMA_REGI MAaddrout[22] -pin MARW_REGI MAaddrout[22]
load net addrout3_top[23] -attr @rip MAaddrout[23] -pin EXMA_REGI MAaddrout[23] -pin MARW_REGI MAaddrout[23]
load net addrout3_top[24] -attr @rip MAaddrout[24] -pin EXMA_REGI MAaddrout[24] -pin MARW_REGI MAaddrout[24]
load net addrout3_top[25] -attr @rip MAaddrout[25] -pin EXMA_REGI MAaddrout[25] -pin MARW_REGI MAaddrout[25]
load net addrout3_top[26] -attr @rip MAaddrout[26] -pin EXMA_REGI MAaddrout[26] -pin MARW_REGI MAaddrout[26]
load net addrout3_top[27] -attr @rip MAaddrout[27] -pin EXMA_REGI MAaddrout[27] -pin MARW_REGI MAaddrout[27]
load net addrout3_top[28] -attr @rip MAaddrout[28] -pin EXMA_REGI MAaddrout[28] -pin MARW_REGI MAaddrout[28]
load net addrout3_top[29] -attr @rip MAaddrout[29] -pin EXMA_REGI MAaddrout[29] -pin MARW_REGI MAaddrout[29]
load net addrout3_top[2] -attr @rip MAaddrout[2] -pin EXMA_REGI MAaddrout[2] -pin MARW_REGI MAaddrout[2]
load net addrout3_top[30] -attr @rip MAaddrout[30] -pin EXMA_REGI MAaddrout[30] -pin MARW_REGI MAaddrout[30]
load net addrout3_top[31] -attr @rip MAaddrout[31] -pin EXMA_REGI MAaddrout[31] -pin MARW_REGI MAaddrout[31]
load net addrout3_top[3] -attr @rip MAaddrout[3] -pin EXMA_REGI MAaddrout[3] -pin MARW_REGI MAaddrout[3]
load net addrout3_top[4] -attr @rip MAaddrout[4] -pin EXMA_REGI MAaddrout[4] -pin MARW_REGI MAaddrout[4]
load net addrout3_top[5] -attr @rip MAaddrout[5] -pin EXMA_REGI MAaddrout[5] -pin MARW_REGI MAaddrout[5]
load net addrout3_top[6] -attr @rip MAaddrout[6] -pin EXMA_REGI MAaddrout[6] -pin MARW_REGI MAaddrout[6]
load net addrout3_top[7] -attr @rip MAaddrout[7] -pin EXMA_REGI MAaddrout[7] -pin MARW_REGI MAaddrout[7]
load net addrout3_top[8] -attr @rip MAaddrout[8] -pin EXMA_REGI MAaddrout[8] -pin MARW_REGI MAaddrout[8]
load net addrout3_top[9] -attr @rip MAaddrout[9] -pin EXMA_REGI MAaddrout[9] -pin MARW_REGI MAaddrout[9]
load net addrout4_top -attr @rip RWaddrout[0] -pin MARW_REGI RWaddrout[0] -pin PC5 addrin[0]
netloc addrout4_top 1 11 1 4320 1320n
load net addrout_top[0] -attr @rip addrout[0] -pin IFOF_REGI IFaddrout[0] -pin INSTRUCTIONMEMORY addrout[0] -pin PC addrout[0]
load net addrout_top[10] -attr @rip addrout[10] -pin IFOF_REGI IFaddrout[10] -pin INSTRUCTIONMEMORY addrout[10] -pin PC addrout[10]
load net addrout_top[11] -attr @rip addrout[11] -pin IFOF_REGI IFaddrout[11] -pin INSTRUCTIONMEMORY addrout[11] -pin PC addrout[11]
load net addrout_top[12] -attr @rip addrout[12] -pin IFOF_REGI IFaddrout[12] -pin INSTRUCTIONMEMORY addrout[12] -pin PC addrout[12]
load net addrout_top[13] -attr @rip addrout[13] -pin IFOF_REGI IFaddrout[13] -pin INSTRUCTIONMEMORY addrout[13] -pin PC addrout[13]
load net addrout_top[14] -attr @rip addrout[14] -pin IFOF_REGI IFaddrout[14] -pin INSTRUCTIONMEMORY addrout[14] -pin PC addrout[14]
load net addrout_top[15] -attr @rip addrout[15] -pin IFOF_REGI IFaddrout[15] -pin INSTRUCTIONMEMORY addrout[15] -pin PC addrout[15]
load net addrout_top[16] -attr @rip addrout[16] -pin IFOF_REGI IFaddrout[16] -pin INSTRUCTIONMEMORY addrout[16] -pin PC addrout[16]
load net addrout_top[17] -attr @rip addrout[17] -pin IFOF_REGI IFaddrout[17] -pin INSTRUCTIONMEMORY addrout[17] -pin PC addrout[17]
load net addrout_top[18] -attr @rip addrout[18] -pin IFOF_REGI IFaddrout[18] -pin INSTRUCTIONMEMORY addrout[18] -pin PC addrout[18]
load net addrout_top[19] -attr @rip addrout[19] -pin IFOF_REGI IFaddrout[19] -pin INSTRUCTIONMEMORY addrout[19] -pin PC addrout[19]
load net addrout_top[1] -attr @rip addrout[1] -pin IFOF_REGI IFaddrout[1] -pin INSTRUCTIONMEMORY addrout[1] -pin PC addrout[1]
load net addrout_top[20] -attr @rip addrout[20] -pin IFOF_REGI IFaddrout[20] -pin INSTRUCTIONMEMORY addrout[20] -pin PC addrout[20]
load net addrout_top[21] -attr @rip addrout[21] -pin IFOF_REGI IFaddrout[21] -pin INSTRUCTIONMEMORY addrout[21] -pin PC addrout[21]
load net addrout_top[22] -attr @rip addrout[22] -pin IFOF_REGI IFaddrout[22] -pin INSTRUCTIONMEMORY addrout[22] -pin PC addrout[22]
load net addrout_top[23] -attr @rip addrout[23] -pin IFOF_REGI IFaddrout[23] -pin INSTRUCTIONMEMORY addrout[23] -pin PC addrout[23]
load net addrout_top[24] -attr @rip addrout[24] -pin IFOF_REGI IFaddrout[24] -pin INSTRUCTIONMEMORY addrout[24] -pin PC addrout[24]
load net addrout_top[25] -attr @rip addrout[25] -pin IFOF_REGI IFaddrout[25] -pin INSTRUCTIONMEMORY addrout[25] -pin PC addrout[25]
load net addrout_top[26] -attr @rip addrout[26] -pin IFOF_REGI IFaddrout[26] -pin INSTRUCTIONMEMORY addrout[26] -pin PC addrout[26]
load net addrout_top[27] -attr @rip addrout[27] -pin IFOF_REGI IFaddrout[27] -pin INSTRUCTIONMEMORY addrout[27] -pin PC addrout[27]
load net addrout_top[28] -attr @rip addrout[28] -pin IFOF_REGI IFaddrout[28] -pin INSTRUCTIONMEMORY addrout[28] -pin PC addrout[28]
load net addrout_top[29] -attr @rip addrout[29] -pin IFOF_REGI IFaddrout[29] -pin INSTRUCTIONMEMORY addrout[29] -pin PC addrout[29]
load net addrout_top[2] -attr @rip addrout[2] -pin IFOF_REGI IFaddrout[2] -pin INSTRUCTIONMEMORY addrout[2] -pin PC addrout[2]
load net addrout_top[30] -attr @rip addrout[30] -pin IFOF_REGI IFaddrout[30] -pin INSTRUCTIONMEMORY addrout[30] -pin PC addrout[30]
load net addrout_top[31] -attr @rip addrout[31] -pin IFOF_REGI IFaddrout[31] -pin INSTRUCTIONMEMORY addrout[31] -pin PC addrout[31]
load net addrout_top[3] -attr @rip addrout[3] -pin IFOF_REGI IFaddrout[3] -pin INSTRUCTIONMEMORY addrout[3] -pin PC addrout[3]
load net addrout_top[4] -attr @rip addrout[4] -pin IFOF_REGI IFaddrout[4] -pin INSTRUCTIONMEMORY addrout[4] -pin PC addrout[4]
load net addrout_top[5] -attr @rip addrout[5] -pin IFOF_REGI IFaddrout[5] -pin INSTRUCTIONMEMORY addrout[5] -pin PC addrout[5]
load net addrout_top[6] -attr @rip addrout[6] -pin IFOF_REGI IFaddrout[6] -pin INSTRUCTIONMEMORY addrout[6] -pin PC addrout[6]
load net addrout_top[7] -attr @rip addrout[7] -pin IFOF_REGI IFaddrout[7] -pin INSTRUCTIONMEMORY addrout[7] -pin PC addrout[7]
load net addrout_top[8] -attr @rip addrout[8] -pin IFOF_REGI IFaddrout[8] -pin INSTRUCTIONMEMORY addrout[8] -pin PC addrout[8]
load net addrout_top[9] -attr @rip addrout[9] -pin IFOF_REGI IFaddrout[9] -pin INSTRUCTIONMEMORY addrout[9] -pin PC addrout[9]
load net branchaddr_top[0] -attr @rip o[0] -pin BRMUX o[0] -pin PCMUX i1[0]
load net branchaddr_top[10] -attr @rip o[10] -pin BRMUX o[10] -pin PCMUX i1[10]
load net branchaddr_top[11] -attr @rip o[11] -pin BRMUX o[11] -pin PCMUX i1[11]
load net branchaddr_top[12] -attr @rip o[12] -pin BRMUX o[12] -pin PCMUX i1[12]
load net branchaddr_top[13] -attr @rip o[13] -pin BRMUX o[13] -pin PCMUX i1[13]
load net branchaddr_top[14] -attr @rip o[14] -pin BRMUX o[14] -pin PCMUX i1[14]
load net branchaddr_top[15] -attr @rip o[15] -pin BRMUX o[15] -pin PCMUX i1[15]
load net branchaddr_top[16] -attr @rip o[16] -pin BRMUX o[16] -pin PCMUX i1[16]
load net branchaddr_top[17] -attr @rip o[17] -pin BRMUX o[17] -pin PCMUX i1[17]
load net branchaddr_top[18] -attr @rip o[18] -pin BRMUX o[18] -pin PCMUX i1[18]
load net branchaddr_top[19] -attr @rip o[19] -pin BRMUX o[19] -pin PCMUX i1[19]
load net branchaddr_top[1] -attr @rip o[1] -pin BRMUX o[1] -pin PCMUX i1[1]
load net branchaddr_top[20] -attr @rip o[20] -pin BRMUX o[20] -pin PCMUX i1[20]
load net branchaddr_top[21] -attr @rip o[21] -pin BRMUX o[21] -pin PCMUX i1[21]
load net branchaddr_top[22] -attr @rip o[22] -pin BRMUX o[22] -pin PCMUX i1[22]
load net branchaddr_top[23] -attr @rip o[23] -pin BRMUX o[23] -pin PCMUX i1[23]
load net branchaddr_top[24] -attr @rip o[24] -pin BRMUX o[24] -pin PCMUX i1[24]
load net branchaddr_top[25] -attr @rip o[25] -pin BRMUX o[25] -pin PCMUX i1[25]
load net branchaddr_top[26] -attr @rip o[26] -pin BRMUX o[26] -pin PCMUX i1[26]
load net branchaddr_top[27] -attr @rip o[27] -pin BRMUX o[27] -pin PCMUX i1[27]
load net branchaddr_top[28] -attr @rip o[28] -pin BRMUX o[28] -pin PCMUX i1[28]
load net branchaddr_top[29] -attr @rip o[29] -pin BRMUX o[29] -pin PCMUX i1[29]
load net branchaddr_top[2] -attr @rip o[2] -pin BRMUX o[2] -pin PCMUX i1[2]
load net branchaddr_top[30] -attr @rip o[30] -pin BRMUX o[30] -pin PCMUX i1[30]
load net branchaddr_top[31] -attr @rip o[31] -pin BRMUX o[31] -pin PCMUX i1[31]
load net branchaddr_top[3] -attr @rip o[3] -pin BRMUX o[3] -pin PCMUX i1[3]
load net branchaddr_top[4] -attr @rip o[4] -pin BRMUX o[4] -pin PCMUX i1[4]
load net branchaddr_top[5] -attr @rip o[5] -pin BRMUX o[5] -pin PCMUX i1[5]
load net branchaddr_top[6] -attr @rip o[6] -pin BRMUX o[6] -pin PCMUX i1[6]
load net branchaddr_top[7] -attr @rip o[7] -pin BRMUX o[7] -pin PCMUX i1[7]
load net branchaddr_top[8] -attr @rip o[8] -pin BRMUX o[8] -pin PCMUX i1[8]
load net branchaddr_top[9] -attr @rip o[9] -pin BRMUX o[9] -pin PCMUX i1[9]
load net branchtarget1_top[0] -attr @rip EXbranchtarget[0] -pin BRMUX i0[0] -pin OFEX_REGI EXbranchtarget[0]
load net branchtarget1_top[10] -attr @rip EXbranchtarget[10] -pin BRMUX i0[10] -pin OFEX_REGI EXbranchtarget[10]
load net branchtarget1_top[11] -attr @rip EXbranchtarget[11] -pin BRMUX i0[11] -pin OFEX_REGI EXbranchtarget[11]
load net branchtarget1_top[12] -attr @rip EXbranchtarget[12] -pin BRMUX i0[12] -pin OFEX_REGI EXbranchtarget[12]
load net branchtarget1_top[13] -attr @rip EXbranchtarget[13] -pin BRMUX i0[13] -pin OFEX_REGI EXbranchtarget[13]
load net branchtarget1_top[14] -attr @rip EXbranchtarget[14] -pin BRMUX i0[14] -pin OFEX_REGI EXbranchtarget[14]
load net branchtarget1_top[15] -attr @rip EXbranchtarget[15] -pin BRMUX i0[15] -pin OFEX_REGI EXbranchtarget[15]
load net branchtarget1_top[16] -attr @rip EXbranchtarget[16] -pin BRMUX i0[16] -pin OFEX_REGI EXbranchtarget[16]
load net branchtarget1_top[17] -attr @rip EXbranchtarget[17] -pin BRMUX i0[17] -pin OFEX_REGI EXbranchtarget[17]
load net branchtarget1_top[18] -attr @rip EXbranchtarget[18] -pin BRMUX i0[18] -pin OFEX_REGI EXbranchtarget[18]
load net branchtarget1_top[19] -attr @rip EXbranchtarget[19] -pin BRMUX i0[19] -pin OFEX_REGI EXbranchtarget[19]
load net branchtarget1_top[1] -attr @rip EXbranchtarget[1] -pin BRMUX i0[1] -pin OFEX_REGI EXbranchtarget[1]
load net branchtarget1_top[20] -attr @rip EXbranchtarget[20] -pin BRMUX i0[20] -pin OFEX_REGI EXbranchtarget[20]
load net branchtarget1_top[21] -attr @rip EXbranchtarget[21] -pin BRMUX i0[21] -pin OFEX_REGI EXbranchtarget[21]
load net branchtarget1_top[22] -attr @rip EXbranchtarget[22] -pin BRMUX i0[22] -pin OFEX_REGI EXbranchtarget[22]
load net branchtarget1_top[23] -attr @rip EXbranchtarget[23] -pin BRMUX i0[23] -pin OFEX_REGI EXbranchtarget[23]
load net branchtarget1_top[24] -attr @rip EXbranchtarget[24] -pin BRMUX i0[24] -pin OFEX_REGI EXbranchtarget[24]
load net branchtarget1_top[25] -attr @rip EXbranchtarget[25] -pin BRMUX i0[25] -pin OFEX_REGI EXbranchtarget[25]
load net branchtarget1_top[26] -attr @rip EXbranchtarget[26] -pin BRMUX i0[26] -pin OFEX_REGI EXbranchtarget[26]
load net branchtarget1_top[27] -attr @rip EXbranchtarget[27] -pin BRMUX i0[27] -pin OFEX_REGI EXbranchtarget[27]
load net branchtarget1_top[28] -attr @rip EXbranchtarget[28] -pin BRMUX i0[28] -pin OFEX_REGI EXbranchtarget[28]
load net branchtarget1_top[29] -attr @rip EXbranchtarget[29] -pin BRMUX i0[29] -pin OFEX_REGI EXbranchtarget[29]
load net branchtarget1_top[2] -attr @rip EXbranchtarget[2] -pin BRMUX i0[2] -pin OFEX_REGI EXbranchtarget[2]
load net branchtarget1_top[30] -attr @rip EXbranchtarget[30] -pin BRMUX i0[30] -pin OFEX_REGI EXbranchtarget[30]
load net branchtarget1_top[31] -attr @rip EXbranchtarget[31] -pin BRMUX i0[31] -pin OFEX_REGI EXbranchtarget[31]
load net branchtarget1_top[3] -attr @rip EXbranchtarget[3] -pin BRMUX i0[3] -pin OFEX_REGI EXbranchtarget[3]
load net branchtarget1_top[4] -attr @rip EXbranchtarget[4] -pin BRMUX i0[4] -pin OFEX_REGI EXbranchtarget[4]
load net branchtarget1_top[5] -attr @rip EXbranchtarget[5] -pin BRMUX i0[5] -pin OFEX_REGI EXbranchtarget[5]
load net branchtarget1_top[6] -attr @rip EXbranchtarget[6] -pin BRMUX i0[6] -pin OFEX_REGI EXbranchtarget[6]
load net branchtarget1_top[7] -attr @rip EXbranchtarget[7] -pin BRMUX i0[7] -pin OFEX_REGI EXbranchtarget[7]
load net branchtarget1_top[8] -attr @rip EXbranchtarget[8] -pin BRMUX i0[8] -pin OFEX_REGI EXbranchtarget[8]
load net branchtarget1_top[9] -attr @rip EXbranchtarget[9] -pin BRMUX i0[9] -pin OFEX_REGI EXbranchtarget[9]
load net branchtarget_top[0] -attr @rip branchtarget[0] -pin IMMEDIATEBRANCH branchtarget[0] -pin OFEX_REGI OFbranchtarget[0]
load net branchtarget_top[10] -attr @rip branchtarget[10] -pin IMMEDIATEBRANCH branchtarget[10] -pin OFEX_REGI OFbranchtarget[10]
load net branchtarget_top[11] -attr @rip branchtarget[11] -pin IMMEDIATEBRANCH branchtarget[11] -pin OFEX_REGI OFbranchtarget[11]
load net branchtarget_top[12] -attr @rip branchtarget[12] -pin IMMEDIATEBRANCH branchtarget[12] -pin OFEX_REGI OFbranchtarget[12]
load net branchtarget_top[13] -attr @rip branchtarget[13] -pin IMMEDIATEBRANCH branchtarget[13] -pin OFEX_REGI OFbranchtarget[13]
load net branchtarget_top[14] -attr @rip branchtarget[14] -pin IMMEDIATEBRANCH branchtarget[14] -pin OFEX_REGI OFbranchtarget[14]
load net branchtarget_top[15] -attr @rip branchtarget[15] -pin IMMEDIATEBRANCH branchtarget[15] -pin OFEX_REGI OFbranchtarget[15]
load net branchtarget_top[16] -attr @rip branchtarget[16] -pin IMMEDIATEBRANCH branchtarget[16] -pin OFEX_REGI OFbranchtarget[16]
load net branchtarget_top[17] -attr @rip branchtarget[17] -pin IMMEDIATEBRANCH branchtarget[17] -pin OFEX_REGI OFbranchtarget[17]
load net branchtarget_top[18] -attr @rip branchtarget[18] -pin IMMEDIATEBRANCH branchtarget[18] -pin OFEX_REGI OFbranchtarget[18]
load net branchtarget_top[19] -attr @rip branchtarget[19] -pin IMMEDIATEBRANCH branchtarget[19] -pin OFEX_REGI OFbranchtarget[19]
load net branchtarget_top[1] -attr @rip branchtarget[1] -pin IMMEDIATEBRANCH branchtarget[1] -pin OFEX_REGI OFbranchtarget[1]
load net branchtarget_top[20] -attr @rip branchtarget[20] -pin IMMEDIATEBRANCH branchtarget[20] -pin OFEX_REGI OFbranchtarget[20]
load net branchtarget_top[21] -attr @rip branchtarget[21] -pin IMMEDIATEBRANCH branchtarget[21] -pin OFEX_REGI OFbranchtarget[21]
load net branchtarget_top[22] -attr @rip branchtarget[22] -pin IMMEDIATEBRANCH branchtarget[22] -pin OFEX_REGI OFbranchtarget[22]
load net branchtarget_top[23] -attr @rip branchtarget[23] -pin IMMEDIATEBRANCH branchtarget[23] -pin OFEX_REGI OFbranchtarget[23]
load net branchtarget_top[24] -attr @rip branchtarget[24] -pin IMMEDIATEBRANCH branchtarget[24] -pin OFEX_REGI OFbranchtarget[24]
load net branchtarget_top[25] -attr @rip branchtarget[25] -pin IMMEDIATEBRANCH branchtarget[25] -pin OFEX_REGI OFbranchtarget[25]
load net branchtarget_top[26] -attr @rip branchtarget[26] -pin IMMEDIATEBRANCH branchtarget[26] -pin OFEX_REGI OFbranchtarget[26]
load net branchtarget_top[27] -attr @rip branchtarget[27] -pin IMMEDIATEBRANCH branchtarget[27] -pin OFEX_REGI OFbranchtarget[27]
load net branchtarget_top[28] -attr @rip branchtarget[28] -pin IMMEDIATEBRANCH branchtarget[28] -pin OFEX_REGI OFbranchtarget[28]
load net branchtarget_top[29] -attr @rip branchtarget[29] -pin IMMEDIATEBRANCH branchtarget[29] -pin OFEX_REGI OFbranchtarget[29]
load net branchtarget_top[2] -attr @rip branchtarget[2] -pin IMMEDIATEBRANCH branchtarget[2] -pin OFEX_REGI OFbranchtarget[2]
load net branchtarget_top[30] -attr @rip branchtarget[30] -pin IMMEDIATEBRANCH branchtarget[30] -pin OFEX_REGI OFbranchtarget[30]
load net branchtarget_top[31] -attr @rip branchtarget[31] -pin IMMEDIATEBRANCH branchtarget[31] -pin OFEX_REGI OFbranchtarget[31]
load net branchtarget_top[3] -attr @rip branchtarget[3] -pin IMMEDIATEBRANCH branchtarget[3] -pin OFEX_REGI OFbranchtarget[3]
load net branchtarget_top[4] -attr @rip branchtarget[4] -pin IMMEDIATEBRANCH branchtarget[4] -pin OFEX_REGI OFbranchtarget[4]
load net branchtarget_top[5] -attr @rip branchtarget[5] -pin IMMEDIATEBRANCH branchtarget[5] -pin OFEX_REGI OFbranchtarget[5]
load net branchtarget_top[6] -attr @rip branchtarget[6] -pin IMMEDIATEBRANCH branchtarget[6] -pin OFEX_REGI OFbranchtarget[6]
load net branchtarget_top[7] -attr @rip branchtarget[7] -pin IMMEDIATEBRANCH branchtarget[7] -pin OFEX_REGI OFbranchtarget[7]
load net branchtarget_top[8] -attr @rip branchtarget[8] -pin IMMEDIATEBRANCH branchtarget[8] -pin OFEX_REGI OFbranchtarget[8]
load net branchtarget_top[9] -attr @rip branchtarget[9] -pin IMMEDIATEBRANCH branchtarget[9] -pin OFEX_REGI OFbranchtarget[9]
load net clk -pin BRANCHUNIT clk -pin CONTROLUNIT clk -pin DATAMEMORY clk -pin EXMA_REGI clk -pin FLAGREGISTER clk -pin IFOF_REGI clk -pin INSTRUCTIONFETCH clk -pin INSTRUCTIONMEMORY clk -pin MARW_REGI clk -pin MEMORYUNIT clk -pin OFEX_REGI clk -pin PC clk -pin PC5 clk -pin REGISTERFILE clk -port clk
netloc clk 1 0 16 40 530 290 730 NJ 730 940 530 1290 790 1600 910 2040 610 2450 960 2820 1560 3460 1500 3920 1520 4300 1020 NJ 1020 5080 470 5500J 370 6010J
load net immx_top[0] -attr @rip immx[0] -pin IMMEDIATEBRANCH immx[0] -pin IMMUX i1[0]
load net immx_top[10] -attr @rip immx[10] -pin IMMEDIATEBRANCH immx[10] -pin IMMUX i1[10]
load net immx_top[11] -attr @rip immx[11] -pin IMMEDIATEBRANCH immx[11] -pin IMMUX i1[11]
load net immx_top[12] -attr @rip immx[12] -pin IMMEDIATEBRANCH immx[12] -pin IMMUX i1[12]
load net immx_top[13] -attr @rip immx[13] -pin IMMEDIATEBRANCH immx[13] -pin IMMUX i1[13]
load net immx_top[14] -attr @rip immx[14] -pin IMMEDIATEBRANCH immx[14] -pin IMMUX i1[14]
load net immx_top[15] -attr @rip immx[15] -pin IMMEDIATEBRANCH immx[15] -pin IMMUX i1[15]
load net immx_top[16] -attr @rip immx[16] -pin IMMEDIATEBRANCH immx[16] -pin IMMUX i1[16]
load net immx_top[17] -attr @rip immx[17] -pin IMMEDIATEBRANCH immx[17] -pin IMMUX i1[17]
load net immx_top[18] -attr @rip immx[18] -pin IMMEDIATEBRANCH immx[18] -pin IMMUX i1[18]
load net immx_top[19] -attr @rip immx[19] -pin IMMEDIATEBRANCH immx[19] -pin IMMUX i1[19]
load net immx_top[1] -attr @rip immx[1] -pin IMMEDIATEBRANCH immx[1] -pin IMMUX i1[1]
load net immx_top[20] -attr @rip immx[20] -pin IMMEDIATEBRANCH immx[20] -pin IMMUX i1[20]
load net immx_top[21] -attr @rip immx[21] -pin IMMEDIATEBRANCH immx[21] -pin IMMUX i1[21]
load net immx_top[22] -attr @rip immx[22] -pin IMMEDIATEBRANCH immx[22] -pin IMMUX i1[22]
load net immx_top[23] -attr @rip immx[23] -pin IMMEDIATEBRANCH immx[23] -pin IMMUX i1[23]
load net immx_top[24] -attr @rip immx[24] -pin IMMEDIATEBRANCH immx[24] -pin IMMUX i1[24]
load net immx_top[25] -attr @rip immx[25] -pin IMMEDIATEBRANCH immx[25] -pin IMMUX i1[25]
load net immx_top[26] -attr @rip immx[26] -pin IMMEDIATEBRANCH immx[26] -pin IMMUX i1[26]
load net immx_top[27] -attr @rip immx[27] -pin IMMEDIATEBRANCH immx[27] -pin IMMUX i1[27]
load net immx_top[28] -attr @rip immx[28] -pin IMMEDIATEBRANCH immx[28] -pin IMMUX i1[28]
load net immx_top[29] -attr @rip immx[29] -pin IMMEDIATEBRANCH immx[29] -pin IMMUX i1[29]
load net immx_top[2] -attr @rip immx[2] -pin IMMEDIATEBRANCH immx[2] -pin IMMUX i1[2]
load net immx_top[30] -attr @rip immx[30] -pin IMMEDIATEBRANCH immx[30] -pin IMMUX i1[30]
load net immx_top[31] -attr @rip immx[31] -pin IMMEDIATEBRANCH immx[31] -pin IMMUX i1[31]
load net immx_top[3] -attr @rip immx[3] -pin IMMEDIATEBRANCH immx[3] -pin IMMUX i1[3]
load net immx_top[4] -attr @rip immx[4] -pin IMMEDIATEBRANCH immx[4] -pin IMMUX i1[4]
load net immx_top[5] -attr @rip immx[5] -pin IMMEDIATEBRANCH immx[5] -pin IMMUX i1[5]
load net immx_top[6] -attr @rip immx[6] -pin IMMEDIATEBRANCH immx[6] -pin IMMUX i1[6]
load net immx_top[7] -attr @rip immx[7] -pin IMMEDIATEBRANCH immx[7] -pin IMMUX i1[7]
load net immx_top[8] -attr @rip immx[8] -pin IMMEDIATEBRANCH immx[8] -pin IMMUX i1[8]
load net immx_top[9] -attr @rip immx[9] -pin IMMEDIATEBRANCH immx[9] -pin IMMUX i1[9]
load net instruction1_top[0] -attr @rip OFinstruction[0] -pin IFOF_REGI OFinstruction[0] -pin IMMEDIATEBRANCH instruction[0]
load net instruction1_top[10] -attr @rip OFinstruction[10] -pin IFOF_REGI OFinstruction[10] -pin IMMEDIATEBRANCH instruction[10]
load net instruction1_top[11] -attr @rip OFinstruction[11] -pin IFOF_REGI OFinstruction[11] -pin IMMEDIATEBRANCH instruction[11]
load net instruction1_top[12] -attr @rip OFinstruction[12] -pin IFOF_REGI OFinstruction[12] -pin IMMEDIATEBRANCH instruction[12]
load net instruction1_top[13] -attr @rip OFinstruction[13] -pin IFOF_REGI OFinstruction[13] -pin IMMEDIATEBRANCH instruction[13]
load net instruction1_top[14] -attr @rip OFinstruction[14] -pin IFOF_REGI OFinstruction[14] -pin IMMEDIATEBRANCH instruction[14]
load net instruction1_top[15] -attr @rip OFinstruction[15] -pin IFOF_REGI OFinstruction[15] -pin IMMEDIATEBRANCH instruction[15]
load net instruction1_top[16] -attr @rip OFinstruction[16] -pin IFOF_REGI OFinstruction[16] -pin IMMEDIATEBRANCH instruction[16]
load net instruction1_top[17] -attr @rip OFinstruction[17] -pin IFOF_REGI OFinstruction[17] -pin IMMEDIATEBRANCH instruction[17]
load net instruction1_top[18] -attr @rip OFinstruction[18] -pin IFOF_REGI OFinstruction[18] -pin IMMEDIATEBRANCH instruction[18]
load net instruction1_top[19] -attr @rip OFinstruction[19] -pin IFOF_REGI OFinstruction[19] -pin IMMEDIATEBRANCH instruction[19]
load net instruction1_top[1] -attr @rip OFinstruction[1] -pin IFOF_REGI OFinstruction[1] -pin IMMEDIATEBRANCH instruction[1]
load net instruction1_top[20] -attr @rip OFinstruction[20] -pin IFOF_REGI OFinstruction[20] -pin IMMEDIATEBRANCH instruction[20]
load net instruction1_top[21] -attr @rip OFinstruction[21] -pin IFOF_REGI OFinstruction[21] -pin IMMEDIATEBRANCH instruction[21]
load net instruction1_top[22] -attr @rip OFinstruction[22] -pin IFOF_REGI OFinstruction[22] -pin IMMEDIATEBRANCH instruction[22]
load net instruction1_top[23] -attr @rip OFinstruction[23] -pin IFOF_REGI OFinstruction[23] -pin IMMEDIATEBRANCH instruction[23]
load net instruction1_top[24] -attr @rip OFinstruction[24] -pin IFOF_REGI OFinstruction[24] -pin IMMEDIATEBRANCH instruction[24]
load net instruction1_top[25] -attr @rip OFinstruction[25] -pin IFOF_REGI OFinstruction[25] -pin IMMEDIATEBRANCH instruction[25]
load net instruction1_top[26] -attr @rip OFinstruction[26] -pin IFOF_REGI OFinstruction[26] -pin IMMEDIATEBRANCH instruction[26]
load net instruction1_top[27] -attr @rip OFinstruction[27] -pin IFOF_REGI OFinstruction[27] -pin IMMEDIATEBRANCH instruction[27]
load net instruction1_top[28] -attr @rip OFinstruction[28] -pin IFOF_REGI OFinstruction[28] -pin IMMEDIATEBRANCH instruction[28]
load net instruction1_top[29] -attr @rip OFinstruction[29] -pin IFOF_REGI OFinstruction[29] -pin IMMEDIATEBRANCH instruction[29]
load net instruction1_top[2] -attr @rip OFinstruction[2] -pin IFOF_REGI OFinstruction[2] -pin IMMEDIATEBRANCH instruction[2]
load net instruction1_top[30] -attr @rip OFinstruction[30] -pin IFOF_REGI OFinstruction[30] -pin IMMEDIATEBRANCH instruction[30]
load net instruction1_top[31] -attr @rip OFinstruction[31] -pin IFOF_REGI OFinstruction[31] -pin IMMEDIATEBRANCH instruction[31]
load net instruction1_top[3] -attr @rip OFinstruction[3] -pin IFOF_REGI OFinstruction[3] -pin IMMEDIATEBRANCH instruction[3]
load net instruction1_top[4] -attr @rip OFinstruction[4] -pin IFOF_REGI OFinstruction[4] -pin IMMEDIATEBRANCH instruction[4]
load net instruction1_top[5] -attr @rip OFinstruction[5] -pin IFOF_REGI OFinstruction[5] -pin IMMEDIATEBRANCH instruction[5]
load net instruction1_top[6] -attr @rip OFinstruction[6] -pin IFOF_REGI OFinstruction[6] -pin IMMEDIATEBRANCH instruction[6]
load net instruction1_top[7] -attr @rip OFinstruction[7] -pin IFOF_REGI OFinstruction[7] -pin IMMEDIATEBRANCH instruction[7]
load net instruction1_top[8] -attr @rip OFinstruction[8] -pin IFOF_REGI OFinstruction[8] -pin IMMEDIATEBRANCH instruction[8]
load net instruction1_top[9] -attr @rip OFinstruction[9] -pin IFOF_REGI OFinstruction[9] -pin IMMEDIATEBRANCH instruction[9]
load net instruction_top[0] -attr @rip instruction[0] -pin IFOF_REGI IFinstruction[0] -pin INSTRUCTIONFETCH instruction[0] -pin INSTRUCTIONMEMORY instruction[0]
load net instruction_top[10] -attr @rip instruction[10] -pin IFOF_REGI IFinstruction[10] -pin INSTRUCTIONFETCH instruction[10] -pin INSTRUCTIONMEMORY instruction[10]
load net instruction_top[11] -attr @rip instruction[11] -pin IFOF_REGI IFinstruction[11] -pin INSTRUCTIONFETCH instruction[11] -pin INSTRUCTIONMEMORY instruction[11]
load net instruction_top[12] -attr @rip instruction[12] -pin IFOF_REGI IFinstruction[12] -pin INSTRUCTIONFETCH instruction[12] -pin INSTRUCTIONMEMORY instruction[12]
load net instruction_top[13] -attr @rip instruction[13] -pin IFOF_REGI IFinstruction[13] -pin INSTRUCTIONFETCH instruction[13] -pin INSTRUCTIONMEMORY instruction[13]
load net instruction_top[14] -attr @rip instruction[14] -pin IFOF_REGI IFinstruction[14] -pin INSTRUCTIONFETCH instruction[14] -pin INSTRUCTIONMEMORY instruction[14]
load net instruction_top[15] -attr @rip instruction[15] -pin IFOF_REGI IFinstruction[15] -pin INSTRUCTIONFETCH instruction[15] -pin INSTRUCTIONMEMORY instruction[15]
load net instruction_top[16] -attr @rip instruction[16] -pin IFOF_REGI IFinstruction[16] -pin INSTRUCTIONFETCH instruction[16] -pin INSTRUCTIONMEMORY instruction[16]
load net instruction_top[17] -attr @rip instruction[17] -pin IFOF_REGI IFinstruction[17] -pin INSTRUCTIONFETCH instruction[17] -pin INSTRUCTIONMEMORY instruction[17]
load net instruction_top[18] -attr @rip instruction[18] -pin IFOF_REGI IFinstruction[18] -pin INSTRUCTIONFETCH instruction[18] -pin INSTRUCTIONMEMORY instruction[18]
load net instruction_top[19] -attr @rip instruction[19] -pin IFOF_REGI IFinstruction[19] -pin INSTRUCTIONFETCH instruction[19] -pin INSTRUCTIONMEMORY instruction[19]
load net instruction_top[1] -attr @rip instruction[1] -pin IFOF_REGI IFinstruction[1] -pin INSTRUCTIONFETCH instruction[1] -pin INSTRUCTIONMEMORY instruction[1]
load net instruction_top[20] -attr @rip instruction[20] -pin IFOF_REGI IFinstruction[20] -pin INSTRUCTIONFETCH instruction[20] -pin INSTRUCTIONMEMORY instruction[20]
load net instruction_top[21] -attr @rip instruction[21] -pin IFOF_REGI IFinstruction[21] -pin INSTRUCTIONFETCH instruction[21] -pin INSTRUCTIONMEMORY instruction[21]
load net instruction_top[22] -attr @rip instruction[22] -pin IFOF_REGI IFinstruction[22] -pin INSTRUCTIONFETCH instruction[22] -pin INSTRUCTIONMEMORY instruction[22]
load net instruction_top[23] -attr @rip instruction[23] -pin IFOF_REGI IFinstruction[23] -pin INSTRUCTIONFETCH instruction[23] -pin INSTRUCTIONMEMORY instruction[23]
load net instruction_top[24] -attr @rip instruction[24] -pin IFOF_REGI IFinstruction[24] -pin INSTRUCTIONFETCH instruction[24] -pin INSTRUCTIONMEMORY instruction[24]
load net instruction_top[25] -attr @rip instruction[25] -pin IFOF_REGI IFinstruction[25] -pin INSTRUCTIONFETCH instruction[25] -pin INSTRUCTIONMEMORY instruction[25]
load net instruction_top[26] -attr @rip instruction[26] -pin IFOF_REGI IFinstruction[26] -pin INSTRUCTIONFETCH instruction[26] -pin INSTRUCTIONMEMORY instruction[26]
load net instruction_top[27] -attr @rip instruction[27] -pin IFOF_REGI IFinstruction[27] -pin INSTRUCTIONFETCH instruction[27] -pin INSTRUCTIONMEMORY instruction[27]
load net instruction_top[28] -attr @rip instruction[28] -pin IFOF_REGI IFinstruction[28] -pin INSTRUCTIONFETCH instruction[28] -pin INSTRUCTIONMEMORY instruction[28]
load net instruction_top[29] -attr @rip instruction[29] -pin IFOF_REGI IFinstruction[29] -pin INSTRUCTIONFETCH instruction[29] -pin INSTRUCTIONMEMORY instruction[29]
load net instruction_top[2] -attr @rip instruction[2] -pin IFOF_REGI IFinstruction[2] -pin INSTRUCTIONFETCH instruction[2] -pin INSTRUCTIONMEMORY instruction[2]
load net instruction_top[30] -attr @rip instruction[30] -pin IFOF_REGI IFinstruction[30] -pin INSTRUCTIONFETCH instruction[30] -pin INSTRUCTIONMEMORY instruction[30]
load net instruction_top[31] -attr @rip instruction[31] -pin IFOF_REGI IFinstruction[31] -pin INSTRUCTIONFETCH instruction[31] -pin INSTRUCTIONMEMORY instruction[31]
load net instruction_top[3] -attr @rip instruction[3] -pin IFOF_REGI IFinstruction[3] -pin INSTRUCTIONFETCH instruction[3] -pin INSTRUCTIONMEMORY instruction[3]
load net instruction_top[4] -attr @rip instruction[4] -pin IFOF_REGI IFinstruction[4] -pin INSTRUCTIONFETCH instruction[4] -pin INSTRUCTIONMEMORY instruction[4]
load net instruction_top[5] -attr @rip instruction[5] -pin IFOF_REGI IFinstruction[5] -pin INSTRUCTIONFETCH instruction[5] -pin INSTRUCTIONMEMORY instruction[5]
load net instruction_top[6] -attr @rip instruction[6] -pin IFOF_REGI IFinstruction[6] -pin INSTRUCTIONFETCH instruction[6] -pin INSTRUCTIONMEMORY instruction[6]
load net instruction_top[7] -attr @rip instruction[7] -pin IFOF_REGI IFinstruction[7] -pin INSTRUCTIONFETCH instruction[7] -pin INSTRUCTIONMEMORY instruction[7]
load net instruction_top[8] -attr @rip instruction[8] -pin IFOF_REGI IFinstruction[8] -pin INSTRUCTIONFETCH instruction[8] -pin INSTRUCTIONMEMORY instruction[8]
load net instruction_top[9] -attr @rip instruction[9] -pin IFOF_REGI IFinstruction[9] -pin INSTRUCTIONFETCH instruction[9] -pin INSTRUCTIONMEMORY instruction[9]
load net isBeq1_top -pin BRANCHUNIT isBeq -pin OFEX_REGI EXisBeq
netloc isBeq1_top 1 1 16 370 230 NJ 230 NJ 230 NJ 230 NJ 230 NJ 230 NJ 230 NJ 230 NJ 230 NJ 230 NJ 230 NJ 230 NJ 230 NJ 230 5910J 470 6570
load net isBeq_top -pin CONTROLUNIT isBeq -pin OFEX_REGI OFisBeq
netloc isBeq_top 1 8 8 2900 150 NJ 150 NJ 150 NJ 150 NJ 150 NJ 150 NJ 150 NJ
load net isBgt1_top -pin BRANCHUNIT isBgt -pin OFEX_REGI EXisBgt
netloc isBgt1_top 1 1 16 350 750 NJ 750 NJ 750 NJ 750 1580J 690 NJ 690 NJ 690 NJ 690 NJ 690 NJ 690 NJ 690 NJ 690 NJ 690 NJ 690 NJ 690 6690
load net isBgt_top -pin CONTROLUNIT isBgt -pin OFEX_REGI OFisBgt
netloc isBgt_top 1 8 8 2920 170 NJ 170 NJ 170 NJ 170 NJ 170 NJ 170 NJ 170 NJ
load net isBranchTaken_top -pin BRANCHUNIT isBranchTaken -pin PCMUX s0
netloc isBranchTaken_top 1 2 1 670 430n
load net isCall1_top -pin EXMA_REGI EXisCall -pin OFEX_REGI EXisCall
netloc isCall1_top 1 8 9 2960 1100 NJ 1100 NJ 1100 NJ 1100 NJ 1100 NJ 1100 NJ 1100 NJ 1100 6590
load net isCall2_top -pin EXMA_REGI MAisCall -pin MARW_REGI MAisCall
netloc isCall2_top 1 9 2 NJ 1260 3920
load net isCall3_top -pin MARW_REGI RWisCall -pin MUX4TO1 s0
netloc isCall3_top 1 11 2 4340 1360 NJ
load net isCall_top -pin CONTROLUNIT isCall -pin MUX3 s0 -pin OFEX_REGI OFisCall
netloc isCall_top 1 8 8 2960 960 NJ 960 NJ 960 NJ 960 4770 350 NJ 350 NJ 350 5890
load net isImmediate1_top -pin IFOF_REGI OFisImmediate -pin IMMUX s0
netloc isImmediate1_top 1 7 8 2490J 610 NJ 610 NJ 610 NJ 610 NJ 610 NJ 610 NJ 610 5560
load net isImmediate_top -pin IFOF_REGI IFisImmediate -pin INSTRUCTIONFETCH isImmediate
netloc isImmediate_top 1 6 1 1920 430n
load net isLd2_top -pin EXMA_REGI MAisLd -pin MARW_REGI MAisLd -pin MEMORYUNIT isLd
netloc isLd2_top 1 9 2 3420 1300 3760
load net isLd3_top -pin MARW_REGI RWisLd -pin MUX4TO1 s1
netloc isLd3_top 1 11 2 4280 1380 NJ
load net isLd_top -pin CONTROLUNIT isLd -pin EXMA_REGI EXisLd -pin OFEX_REGI OFisLd
netloc isLd_top 1 8 8 2840 1120 NJ 1120 NJ 1120 NJ 1120 NJ 1120 NJ 1120 NJ 1120 6070
load net isRet1_top -pin BRMUX s0 -pin OFEX_REGI EXisRet
netloc isRet1_top 1 1 16 350 70 NJ 70 NJ 70 NJ 70 NJ 70 NJ 70 NJ 70 2960J 190 NJ 190 NJ 190 NJ 190 NJ 190 NJ 190 5500J 210 6050J 450 6510
load net isRet_top -pin CONTROLUNIT isRet -pin MUX2 s0 -pin OFEX_REGI OFisRet
netloc isRet_top 1 8 8 2920 770 NJ 770 NJ 770 NJ 770 4750 310 NJ 310 NJ 310 5930
load net isSt1_top -pin EXMA_REGI EXisSt -pin OFEX_REGI EXisSt
netloc isSt1_top 1 8 9 2920 1140 NJ 1140 NJ 1140 NJ 1140 NJ 1140 NJ 1140 NJ 1140 NJ 1140 6670
load net isSt2_top -pin EXMA_REGI MAisSt -pin MEMORYUNIT isSt
netloc isSt2_top 1 9 1 3400 1300n
load net isSt_top -pin CONTROLUNIT isSt -pin MUX1 s0 -pin OFEX_REGI OFisSt
netloc isSt_top 1 8 8 2900 570 NJ 570 NJ 570 NJ 570 4710 330 NJ 330 NJ 330 5850
load net isUBranch1_top -pin BRANCHUNIT isUBranch -pin OFEX_REGI EXisUBranch
netloc isUBranch1_top 1 1 16 370 770 NJ 770 NJ 770 NJ 770 1600J 710 NJ 710 NJ 710 NJ 710 NJ 710 NJ 710 NJ 710 NJ 710 NJ 710 NJ 710 NJ 710 6630
load net isUBranch_top -pin CONTROLUNIT isUBranch -pin OFEX_REGI OFisUBranch
netloc isUBranch_top 1 8 8 NJ 490 NJ 490 NJ 490 NJ 490 4670J 410 5120J 490 5500J 530 5970
load net isWb1_top -pin EXMA_REGI EXisWb -pin OFEX_REGI EXisWb
netloc isWb1_top 1 8 9 2940 1160 NJ 1160 NJ 1160 NJ 1160 NJ 1160 NJ 1160 NJ 1160 NJ 1160 6550
load net isWb2_top -pin EXMA_REGI MAisWb -pin MARW_REGI MAisWb
netloc isWb2_top 1 9 2 NJ 1320 3880
load net isWb3_top -pin MARW_REGI RWisWb -pin REGISTERFILE isWb
netloc isWb3_top 1 11 3 4240 1040 NJ 1040 5120J
load net isWb_top -pin CONTROLUNIT isWb -pin OFEX_REGI OFisWb
netloc isWb_top 1 8 8 NJ 510 NJ 510 NJ 510 NJ 510 4730J 430 5040J 510 5480J 550 6030
load net memdataout_top[0] -attr @rip MemData_out[0] -pin DATAMEMORY MemData_out[0] -pin MEMORYUNIT memData[0]
load net memdataout_top[10] -attr @rip MemData_out[10] -pin DATAMEMORY MemData_out[10] -pin MEMORYUNIT memData[10]
load net memdataout_top[11] -attr @rip MemData_out[11] -pin DATAMEMORY MemData_out[11] -pin MEMORYUNIT memData[11]
load net memdataout_top[12] -attr @rip MemData_out[12] -pin DATAMEMORY MemData_out[12] -pin MEMORYUNIT memData[12]
load net memdataout_top[13] -attr @rip MemData_out[13] -pin DATAMEMORY MemData_out[13] -pin MEMORYUNIT memData[13]
load net memdataout_top[14] -attr @rip MemData_out[14] -pin DATAMEMORY MemData_out[14] -pin MEMORYUNIT memData[14]
load net memdataout_top[15] -attr @rip MemData_out[15] -pin DATAMEMORY MemData_out[15] -pin MEMORYUNIT memData[15]
load net memdataout_top[16] -attr @rip MemData_out[16] -pin DATAMEMORY MemData_out[16] -pin MEMORYUNIT memData[16]
load net memdataout_top[17] -attr @rip MemData_out[17] -pin DATAMEMORY MemData_out[17] -pin MEMORYUNIT memData[17]
load net memdataout_top[18] -attr @rip MemData_out[18] -pin DATAMEMORY MemData_out[18] -pin MEMORYUNIT memData[18]
load net memdataout_top[19] -attr @rip MemData_out[19] -pin DATAMEMORY MemData_out[19] -pin MEMORYUNIT memData[19]
load net memdataout_top[1] -attr @rip MemData_out[1] -pin DATAMEMORY MemData_out[1] -pin MEMORYUNIT memData[1]
load net memdataout_top[20] -attr @rip MemData_out[20] -pin DATAMEMORY MemData_out[20] -pin MEMORYUNIT memData[20]
load net memdataout_top[21] -attr @rip MemData_out[21] -pin DATAMEMORY MemData_out[21] -pin MEMORYUNIT memData[21]
load net memdataout_top[22] -attr @rip MemData_out[22] -pin DATAMEMORY MemData_out[22] -pin MEMORYUNIT memData[22]
load net memdataout_top[23] -attr @rip MemData_out[23] -pin DATAMEMORY MemData_out[23] -pin MEMORYUNIT memData[23]
load net memdataout_top[24] -attr @rip MemData_out[24] -pin DATAMEMORY MemData_out[24] -pin MEMORYUNIT memData[24]
load net memdataout_top[25] -attr @rip MemData_out[25] -pin DATAMEMORY MemData_out[25] -pin MEMORYUNIT memData[25]
load net memdataout_top[26] -attr @rip MemData_out[26] -pin DATAMEMORY MemData_out[26] -pin MEMORYUNIT memData[26]
load net memdataout_top[27] -attr @rip MemData_out[27] -pin DATAMEMORY MemData_out[27] -pin MEMORYUNIT memData[27]
load net memdataout_top[28] -attr @rip MemData_out[28] -pin DATAMEMORY MemData_out[28] -pin MEMORYUNIT memData[28]
load net memdataout_top[29] -attr @rip MemData_out[29] -pin DATAMEMORY MemData_out[29] -pin MEMORYUNIT memData[29]
load net memdataout_top[2] -attr @rip MemData_out[2] -pin DATAMEMORY MemData_out[2] -pin MEMORYUNIT memData[2]
load net memdataout_top[30] -attr @rip MemData_out[30] -pin DATAMEMORY MemData_out[30] -pin MEMORYUNIT memData[30]
load net memdataout_top[31] -attr @rip MemData_out[31] -pin DATAMEMORY MemData_out[31] -pin MEMORYUNIT memData[31]
load net memdataout_top[3] -attr @rip MemData_out[3] -pin DATAMEMORY MemData_out[3] -pin MEMORYUNIT memData[3]
load net memdataout_top[4] -attr @rip MemData_out[4] -pin DATAMEMORY MemData_out[4] -pin MEMORYUNIT memData[4]
load net memdataout_top[5] -attr @rip MemData_out[5] -pin DATAMEMORY MemData_out[5] -pin MEMORYUNIT memData[5]
load net memdataout_top[6] -attr @rip MemData_out[6] -pin DATAMEMORY MemData_out[6] -pin MEMORYUNIT memData[6]
load net memdataout_top[7] -attr @rip MemData_out[7] -pin DATAMEMORY MemData_out[7] -pin MEMORYUNIT memData[7]
load net memdataout_top[8] -attr @rip MemData_out[8] -pin DATAMEMORY MemData_out[8] -pin MEMORYUNIT memData[8]
load net memdataout_top[9] -attr @rip MemData_out[9] -pin DATAMEMORY MemData_out[9] -pin MEMORYUNIT memData[9]
load net mux1_top[0] -attr @rip o[0] -pin MUX1 o[0] -pin REGISTERFILE mux1[0]
load net mux1_top[1] -attr @rip o[1] -pin MUX1 o[1] -pin REGISTERFILE mux1[1]
load net mux1_top[2] -attr @rip o[2] -pin MUX1 o[2] -pin REGISTERFILE mux1[2]
load net mux1_top[3] -attr @rip o[3] -pin MUX1 o[3] -pin REGISTERFILE mux1[3]
load net mux2_top[0] -attr @rip o[0] -pin MUX2 o[0] -pin REGISTERFILE mux2[0]
load net mux2_top[1] -attr @rip o[1] -pin MUX2 o[1] -pin REGISTERFILE mux2[1]
load net mux2_top[2] -attr @rip o[2] -pin MUX2 o[2] -pin REGISTERFILE mux2[2]
load net mux2_top[3] -attr @rip o[3] -pin MUX2 o[3] -pin REGISTERFILE mux2[3]
load net mux3_top[0] -attr @rip o[0] -pin MUX3 o[0] -pin REGISTERFILE mux3[0]
load net mux3_top[1] -attr @rip o[1] -pin MUX3 o[1] -pin REGISTERFILE mux3[1]
load net mux3_top[2] -attr @rip o[2] -pin MUX3 o[2] -pin REGISTERFILE mux3[2]
load net mux3_top[3] -attr @rip o[3] -pin MUX3 o[3] -pin REGISTERFILE mux3[3]
load net op11_top[0] -attr @rip EXA[0] -pin ALU A[0] -pin BRMUX i1[0] -pin OFEX_REGI EXA[0]
load net op11_top[1] -attr @rip EXA[1] -pin ALU A[1] -pin BRMUX i1[1] -pin OFEX_REGI EXA[1]
load net op11_top[2] -attr @rip EXA[2] -pin ALU A[2] -pin BRMUX i1[2] -pin OFEX_REGI EXA[2]
load net op11_top[3] -attr @rip EXA[3] -pin ALU A[3] -pin BRMUX i1[3] -pin OFEX_REGI EXA[3]
load net op1_top[0] -attr @rip op1[0] -pin OFEX_REGI OFA[0] -pin REGISTERFILE op1[0]
load net op1_top[10] -attr @rip op1[10] -pin OFEX_REGI OFA[10] -pin REGISTERFILE op1[10]
load net op1_top[11] -attr @rip op1[11] -pin OFEX_REGI OFA[11] -pin REGISTERFILE op1[11]
load net op1_top[12] -attr @rip op1[12] -pin OFEX_REGI OFA[12] -pin REGISTERFILE op1[12]
load net op1_top[13] -attr @rip op1[13] -pin OFEX_REGI OFA[13] -pin REGISTERFILE op1[13]
load net op1_top[14] -attr @rip op1[14] -pin OFEX_REGI OFA[14] -pin REGISTERFILE op1[14]
load net op1_top[15] -attr @rip op1[15] -pin OFEX_REGI OFA[15] -pin REGISTERFILE op1[15]
load net op1_top[16] -attr @rip op1[16] -pin OFEX_REGI OFA[16] -pin REGISTERFILE op1[16]
load net op1_top[17] -attr @rip op1[17] -pin OFEX_REGI OFA[17] -pin REGISTERFILE op1[17]
load net op1_top[18] -attr @rip op1[18] -pin OFEX_REGI OFA[18] -pin REGISTERFILE op1[18]
load net op1_top[19] -attr @rip op1[19] -pin OFEX_REGI OFA[19] -pin REGISTERFILE op1[19]
load net op1_top[1] -attr @rip op1[1] -pin OFEX_REGI OFA[1] -pin REGISTERFILE op1[1]
load net op1_top[20] -attr @rip op1[20] -pin OFEX_REGI OFA[20] -pin REGISTERFILE op1[20]
load net op1_top[21] -attr @rip op1[21] -pin OFEX_REGI OFA[21] -pin REGISTERFILE op1[21]
load net op1_top[22] -attr @rip op1[22] -pin OFEX_REGI OFA[22] -pin REGISTERFILE op1[22]
load net op1_top[23] -attr @rip op1[23] -pin OFEX_REGI OFA[23] -pin REGISTERFILE op1[23]
load net op1_top[24] -attr @rip op1[24] -pin OFEX_REGI OFA[24] -pin REGISTERFILE op1[24]
load net op1_top[25] -attr @rip op1[25] -pin OFEX_REGI OFA[25] -pin REGISTERFILE op1[25]
load net op1_top[26] -attr @rip op1[26] -pin OFEX_REGI OFA[26] -pin REGISTERFILE op1[26]
load net op1_top[27] -attr @rip op1[27] -pin OFEX_REGI OFA[27] -pin REGISTERFILE op1[27]
load net op1_top[28] -attr @rip op1[28] -pin OFEX_REGI OFA[28] -pin REGISTERFILE op1[28]
load net op1_top[29] -attr @rip op1[29] -pin OFEX_REGI OFA[29] -pin REGISTERFILE op1[29]
load net op1_top[2] -attr @rip op1[2] -pin OFEX_REGI OFA[2] -pin REGISTERFILE op1[2]
load net op1_top[30] -attr @rip op1[30] -pin OFEX_REGI OFA[30] -pin REGISTERFILE op1[30]
load net op1_top[31] -attr @rip op1[31] -pin OFEX_REGI OFA[31] -pin REGISTERFILE op1[31]
load net op1_top[3] -attr @rip op1[3] -pin OFEX_REGI OFA[3] -pin REGISTERFILE op1[3]
load net op1_top[4] -attr @rip op1[4] -pin OFEX_REGI OFA[4] -pin REGISTERFILE op1[4]
load net op1_top[5] -attr @rip op1[5] -pin OFEX_REGI OFA[5] -pin REGISTERFILE op1[5]
load net op1_top[6] -attr @rip op1[6] -pin OFEX_REGI OFA[6] -pin REGISTERFILE op1[6]
load net op1_top[7] -attr @rip op1[7] -pin OFEX_REGI OFA[7] -pin REGISTERFILE op1[7]
load net op1_top[8] -attr @rip op1[8] -pin OFEX_REGI OFA[8] -pin REGISTERFILE op1[8]
load net op1_top[9] -attr @rip op1[9] -pin OFEX_REGI OFA[9] -pin REGISTERFILE op1[9]
load net op21_top[0] -attr @rip EXop2[0] -pin EXMA_REGI EXop2[0] -pin OFEX_REGI EXop2[0]
load net op21_top[1] -attr @rip EXop2[1] -pin EXMA_REGI EXop2[1] -pin OFEX_REGI EXop2[1]
load net op21_top[2] -attr @rip EXop2[2] -pin EXMA_REGI EXop2[2] -pin OFEX_REGI EXop2[2]
load net op21_top[3] -attr @rip EXop2[3] -pin EXMA_REGI EXop2[3] -pin OFEX_REGI EXop2[3]
load net op22_top[0] -attr @rip MAop2[0] -pin EXMA_REGI MAop2[0] -pin MEMORYUNIT op2[0]
load net op22_top[1] -attr @rip MAop2[1] -pin EXMA_REGI MAop2[1] -pin MEMORYUNIT op2[1]
load net op22_top[2] -attr @rip MAop2[2] -pin EXMA_REGI MAop2[2] -pin MEMORYUNIT op2[2]
load net op22_top[3] -attr @rip MAop2[3] -pin EXMA_REGI MAop2[3] -pin MEMORYUNIT op2[3]
load net op2_top[0] -attr @rip op2[0] -pin IMMUX i0[0] -pin OFEX_REGI OFop2[0] -pin REGISTERFILE op2[0]
load net op2_top[10] -attr @rip op2[10] -pin IMMUX i0[10] -pin OFEX_REGI OFop2[10] -pin REGISTERFILE op2[10]
load net op2_top[11] -attr @rip op2[11] -pin IMMUX i0[11] -pin OFEX_REGI OFop2[11] -pin REGISTERFILE op2[11]
load net op2_top[12] -attr @rip op2[12] -pin IMMUX i0[12] -pin OFEX_REGI OFop2[12] -pin REGISTERFILE op2[12]
load net op2_top[13] -attr @rip op2[13] -pin IMMUX i0[13] -pin OFEX_REGI OFop2[13] -pin REGISTERFILE op2[13]
load net op2_top[14] -attr @rip op2[14] -pin IMMUX i0[14] -pin OFEX_REGI OFop2[14] -pin REGISTERFILE op2[14]
load net op2_top[15] -attr @rip op2[15] -pin IMMUX i0[15] -pin OFEX_REGI OFop2[15] -pin REGISTERFILE op2[15]
load net op2_top[16] -attr @rip op2[16] -pin IMMUX i0[16] -pin OFEX_REGI OFop2[16] -pin REGISTERFILE op2[16]
load net op2_top[17] -attr @rip op2[17] -pin IMMUX i0[17] -pin OFEX_REGI OFop2[17] -pin REGISTERFILE op2[17]
load net op2_top[18] -attr @rip op2[18] -pin IMMUX i0[18] -pin OFEX_REGI OFop2[18] -pin REGISTERFILE op2[18]
load net op2_top[19] -attr @rip op2[19] -pin IMMUX i0[19] -pin OFEX_REGI OFop2[19] -pin REGISTERFILE op2[19]
load net op2_top[1] -attr @rip op2[1] -pin IMMUX i0[1] -pin OFEX_REGI OFop2[1] -pin REGISTERFILE op2[1]
load net op2_top[20] -attr @rip op2[20] -pin IMMUX i0[20] -pin OFEX_REGI OFop2[20] -pin REGISTERFILE op2[20]
load net op2_top[21] -attr @rip op2[21] -pin IMMUX i0[21] -pin OFEX_REGI OFop2[21] -pin REGISTERFILE op2[21]
load net op2_top[22] -attr @rip op2[22] -pin IMMUX i0[22] -pin OFEX_REGI OFop2[22] -pin REGISTERFILE op2[22]
load net op2_top[23] -attr @rip op2[23] -pin IMMUX i0[23] -pin OFEX_REGI OFop2[23] -pin REGISTERFILE op2[23]
load net op2_top[24] -attr @rip op2[24] -pin IMMUX i0[24] -pin OFEX_REGI OFop2[24] -pin REGISTERFILE op2[24]
load net op2_top[25] -attr @rip op2[25] -pin IMMUX i0[25] -pin OFEX_REGI OFop2[25] -pin REGISTERFILE op2[25]
load net op2_top[26] -attr @rip op2[26] -pin IMMUX i0[26] -pin OFEX_REGI OFop2[26] -pin REGISTERFILE op2[26]
load net op2_top[27] -attr @rip op2[27] -pin IMMUX i0[27] -pin OFEX_REGI OFop2[27] -pin REGISTERFILE op2[27]
load net op2_top[28] -attr @rip op2[28] -pin IMMUX i0[28] -pin OFEX_REGI OFop2[28] -pin REGISTERFILE op2[28]
load net op2_top[29] -attr @rip op2[29] -pin IMMUX i0[29] -pin OFEX_REGI OFop2[29] -pin REGISTERFILE op2[29]
load net op2_top[2] -attr @rip op2[2] -pin IMMUX i0[2] -pin OFEX_REGI OFop2[2] -pin REGISTERFILE op2[2]
load net op2_top[30] -attr @rip op2[30] -pin IMMUX i0[30] -pin OFEX_REGI OFop2[30] -pin REGISTERFILE op2[30]
load net op2_top[31] -attr @rip op2[31] -pin IMMUX i0[31] -pin OFEX_REGI OFop2[31] -pin REGISTERFILE op2[31]
load net op2_top[3] -attr @rip op2[3] -pin IMMUX i0[3] -pin OFEX_REGI OFop2[3] -pin REGISTERFILE op2[3]
load net op2_top[4] -attr @rip op2[4] -pin IMMUX i0[4] -pin OFEX_REGI OFop2[4] -pin REGISTERFILE op2[4]
load net op2_top[5] -attr @rip op2[5] -pin IMMUX i0[5] -pin OFEX_REGI OFop2[5] -pin REGISTERFILE op2[5]
load net op2_top[6] -attr @rip op2[6] -pin IMMUX i0[6] -pin OFEX_REGI OFop2[6] -pin REGISTERFILE op2[6]
load net op2_top[7] -attr @rip op2[7] -pin IMMUX i0[7] -pin OFEX_REGI OFop2[7] -pin REGISTERFILE op2[7]
load net op2_top[8] -attr @rip op2[8] -pin IMMUX i0[8] -pin OFEX_REGI OFop2[8] -pin REGISTERFILE op2[8]
load net op2_top[9] -attr @rip op2[9] -pin IMMUX i0[9] -pin OFEX_REGI OFop2[9] -pin REGISTERFILE op2[9]
load net opcode1_top[0] -attr @rip OFopcode[0] -pin CONTROLUNIT opcode[0] -pin IFOF_REGI OFopcode[0] -pin OFEX_REGI OFopcode[0]
load net opcode1_top[1] -attr @rip OFopcode[1] -pin CONTROLUNIT opcode[1] -pin IFOF_REGI OFopcode[1] -pin OFEX_REGI OFopcode[1]
load net opcode1_top[2] -attr @rip OFopcode[2] -pin CONTROLUNIT opcode[2] -pin IFOF_REGI OFopcode[2] -pin OFEX_REGI OFopcode[2]
load net opcode1_top[3] -attr @rip OFopcode[3] -pin CONTROLUNIT opcode[3] -pin IFOF_REGI OFopcode[3] -pin OFEX_REGI OFopcode[3]
load net opcode1_top[4] -attr @rip OFopcode[4] -pin CONTROLUNIT opcode[4] -pin IFOF_REGI OFopcode[4] -pin OFEX_REGI OFopcode[4]
load net opcode2_top[0] -attr @rip EXopcode[0] -pin ALU aluSignals[0] -pin OFEX_REGI EXopcode[0]
load net opcode2_top[1] -attr @rip EXopcode[1] -pin ALU aluSignals[1] -pin OFEX_REGI EXopcode[1]
load net opcode2_top[2] -attr @rip EXopcode[2] -pin ALU aluSignals[2] -pin OFEX_REGI EXopcode[2]
load net opcode2_top[3] -attr @rip EXopcode[3] -pin ALU aluSignals[3] -pin OFEX_REGI EXopcode[3]
load net opcode2_top[4] -attr @rip EXopcode[4] -pin ALU aluSignals[4] -pin OFEX_REGI EXopcode[4]
load net opcode_top[0] -attr @rip opcode[0] -pin IFOF_REGI IFopcode[0] -pin INSTRUCTIONFETCH opcode[0]
load net opcode_top[1] -attr @rip opcode[1] -pin IFOF_REGI IFopcode[1] -pin INSTRUCTIONFETCH opcode[1]
load net opcode_top[2] -attr @rip opcode[2] -pin IFOF_REGI IFopcode[2] -pin INSTRUCTIONFETCH opcode[2]
load net opcode_top[3] -attr @rip opcode[3] -pin IFOF_REGI IFopcode[3] -pin INSTRUCTIONFETCH opcode[3]
load net opcode_top[4] -attr @rip opcode[4] -pin IFOF_REGI IFopcode[4] -pin INSTRUCTIONFETCH opcode[4]
load net overflow_in_top -pin ALU overflow -pin FLAGREGISTER overflow_in
netloc overflow_in_top 1 0 18 80 490 NJ 490 650J 530 920J 570 1270J 590 NJ 590 2000J 650 NJ 650 NJ 650 NJ 650 NJ 650 NJ 650 NJ 650 NJ 650 NJ 650 NJ 650 NJ 650 7140
load net pcplus45_top[0] -attr @rip pcplus4[0] -pin MUX4TO1 i2[0] -pin PC5 pcplus4[0]
load net pcplus45_top[10] -attr @rip pcplus4[10] -pin MUX4TO1 i2[10] -pin PC5 pcplus4[10]
load net pcplus45_top[11] -attr @rip pcplus4[11] -pin MUX4TO1 i2[11] -pin PC5 pcplus4[11]
load net pcplus45_top[12] -attr @rip pcplus4[12] -pin MUX4TO1 i2[12] -pin PC5 pcplus4[12]
load net pcplus45_top[13] -attr @rip pcplus4[13] -pin MUX4TO1 i2[13] -pin PC5 pcplus4[13]
load net pcplus45_top[14] -attr @rip pcplus4[14] -pin MUX4TO1 i2[14] -pin PC5 pcplus4[14]
load net pcplus45_top[15] -attr @rip pcplus4[15] -pin MUX4TO1 i2[15] -pin PC5 pcplus4[15]
load net pcplus45_top[16] -attr @rip pcplus4[16] -pin MUX4TO1 i2[16] -pin PC5 pcplus4[16]
load net pcplus45_top[17] -attr @rip pcplus4[17] -pin MUX4TO1 i2[17] -pin PC5 pcplus4[17]
load net pcplus45_top[18] -attr @rip pcplus4[18] -pin MUX4TO1 i2[18] -pin PC5 pcplus4[18]
load net pcplus45_top[19] -attr @rip pcplus4[19] -pin MUX4TO1 i2[19] -pin PC5 pcplus4[19]
load net pcplus45_top[1] -attr @rip pcplus4[1] -pin MUX4TO1 i2[1] -pin PC5 pcplus4[1]
load net pcplus45_top[20] -attr @rip pcplus4[20] -pin MUX4TO1 i2[20] -pin PC5 pcplus4[20]
load net pcplus45_top[21] -attr @rip pcplus4[21] -pin MUX4TO1 i2[21] -pin PC5 pcplus4[21]
load net pcplus45_top[22] -attr @rip pcplus4[22] -pin MUX4TO1 i2[22] -pin PC5 pcplus4[22]
load net pcplus45_top[23] -attr @rip pcplus4[23] -pin MUX4TO1 i2[23] -pin PC5 pcplus4[23]
load net pcplus45_top[24] -attr @rip pcplus4[24] -pin MUX4TO1 i2[24] -pin PC5 pcplus4[24]
load net pcplus45_top[25] -attr @rip pcplus4[25] -pin MUX4TO1 i2[25] -pin PC5 pcplus4[25]
load net pcplus45_top[26] -attr @rip pcplus4[26] -pin MUX4TO1 i2[26] -pin PC5 pcplus4[26]
load net pcplus45_top[27] -attr @rip pcplus4[27] -pin MUX4TO1 i2[27] -pin PC5 pcplus4[27]
load net pcplus45_top[28] -attr @rip pcplus4[28] -pin MUX4TO1 i2[28] -pin PC5 pcplus4[28]
load net pcplus45_top[29] -attr @rip pcplus4[29] -pin MUX4TO1 i2[29] -pin PC5 pcplus4[29]
load net pcplus45_top[2] -attr @rip pcplus4[2] -pin MUX4TO1 i2[2] -pin PC5 pcplus4[2]
load net pcplus45_top[30] -attr @rip pcplus4[30] -pin MUX4TO1 i2[30] -pin PC5 pcplus4[30]
load net pcplus45_top[31] -attr @rip pcplus4[31] -pin MUX4TO1 i2[31] -pin PC5 pcplus4[31]
load net pcplus45_top[3] -attr @rip pcplus4[3] -pin MUX4TO1 i2[3] -pin PC5 pcplus4[3]
load net pcplus45_top[4] -attr @rip pcplus4[4] -pin MUX4TO1 i2[4] -pin PC5 pcplus4[4]
load net pcplus45_top[5] -attr @rip pcplus4[5] -pin MUX4TO1 i2[5] -pin PC5 pcplus4[5]
load net pcplus45_top[6] -attr @rip pcplus4[6] -pin MUX4TO1 i2[6] -pin PC5 pcplus4[6]
load net pcplus45_top[7] -attr @rip pcplus4[7] -pin MUX4TO1 i2[7] -pin PC5 pcplus4[7]
load net pcplus45_top[8] -attr @rip pcplus4[8] -pin MUX4TO1 i2[8] -pin PC5 pcplus4[8]
load net pcplus45_top[9] -attr @rip pcplus4[9] -pin MUX4TO1 i2[9] -pin PC5 pcplus4[9]
load net pcplus4_top[0] -attr @rip pcplus4[0] -pin PC pcplus4[0] -pin PCMUX i0[0]
load net pcplus4_top[10] -attr @rip pcplus4[10] -pin PC pcplus4[10] -pin PCMUX i0[10]
load net pcplus4_top[11] -attr @rip pcplus4[11] -pin PC pcplus4[11] -pin PCMUX i0[11]
load net pcplus4_top[12] -attr @rip pcplus4[12] -pin PC pcplus4[12] -pin PCMUX i0[12]
load net pcplus4_top[13] -attr @rip pcplus4[13] -pin PC pcplus4[13] -pin PCMUX i0[13]
load net pcplus4_top[14] -attr @rip pcplus4[14] -pin PC pcplus4[14] -pin PCMUX i0[14]
load net pcplus4_top[15] -attr @rip pcplus4[15] -pin PC pcplus4[15] -pin PCMUX i0[15]
load net pcplus4_top[16] -attr @rip pcplus4[16] -pin PC pcplus4[16] -pin PCMUX i0[16]
load net pcplus4_top[17] -attr @rip pcplus4[17] -pin PC pcplus4[17] -pin PCMUX i0[17]
load net pcplus4_top[18] -attr @rip pcplus4[18] -pin PC pcplus4[18] -pin PCMUX i0[18]
load net pcplus4_top[19] -attr @rip pcplus4[19] -pin PC pcplus4[19] -pin PCMUX i0[19]
load net pcplus4_top[1] -attr @rip pcplus4[1] -pin PC pcplus4[1] -pin PCMUX i0[1]
load net pcplus4_top[20] -attr @rip pcplus4[20] -pin PC pcplus4[20] -pin PCMUX i0[20]
load net pcplus4_top[21] -attr @rip pcplus4[21] -pin PC pcplus4[21] -pin PCMUX i0[21]
load net pcplus4_top[22] -attr @rip pcplus4[22] -pin PC pcplus4[22] -pin PCMUX i0[22]
load net pcplus4_top[23] -attr @rip pcplus4[23] -pin PC pcplus4[23] -pin PCMUX i0[23]
load net pcplus4_top[24] -attr @rip pcplus4[24] -pin PC pcplus4[24] -pin PCMUX i0[24]
load net pcplus4_top[25] -attr @rip pcplus4[25] -pin PC pcplus4[25] -pin PCMUX i0[25]
load net pcplus4_top[26] -attr @rip pcplus4[26] -pin PC pcplus4[26] -pin PCMUX i0[26]
load net pcplus4_top[27] -attr @rip pcplus4[27] -pin PC pcplus4[27] -pin PCMUX i0[27]
load net pcplus4_top[28] -attr @rip pcplus4[28] -pin PC pcplus4[28] -pin PCMUX i0[28]
load net pcplus4_top[29] -attr @rip pcplus4[29] -pin PC pcplus4[29] -pin PCMUX i0[29]
load net pcplus4_top[2] -attr @rip pcplus4[2] -pin PC pcplus4[2] -pin PCMUX i0[2]
load net pcplus4_top[30] -attr @rip pcplus4[30] -pin PC pcplus4[30] -pin PCMUX i0[30]
load net pcplus4_top[31] -attr @rip pcplus4[31] -pin PC pcplus4[31] -pin PCMUX i0[31]
load net pcplus4_top[3] -attr @rip pcplus4[3] -pin PC pcplus4[3] -pin PCMUX i0[3]
load net pcplus4_top[4] -attr @rip pcplus4[4] -pin PC pcplus4[4] -pin PCMUX i0[4]
load net pcplus4_top[5] -attr @rip pcplus4[5] -pin PC pcplus4[5] -pin PCMUX i0[5]
load net pcplus4_top[6] -attr @rip pcplus4[6] -pin PC pcplus4[6] -pin PCMUX i0[6]
load net pcplus4_top[7] -attr @rip pcplus4[7] -pin PC pcplus4[7] -pin PCMUX i0[7]
load net pcplus4_top[8] -attr @rip pcplus4[8] -pin PC pcplus4[8] -pin PCMUX i0[8]
load net pcplus4_top[9] -attr @rip pcplus4[9] -pin PC pcplus4[9] -pin PCMUX i0[9]
load net ra1_top[0] -attr @rip OFra[0] -pin IFOF_REGI OFra[0] -pin MUX2 i1[0] -pin OFEX_REGI OFra[0]
load net ra1_top[1] -attr @rip OFra[1] -pin IFOF_REGI OFra[1] -pin MUX2 i1[1] -pin OFEX_REGI OFra[1]
load net ra1_top[2] -attr @rip OFra[2] -pin IFOF_REGI OFra[2] -pin MUX2 i1[2] -pin OFEX_REGI OFra[2]
load net ra1_top[3] -attr @rip OFra[3] -pin IFOF_REGI OFra[3] -pin MUX2 i1[3] -pin OFEX_REGI OFra[3]
load net ra2_top[0] -attr @rip EXra[0] -pin EXMA_REGI EXra[0] -pin OFEX_REGI EXra[0]
load net ra2_top[1] -attr @rip EXra[1] -pin EXMA_REGI EXra[1] -pin OFEX_REGI EXra[1]
load net ra2_top[2] -attr @rip EXra[2] -pin EXMA_REGI EXra[2] -pin OFEX_REGI EXra[2]
load net ra2_top[3] -attr @rip EXra[3] -pin EXMA_REGI EXra[3] -pin OFEX_REGI EXra[3]
load net ra_top[0] -attr @rip ra[0] -pin IFOF_REGI IFra[0] -pin INSTRUCTIONFETCH ra[0] -pin MUX3 i1[0]
load net ra_top[1] -attr @rip ra[1] -pin IFOF_REGI IFra[1] -pin INSTRUCTIONFETCH ra[1] -pin MUX3 i1[1]
load net ra_top[2] -attr @rip ra[2] -pin IFOF_REGI IFra[2] -pin INSTRUCTIONFETCH ra[2] -pin MUX3 i1[2]
load net ra_top[3] -attr @rip ra[3] -pin IFOF_REGI IFra[3] -pin INSTRUCTIONFETCH ra[3] -pin MUX3 i1[3]
load net rd1_top[0] -attr @rip OFrd[0] -pin IFOF_REGI OFrd[0] -pin MUX1 i1[0] -pin OFEX_REGI OFrd[0]
load net rd1_top[1] -attr @rip OFrd[1] -pin IFOF_REGI OFrd[1] -pin MUX1 i1[1] -pin OFEX_REGI OFrd[1]
load net rd1_top[2] -attr @rip OFrd[2] -pin IFOF_REGI OFrd[2] -pin MUX1 i1[2] -pin OFEX_REGI OFrd[2]
load net rd1_top[3] -attr @rip OFrd[3] -pin IFOF_REGI OFrd[3] -pin MUX1 i1[3] -pin OFEX_REGI OFrd[3]
load net rd2_top[0] -attr @rip EXrd[0] -pin EXMA_REGI EXrd[0] -pin OFEX_REGI EXrd[0]
load net rd2_top[1] -attr @rip EXrd[1] -pin EXMA_REGI EXrd[1] -pin OFEX_REGI EXrd[1]
load net rd2_top[2] -attr @rip EXrd[2] -pin EXMA_REGI EXrd[2] -pin OFEX_REGI EXrd[2]
load net rd2_top[3] -attr @rip EXrd[3] -pin EXMA_REGI EXrd[3] -pin OFEX_REGI EXrd[3]
load net rd3_top[0] -attr @rip MArd[0] -pin EXMA_REGI MArd[0] -pin MARW_REGI MAra[0] -pin MARW_REGI MArd[0]
load net rd3_top[1] -attr @rip MArd[1] -pin EXMA_REGI MArd[1] -pin MARW_REGI MAra[1] -pin MARW_REGI MArd[1]
load net rd3_top[2] -attr @rip MArd[2] -pin EXMA_REGI MArd[2] -pin MARW_REGI MAra[2] -pin MARW_REGI MArd[2]
load net rd3_top[3] -attr @rip MArd[3] -pin EXMA_REGI MArd[3] -pin MARW_REGI MAra[3] -pin MARW_REGI MArd[3]
load net rd4_top[0] -attr @rip RWra[0] -pin MARW_REGI RWra[0] -pin MARW_REGI RWrd[0]
load net rd4_top[1] -attr @rip RWra[1] -pin MARW_REGI RWra[1] -pin MARW_REGI RWrd[1]
load net rd4_top[2] -attr @rip RWra[2] -pin MARW_REGI RWra[2] -pin MARW_REGI RWrd[2]
load net rd4_top[3] -attr @rip RWra[3] -pin MARW_REGI RWra[3] -pin MARW_REGI RWrd[3]
load net rd_top[0] -attr @rip rd[0] -pin IFOF_REGI IFrd[0] -pin INSTRUCTIONFETCH rd[0] -pin MUX3 i0[0]
load net rd_top[1] -attr @rip rd[1] -pin IFOF_REGI IFrd[1] -pin INSTRUCTIONFETCH rd[1] -pin MUX3 i0[1]
load net rd_top[2] -attr @rip rd[2] -pin IFOF_REGI IFrd[2] -pin INSTRUCTIONFETCH rd[2] -pin MUX3 i0[2]
load net rd_top[3] -attr @rip rd[3] -pin IFOF_REGI IFrd[3] -pin INSTRUCTIONFETCH rd[3] -pin MUX3 i0[3]
load net read_address_top[0] -attr @rip address[0] -pin DATAMEMORY read_address[0] -pin MEMORYUNIT address[0]
load net read_address_top[10] -attr @rip address[10] -pin DATAMEMORY read_address[10] -pin MEMORYUNIT address[10]
load net read_address_top[11] -attr @rip address[11] -pin DATAMEMORY read_address[11] -pin MEMORYUNIT address[11]
load net read_address_top[12] -attr @rip address[12] -pin DATAMEMORY read_address[12] -pin MEMORYUNIT address[12]
load net read_address_top[13] -attr @rip address[13] -pin DATAMEMORY read_address[13] -pin MEMORYUNIT address[13]
load net read_address_top[14] -attr @rip address[14] -pin DATAMEMORY read_address[14] -pin MEMORYUNIT address[14]
load net read_address_top[15] -attr @rip address[15] -pin DATAMEMORY read_address[15] -pin MEMORYUNIT address[15]
load net read_address_top[16] -attr @rip address[16] -pin DATAMEMORY read_address[16] -pin MEMORYUNIT address[16]
load net read_address_top[17] -attr @rip address[17] -pin DATAMEMORY read_address[17] -pin MEMORYUNIT address[17]
load net read_address_top[18] -attr @rip address[18] -pin DATAMEMORY read_address[18] -pin MEMORYUNIT address[18]
load net read_address_top[19] -attr @rip address[19] -pin DATAMEMORY read_address[19] -pin MEMORYUNIT address[19]
load net read_address_top[1] -attr @rip address[1] -pin DATAMEMORY read_address[1] -pin MEMORYUNIT address[1]
load net read_address_top[20] -attr @rip address[20] -pin DATAMEMORY read_address[20] -pin MEMORYUNIT address[20]
load net read_address_top[21] -attr @rip address[21] -pin DATAMEMORY read_address[21] -pin MEMORYUNIT address[21]
load net read_address_top[22] -attr @rip address[22] -pin DATAMEMORY read_address[22] -pin MEMORYUNIT address[22]
load net read_address_top[23] -attr @rip address[23] -pin DATAMEMORY read_address[23] -pin MEMORYUNIT address[23]
load net read_address_top[24] -attr @rip address[24] -pin DATAMEMORY read_address[24] -pin MEMORYUNIT address[24]
load net read_address_top[25] -attr @rip address[25] -pin DATAMEMORY read_address[25] -pin MEMORYUNIT address[25]
load net read_address_top[26] -attr @rip address[26] -pin DATAMEMORY read_address[26] -pin MEMORYUNIT address[26]
load net read_address_top[27] -attr @rip address[27] -pin DATAMEMORY read_address[27] -pin MEMORYUNIT address[27]
load net read_address_top[28] -attr @rip address[28] -pin DATAMEMORY read_address[28] -pin MEMORYUNIT address[28]
load net read_address_top[29] -attr @rip address[29] -pin DATAMEMORY read_address[29] -pin MEMORYUNIT address[29]
load net read_address_top[2] -attr @rip address[2] -pin DATAMEMORY read_address[2] -pin MEMORYUNIT address[2]
load net read_address_top[30] -attr @rip address[30] -pin DATAMEMORY read_address[30] -pin MEMORYUNIT address[30]
load net read_address_top[31] -attr @rip address[31] -pin DATAMEMORY read_address[31] -pin MEMORYUNIT address[31]
load net read_address_top[3] -attr @rip address[3] -pin DATAMEMORY read_address[3] -pin MEMORYUNIT address[3]
load net read_address_top[4] -attr @rip address[4] -pin DATAMEMORY read_address[4] -pin MEMORYUNIT address[4]
load net read_address_top[5] -attr @rip address[5] -pin DATAMEMORY read_address[5] -pin MEMORYUNIT address[5]
load net read_address_top[6] -attr @rip address[6] -pin DATAMEMORY read_address[6] -pin MEMORYUNIT address[6]
load net read_address_top[7] -attr @rip address[7] -pin DATAMEMORY read_address[7] -pin MEMORYUNIT address[7]
load net read_address_top[8] -attr @rip address[8] -pin DATAMEMORY read_address[8] -pin MEMORYUNIT address[8]
load net read_address_top[9] -attr @rip address[9] -pin DATAMEMORY read_address[9] -pin MEMORYUNIT address[9]
load net reset -pin BRANCHUNIT reset -pin CONTROLUNIT reset -pin DATAMEMORY reset -pin EXMA_REGI reset -pin FLAGREGISTER reset -pin HAZARDUNIT reset -pin IFOF_REGI reset -pin INSTRUCTIONFETCH reset -pin INSTRUCTIONMEMORY reset -pin MARW_REGI reset -pin MEMORYUNIT reset -pin OFEX_REGI reset -pin PC reset -pin PC5 reset -pin REGISTERFILE reset -port reset
netloc reset 1 0 17 20 550 330 470 NJ 470 960 550 1250 810 1580 930 1900 630 2510 980 2800 1580 3440 1520 3900 1540 4380 1060 NJ 1060 5140 1060 NJ 1060 6150 610 NJ
load net result1_top[0] -attr @rip MAresult[0] -pin EXMA_REGI MAresult[0] -pin MARW_REGI MAresult[0] -pin MEMORYUNIT result[0]
load net result1_top[10] -attr @rip MAresult[10] -pin EXMA_REGI MAresult[10] -pin MARW_REGI MAresult[10] -pin MEMORYUNIT result[10]
load net result1_top[11] -attr @rip MAresult[11] -pin EXMA_REGI MAresult[11] -pin MARW_REGI MAresult[11] -pin MEMORYUNIT result[11]
load net result1_top[12] -attr @rip MAresult[12] -pin EXMA_REGI MAresult[12] -pin MARW_REGI MAresult[12] -pin MEMORYUNIT result[12]
load net result1_top[13] -attr @rip MAresult[13] -pin EXMA_REGI MAresult[13] -pin MARW_REGI MAresult[13] -pin MEMORYUNIT result[13]
load net result1_top[14] -attr @rip MAresult[14] -pin EXMA_REGI MAresult[14] -pin MARW_REGI MAresult[14] -pin MEMORYUNIT result[14]
load net result1_top[15] -attr @rip MAresult[15] -pin EXMA_REGI MAresult[15] -pin MARW_REGI MAresult[15] -pin MEMORYUNIT result[15]
load net result1_top[16] -attr @rip MAresult[16] -pin EXMA_REGI MAresult[16] -pin MARW_REGI MAresult[16] -pin MEMORYUNIT result[16]
load net result1_top[17] -attr @rip MAresult[17] -pin EXMA_REGI MAresult[17] -pin MARW_REGI MAresult[17] -pin MEMORYUNIT result[17]
load net result1_top[18] -attr @rip MAresult[18] -pin EXMA_REGI MAresult[18] -pin MARW_REGI MAresult[18] -pin MEMORYUNIT result[18]
load net result1_top[19] -attr @rip MAresult[19] -pin EXMA_REGI MAresult[19] -pin MARW_REGI MAresult[19] -pin MEMORYUNIT result[19]
load net result1_top[1] -attr @rip MAresult[1] -pin EXMA_REGI MAresult[1] -pin MARW_REGI MAresult[1] -pin MEMORYUNIT result[1]
load net result1_top[20] -attr @rip MAresult[20] -pin EXMA_REGI MAresult[20] -pin MARW_REGI MAresult[20] -pin MEMORYUNIT result[20]
load net result1_top[21] -attr @rip MAresult[21] -pin EXMA_REGI MAresult[21] -pin MARW_REGI MAresult[21] -pin MEMORYUNIT result[21]
load net result1_top[22] -attr @rip MAresult[22] -pin EXMA_REGI MAresult[22] -pin MARW_REGI MAresult[22] -pin MEMORYUNIT result[22]
load net result1_top[23] -attr @rip MAresult[23] -pin EXMA_REGI MAresult[23] -pin MARW_REGI MAresult[23] -pin MEMORYUNIT result[23]
load net result1_top[24] -attr @rip MAresult[24] -pin EXMA_REGI MAresult[24] -pin MARW_REGI MAresult[24] -pin MEMORYUNIT result[24]
load net result1_top[25] -attr @rip MAresult[25] -pin EXMA_REGI MAresult[25] -pin MARW_REGI MAresult[25] -pin MEMORYUNIT result[25]
load net result1_top[26] -attr @rip MAresult[26] -pin EXMA_REGI MAresult[26] -pin MARW_REGI MAresult[26] -pin MEMORYUNIT result[26]
load net result1_top[27] -attr @rip MAresult[27] -pin EXMA_REGI MAresult[27] -pin MARW_REGI MAresult[27] -pin MEMORYUNIT result[27]
load net result1_top[28] -attr @rip MAresult[28] -pin EXMA_REGI MAresult[28] -pin MARW_REGI MAresult[28] -pin MEMORYUNIT result[28]
load net result1_top[29] -attr @rip MAresult[29] -pin EXMA_REGI MAresult[29] -pin MARW_REGI MAresult[29] -pin MEMORYUNIT result[29]
load net result1_top[2] -attr @rip MAresult[2] -pin EXMA_REGI MAresult[2] -pin MARW_REGI MAresult[2] -pin MEMORYUNIT result[2]
load net result1_top[30] -attr @rip MAresult[30] -pin EXMA_REGI MAresult[30] -pin MARW_REGI MAresult[30] -pin MEMORYUNIT result[30]
load net result1_top[31] -attr @rip MAresult[31] -pin EXMA_REGI MAresult[31] -pin MARW_REGI MAresult[31] -pin MEMORYUNIT result[31]
load net result1_top[3] -attr @rip MAresult[3] -pin EXMA_REGI MAresult[3] -pin MARW_REGI MAresult[3] -pin MEMORYUNIT result[3]
load net result1_top[4] -attr @rip MAresult[4] -pin EXMA_REGI MAresult[4] -pin MARW_REGI MAresult[4] -pin MEMORYUNIT result[4]
load net result1_top[5] -attr @rip MAresult[5] -pin EXMA_REGI MAresult[5] -pin MARW_REGI MAresult[5] -pin MEMORYUNIT result[5]
load net result1_top[6] -attr @rip MAresult[6] -pin EXMA_REGI MAresult[6] -pin MARW_REGI MAresult[6] -pin MEMORYUNIT result[6]
load net result1_top[7] -attr @rip MAresult[7] -pin EXMA_REGI MAresult[7] -pin MARW_REGI MAresult[7] -pin MEMORYUNIT result[7]
load net result1_top[8] -attr @rip MAresult[8] -pin EXMA_REGI MAresult[8] -pin MARW_REGI MAresult[8] -pin MEMORYUNIT result[8]
load net result1_top[9] -attr @rip MAresult[9] -pin EXMA_REGI MAresult[9] -pin MARW_REGI MAresult[9] -pin MEMORYUNIT result[9]
load net result2_top[0] -attr @rip RWresult[0] -pin MARW_REGI RWresult[0] -pin MUX4TO1 i0[0]
load net result2_top[10] -attr @rip RWresult[10] -pin MARW_REGI RWresult[10] -pin MUX4TO1 i0[10]
load net result2_top[11] -attr @rip RWresult[11] -pin MARW_REGI RWresult[11] -pin MUX4TO1 i0[11]
load net result2_top[12] -attr @rip RWresult[12] -pin MARW_REGI RWresult[12] -pin MUX4TO1 i0[12]
load net result2_top[13] -attr @rip RWresult[13] -pin MARW_REGI RWresult[13] -pin MUX4TO1 i0[13]
load net result2_top[14] -attr @rip RWresult[14] -pin MARW_REGI RWresult[14] -pin MUX4TO1 i0[14]
load net result2_top[15] -attr @rip RWresult[15] -pin MARW_REGI RWresult[15] -pin MUX4TO1 i0[15]
load net result2_top[16] -attr @rip RWresult[16] -pin MARW_REGI RWresult[16] -pin MUX4TO1 i0[16]
load net result2_top[17] -attr @rip RWresult[17] -pin MARW_REGI RWresult[17] -pin MUX4TO1 i0[17]
load net result2_top[18] -attr @rip RWresult[18] -pin MARW_REGI RWresult[18] -pin MUX4TO1 i0[18]
load net result2_top[19] -attr @rip RWresult[19] -pin MARW_REGI RWresult[19] -pin MUX4TO1 i0[19]
load net result2_top[1] -attr @rip RWresult[1] -pin MARW_REGI RWresult[1] -pin MUX4TO1 i0[1]
load net result2_top[20] -attr @rip RWresult[20] -pin MARW_REGI RWresult[20] -pin MUX4TO1 i0[20]
load net result2_top[21] -attr @rip RWresult[21] -pin MARW_REGI RWresult[21] -pin MUX4TO1 i0[21]
load net result2_top[22] -attr @rip RWresult[22] -pin MARW_REGI RWresult[22] -pin MUX4TO1 i0[22]
load net result2_top[23] -attr @rip RWresult[23] -pin MARW_REGI RWresult[23] -pin MUX4TO1 i0[23]
load net result2_top[24] -attr @rip RWresult[24] -pin MARW_REGI RWresult[24] -pin MUX4TO1 i0[24]
load net result2_top[25] -attr @rip RWresult[25] -pin MARW_REGI RWresult[25] -pin MUX4TO1 i0[25]
load net result2_top[26] -attr @rip RWresult[26] -pin MARW_REGI RWresult[26] -pin MUX4TO1 i0[26]
load net result2_top[27] -attr @rip RWresult[27] -pin MARW_REGI RWresult[27] -pin MUX4TO1 i0[27]
load net result2_top[28] -attr @rip RWresult[28] -pin MARW_REGI RWresult[28] -pin MUX4TO1 i0[28]
load net result2_top[29] -attr @rip RWresult[29] -pin MARW_REGI RWresult[29] -pin MUX4TO1 i0[29]
load net result2_top[2] -attr @rip RWresult[2] -pin MARW_REGI RWresult[2] -pin MUX4TO1 i0[2]
load net result2_top[30] -attr @rip RWresult[30] -pin MARW_REGI RWresult[30] -pin MUX4TO1 i0[30]
load net result2_top[31] -attr @rip RWresult[31] -pin MARW_REGI RWresult[31] -pin MUX4TO1 i0[31]
load net result2_top[3] -attr @rip RWresult[3] -pin MARW_REGI RWresult[3] -pin MUX4TO1 i0[3]
load net result2_top[4] -attr @rip RWresult[4] -pin MARW_REGI RWresult[4] -pin MUX4TO1 i0[4]
load net result2_top[5] -attr @rip RWresult[5] -pin MARW_REGI RWresult[5] -pin MUX4TO1 i0[5]
load net result2_top[6] -attr @rip RWresult[6] -pin MARW_REGI RWresult[6] -pin MUX4TO1 i0[6]
load net result2_top[7] -attr @rip RWresult[7] -pin MARW_REGI RWresult[7] -pin MUX4TO1 i0[7]
load net result2_top[8] -attr @rip RWresult[8] -pin MARW_REGI RWresult[8] -pin MUX4TO1 i0[8]
load net result2_top[9] -attr @rip RWresult[9] -pin MARW_REGI RWresult[9] -pin MUX4TO1 i0[9]
load net result_top[0] -attr @rip result[0] -pin ALU result[0] -pin EXMA_REGI EXresult[0]
load net result_top[10] -attr @rip result[10] -pin ALU result[10] -pin EXMA_REGI EXresult[10]
load net result_top[11] -attr @rip result[11] -pin ALU result[11] -pin EXMA_REGI EXresult[11]
load net result_top[12] -attr @rip result[12] -pin ALU result[12] -pin EXMA_REGI EXresult[12]
load net result_top[13] -attr @rip result[13] -pin ALU result[13] -pin EXMA_REGI EXresult[13]
load net result_top[14] -attr @rip result[14] -pin ALU result[14] -pin EXMA_REGI EXresult[14]
load net result_top[15] -attr @rip result[15] -pin ALU result[15] -pin EXMA_REGI EXresult[15]
load net result_top[16] -attr @rip result[16] -pin ALU result[16] -pin EXMA_REGI EXresult[16]
load net result_top[17] -attr @rip result[17] -pin ALU result[17] -pin EXMA_REGI EXresult[17]
load net result_top[18] -attr @rip result[18] -pin ALU result[18] -pin EXMA_REGI EXresult[18]
load net result_top[19] -attr @rip result[19] -pin ALU result[19] -pin EXMA_REGI EXresult[19]
load net result_top[1] -attr @rip result[1] -pin ALU result[1] -pin EXMA_REGI EXresult[1]
load net result_top[20] -attr @rip result[20] -pin ALU result[20] -pin EXMA_REGI EXresult[20]
load net result_top[21] -attr @rip result[21] -pin ALU result[21] -pin EXMA_REGI EXresult[21]
load net result_top[22] -attr @rip result[22] -pin ALU result[22] -pin EXMA_REGI EXresult[22]
load net result_top[23] -attr @rip result[23] -pin ALU result[23] -pin EXMA_REGI EXresult[23]
load net result_top[24] -attr @rip result[24] -pin ALU result[24] -pin EXMA_REGI EXresult[24]
load net result_top[25] -attr @rip result[25] -pin ALU result[25] -pin EXMA_REGI EXresult[25]
load net result_top[26] -attr @rip result[26] -pin ALU result[26] -pin EXMA_REGI EXresult[26]
load net result_top[27] -attr @rip result[27] -pin ALU result[27] -pin EXMA_REGI EXresult[27]
load net result_top[28] -attr @rip result[28] -pin ALU result[28] -pin EXMA_REGI EXresult[28]
load net result_top[29] -attr @rip result[29] -pin ALU result[29] -pin EXMA_REGI EXresult[29]
load net result_top[2] -attr @rip result[2] -pin ALU result[2] -pin EXMA_REGI EXresult[2]
load net result_top[30] -attr @rip result[30] -pin ALU result[30] -pin EXMA_REGI EXresult[30]
load net result_top[31] -attr @rip result[31] -pin ALU result[31] -pin EXMA_REGI EXresult[31]
load net result_top[3] -attr @rip result[3] -pin ALU result[3] -pin EXMA_REGI EXresult[3]
load net result_top[4] -attr @rip result[4] -pin ALU result[4] -pin EXMA_REGI EXresult[4]
load net result_top[5] -attr @rip result[5] -pin ALU result[5] -pin EXMA_REGI EXresult[5]
load net result_top[6] -attr @rip result[6] -pin ALU result[6] -pin EXMA_REGI EXresult[6]
load net result_top[7] -attr @rip result[7] -pin ALU result[7] -pin EXMA_REGI EXresult[7]
load net result_top[8] -attr @rip result[8] -pin ALU result[8] -pin EXMA_REGI EXresult[8]
load net result_top[9] -attr @rip result[9] -pin ALU result[9] -pin EXMA_REGI EXresult[9]
load net rs11_top[0] -attr @rip OFrs1[0] -pin IFOF_REGI OFrs1[0] -pin MUX2 i0[0]
load net rs11_top[1] -attr @rip OFrs1[1] -pin IFOF_REGI OFrs1[1] -pin MUX2 i0[1]
load net rs11_top[2] -attr @rip OFrs1[2] -pin IFOF_REGI OFrs1[2] -pin MUX2 i0[2]
load net rs11_top[3] -attr @rip OFrs1[3] -pin IFOF_REGI OFrs1[3] -pin MUX2 i0[3]
load net rs1_top[0] -attr @rip rs1[0] -pin IFOF_REGI IFrs1[0] -pin INSTRUCTIONFETCH rs1[0]
load net rs1_top[1] -attr @rip rs1[1] -pin IFOF_REGI IFrs1[1] -pin INSTRUCTIONFETCH rs1[1]
load net rs1_top[2] -attr @rip rs1[2] -pin IFOF_REGI IFrs1[2] -pin INSTRUCTIONFETCH rs1[2]
load net rs1_top[3] -attr @rip rs1[3] -pin IFOF_REGI IFrs1[3] -pin INSTRUCTIONFETCH rs1[3]
load net rs21_top[0] -attr @rip OFrs2[0] -pin IFOF_REGI OFrs2[0] -pin MUX1 i0[0]
load net rs21_top[1] -attr @rip OFrs2[1] -pin IFOF_REGI OFrs2[1] -pin MUX1 i0[1]
load net rs21_top[2] -attr @rip OFrs2[2] -pin IFOF_REGI OFrs2[2] -pin MUX1 i0[2]
load net rs21_top[3] -attr @rip OFrs2[3] -pin IFOF_REGI OFrs2[3] -pin MUX1 i0[3]
load net rs2_top[0] -attr @rip rs2[0] -pin IFOF_REGI IFrs2[0] -pin INSTRUCTIONFETCH rs2[0]
load net rs2_top[1] -attr @rip rs2[1] -pin IFOF_REGI IFrs2[1] -pin INSTRUCTIONFETCH rs2[1]
load net rs2_top[2] -attr @rip rs2[2] -pin IFOF_REGI IFrs2[2] -pin INSTRUCTIONFETCH rs2[2]
load net rs2_top[3] -attr @rip rs2[3] -pin IFOF_REGI IFrs2[3] -pin INSTRUCTIONFETCH rs2[3]
load net sign_in_top -pin ALU sign -pin FLAGREGISTER sign_in
netloc sign_in_top 1 0 18 60 510 NJ 510 630J 550 900J 590 1230J 610 NJ 610 1960J 670 NJ 670 NJ 670 NJ 670 NJ 670 NJ 670 NJ 670 NJ 670 NJ 670 NJ 670 NJ 670 7100
load net source1_top[0] -attr @rip RWldResult[0] -pin MARW_REGI RWldResult[0] -pin MUX4TO1 i1[0]
load net source1_top[10] -attr @rip RWldResult[10] -pin MARW_REGI RWldResult[10] -pin MUX4TO1 i1[10]
load net source1_top[11] -attr @rip RWldResult[11] -pin MARW_REGI RWldResult[11] -pin MUX4TO1 i1[11]
load net source1_top[12] -attr @rip RWldResult[12] -pin MARW_REGI RWldResult[12] -pin MUX4TO1 i1[12]
load net source1_top[13] -attr @rip RWldResult[13] -pin MARW_REGI RWldResult[13] -pin MUX4TO1 i1[13]
load net source1_top[14] -attr @rip RWldResult[14] -pin MARW_REGI RWldResult[14] -pin MUX4TO1 i1[14]
load net source1_top[15] -attr @rip RWldResult[15] -pin MARW_REGI RWldResult[15] -pin MUX4TO1 i1[15]
load net source1_top[16] -attr @rip RWldResult[16] -pin MARW_REGI RWldResult[16] -pin MUX4TO1 i1[16]
load net source1_top[17] -attr @rip RWldResult[17] -pin MARW_REGI RWldResult[17] -pin MUX4TO1 i1[17]
load net source1_top[18] -attr @rip RWldResult[18] -pin MARW_REGI RWldResult[18] -pin MUX4TO1 i1[18]
load net source1_top[19] -attr @rip RWldResult[19] -pin MARW_REGI RWldResult[19] -pin MUX4TO1 i1[19]
load net source1_top[1] -attr @rip RWldResult[1] -pin MARW_REGI RWldResult[1] -pin MUX4TO1 i1[1]
load net source1_top[20] -attr @rip RWldResult[20] -pin MARW_REGI RWldResult[20] -pin MUX4TO1 i1[20]
load net source1_top[21] -attr @rip RWldResult[21] -pin MARW_REGI RWldResult[21] -pin MUX4TO1 i1[21]
load net source1_top[22] -attr @rip RWldResult[22] -pin MARW_REGI RWldResult[22] -pin MUX4TO1 i1[22]
load net source1_top[23] -attr @rip RWldResult[23] -pin MARW_REGI RWldResult[23] -pin MUX4TO1 i1[23]
load net source1_top[24] -attr @rip RWldResult[24] -pin MARW_REGI RWldResult[24] -pin MUX4TO1 i1[24]
load net source1_top[25] -attr @rip RWldResult[25] -pin MARW_REGI RWldResult[25] -pin MUX4TO1 i1[25]
load net source1_top[26] -attr @rip RWldResult[26] -pin MARW_REGI RWldResult[26] -pin MUX4TO1 i1[26]
load net source1_top[27] -attr @rip RWldResult[27] -pin MARW_REGI RWldResult[27] -pin MUX4TO1 i1[27]
load net source1_top[28] -attr @rip RWldResult[28] -pin MARW_REGI RWldResult[28] -pin MUX4TO1 i1[28]
load net source1_top[29] -attr @rip RWldResult[29] -pin MARW_REGI RWldResult[29] -pin MUX4TO1 i1[29]
load net source1_top[2] -attr @rip RWldResult[2] -pin MARW_REGI RWldResult[2] -pin MUX4TO1 i1[2]
load net source1_top[30] -attr @rip RWldResult[30] -pin MARW_REGI RWldResult[30] -pin MUX4TO1 i1[30]
load net source1_top[31] -attr @rip RWldResult[31] -pin MARW_REGI RWldResult[31] -pin MUX4TO1 i1[31]
load net source1_top[3] -attr @rip RWldResult[3] -pin MARW_REGI RWldResult[3] -pin MUX4TO1 i1[3]
load net source1_top[4] -attr @rip RWldResult[4] -pin MARW_REGI RWldResult[4] -pin MUX4TO1 i1[4]
load net source1_top[5] -attr @rip RWldResult[5] -pin MARW_REGI RWldResult[5] -pin MUX4TO1 i1[5]
load net source1_top[6] -attr @rip RWldResult[6] -pin MARW_REGI RWldResult[6] -pin MUX4TO1 i1[6]
load net source1_top[7] -attr @rip RWldResult[7] -pin MARW_REGI RWldResult[7] -pin MUX4TO1 i1[7]
load net source1_top[8] -attr @rip RWldResult[8] -pin MARW_REGI RWldResult[8] -pin MUX4TO1 i1[8]
load net source1_top[9] -attr @rip RWldResult[9] -pin MARW_REGI RWldResult[9] -pin MUX4TO1 i1[9]
load net source_top[0] -attr @rip ldResult[0] -pin MARW_REGI MAldResult[0] -pin MEMORYUNIT ldResult[0]
load net source_top[10] -attr @rip ldResult[10] -pin MARW_REGI MAldResult[10] -pin MEMORYUNIT ldResult[10]
load net source_top[11] -attr @rip ldResult[11] -pin MARW_REGI MAldResult[11] -pin MEMORYUNIT ldResult[11]
load net source_top[12] -attr @rip ldResult[12] -pin MARW_REGI MAldResult[12] -pin MEMORYUNIT ldResult[12]
load net source_top[13] -attr @rip ldResult[13] -pin MARW_REGI MAldResult[13] -pin MEMORYUNIT ldResult[13]
load net source_top[14] -attr @rip ldResult[14] -pin MARW_REGI MAldResult[14] -pin MEMORYUNIT ldResult[14]
load net source_top[15] -attr @rip ldResult[15] -pin MARW_REGI MAldResult[15] -pin MEMORYUNIT ldResult[15]
load net source_top[16] -attr @rip ldResult[16] -pin MARW_REGI MAldResult[16] -pin MEMORYUNIT ldResult[16]
load net source_top[17] -attr @rip ldResult[17] -pin MARW_REGI MAldResult[17] -pin MEMORYUNIT ldResult[17]
load net source_top[18] -attr @rip ldResult[18] -pin MARW_REGI MAldResult[18] -pin MEMORYUNIT ldResult[18]
load net source_top[19] -attr @rip ldResult[19] -pin MARW_REGI MAldResult[19] -pin MEMORYUNIT ldResult[19]
load net source_top[1] -attr @rip ldResult[1] -pin MARW_REGI MAldResult[1] -pin MEMORYUNIT ldResult[1]
load net source_top[20] -attr @rip ldResult[20] -pin MARW_REGI MAldResult[20] -pin MEMORYUNIT ldResult[20]
load net source_top[21] -attr @rip ldResult[21] -pin MARW_REGI MAldResult[21] -pin MEMORYUNIT ldResult[21]
load net source_top[22] -attr @rip ldResult[22] -pin MARW_REGI MAldResult[22] -pin MEMORYUNIT ldResult[22]
load net source_top[23] -attr @rip ldResult[23] -pin MARW_REGI MAldResult[23] -pin MEMORYUNIT ldResult[23]
load net source_top[24] -attr @rip ldResult[24] -pin MARW_REGI MAldResult[24] -pin MEMORYUNIT ldResult[24]
load net source_top[25] -attr @rip ldResult[25] -pin MARW_REGI MAldResult[25] -pin MEMORYUNIT ldResult[25]
load net source_top[26] -attr @rip ldResult[26] -pin MARW_REGI MAldResult[26] -pin MEMORYUNIT ldResult[26]
load net source_top[27] -attr @rip ldResult[27] -pin MARW_REGI MAldResult[27] -pin MEMORYUNIT ldResult[27]
load net source_top[28] -attr @rip ldResult[28] -pin MARW_REGI MAldResult[28] -pin MEMORYUNIT ldResult[28]
load net source_top[29] -attr @rip ldResult[29] -pin MARW_REGI MAldResult[29] -pin MEMORYUNIT ldResult[29]
load net source_top[2] -attr @rip ldResult[2] -pin MARW_REGI MAldResult[2] -pin MEMORYUNIT ldResult[2]
load net source_top[30] -attr @rip ldResult[30] -pin MARW_REGI MAldResult[30] -pin MEMORYUNIT ldResult[30]
load net source_top[31] -attr @rip ldResult[31] -pin MARW_REGI MAldResult[31] -pin MEMORYUNIT ldResult[31]
load net source_top[3] -attr @rip ldResult[3] -pin MARW_REGI MAldResult[3] -pin MEMORYUNIT ldResult[3]
load net source_top[4] -attr @rip ldResult[4] -pin MARW_REGI MAldResult[4] -pin MEMORYUNIT ldResult[4]
load net source_top[5] -attr @rip ldResult[5] -pin MARW_REGI MAldResult[5] -pin MEMORYUNIT ldResult[5]
load net source_top[6] -attr @rip ldResult[6] -pin MARW_REGI MAldResult[6] -pin MEMORYUNIT ldResult[6]
load net source_top[7] -attr @rip ldResult[7] -pin MARW_REGI MAldResult[7] -pin MEMORYUNIT ldResult[7]
load net source_top[8] -attr @rip ldResult[8] -pin MARW_REGI MAldResult[8] -pin MEMORYUNIT ldResult[8]
load net source_top[9] -attr @rip ldResult[9] -pin MARW_REGI MAldResult[9] -pin MEMORYUNIT ldResult[9]
load net write_data_top[0] -attr @rip writeData[0] -pin DATAMEMORY Write_data[0] -pin MEMORYUNIT writeData[0]
load net write_data_top[10] -attr @rip writeData[10] -pin DATAMEMORY Write_data[10] -pin MEMORYUNIT writeData[10]
load net write_data_top[11] -attr @rip writeData[11] -pin DATAMEMORY Write_data[11] -pin MEMORYUNIT writeData[11]
load net write_data_top[12] -attr @rip writeData[12] -pin DATAMEMORY Write_data[12] -pin MEMORYUNIT writeData[12]
load net write_data_top[13] -attr @rip writeData[13] -pin DATAMEMORY Write_data[13] -pin MEMORYUNIT writeData[13]
load net write_data_top[14] -attr @rip writeData[14] -pin DATAMEMORY Write_data[14] -pin MEMORYUNIT writeData[14]
load net write_data_top[15] -attr @rip writeData[15] -pin DATAMEMORY Write_data[15] -pin MEMORYUNIT writeData[15]
load net write_data_top[16] -attr @rip writeData[16] -pin DATAMEMORY Write_data[16] -pin MEMORYUNIT writeData[16]
load net write_data_top[17] -attr @rip writeData[17] -pin DATAMEMORY Write_data[17] -pin MEMORYUNIT writeData[17]
load net write_data_top[18] -attr @rip writeData[18] -pin DATAMEMORY Write_data[18] -pin MEMORYUNIT writeData[18]
load net write_data_top[19] -attr @rip writeData[19] -pin DATAMEMORY Write_data[19] -pin MEMORYUNIT writeData[19]
load net write_data_top[1] -attr @rip writeData[1] -pin DATAMEMORY Write_data[1] -pin MEMORYUNIT writeData[1]
load net write_data_top[20] -attr @rip writeData[20] -pin DATAMEMORY Write_data[20] -pin MEMORYUNIT writeData[20]
load net write_data_top[21] -attr @rip writeData[21] -pin DATAMEMORY Write_data[21] -pin MEMORYUNIT writeData[21]
load net write_data_top[22] -attr @rip writeData[22] -pin DATAMEMORY Write_data[22] -pin MEMORYUNIT writeData[22]
load net write_data_top[23] -attr @rip writeData[23] -pin DATAMEMORY Write_data[23] -pin MEMORYUNIT writeData[23]
load net write_data_top[24] -attr @rip writeData[24] -pin DATAMEMORY Write_data[24] -pin MEMORYUNIT writeData[24]
load net write_data_top[25] -attr @rip writeData[25] -pin DATAMEMORY Write_data[25] -pin MEMORYUNIT writeData[25]
load net write_data_top[26] -attr @rip writeData[26] -pin DATAMEMORY Write_data[26] -pin MEMORYUNIT writeData[26]
load net write_data_top[27] -attr @rip writeData[27] -pin DATAMEMORY Write_data[27] -pin MEMORYUNIT writeData[27]
load net write_data_top[28] -attr @rip writeData[28] -pin DATAMEMORY Write_data[28] -pin MEMORYUNIT writeData[28]
load net write_data_top[29] -attr @rip writeData[29] -pin DATAMEMORY Write_data[29] -pin MEMORYUNIT writeData[29]
load net write_data_top[2] -attr @rip writeData[2] -pin DATAMEMORY Write_data[2] -pin MEMORYUNIT writeData[2]
load net write_data_top[30] -attr @rip writeData[30] -pin DATAMEMORY Write_data[30] -pin MEMORYUNIT writeData[30]
load net write_data_top[31] -attr @rip writeData[31] -pin DATAMEMORY Write_data[31] -pin MEMORYUNIT writeData[31]
load net write_data_top[3] -attr @rip writeData[3] -pin DATAMEMORY Write_data[3] -pin MEMORYUNIT writeData[3]
load net write_data_top[4] -attr @rip writeData[4] -pin DATAMEMORY Write_data[4] -pin MEMORYUNIT writeData[4]
load net write_data_top[5] -attr @rip writeData[5] -pin DATAMEMORY Write_data[5] -pin MEMORYUNIT writeData[5]
load net write_data_top[6] -attr @rip writeData[6] -pin DATAMEMORY Write_data[6] -pin MEMORYUNIT writeData[6]
load net write_data_top[7] -attr @rip writeData[7] -pin DATAMEMORY Write_data[7] -pin MEMORYUNIT writeData[7]
load net write_data_top[8] -attr @rip writeData[8] -pin DATAMEMORY Write_data[8] -pin MEMORYUNIT writeData[8]
load net write_data_top[9] -attr @rip writeData[9] -pin DATAMEMORY Write_data[9] -pin MEMORYUNIT writeData[9]
load net writedata_top[0] -attr @rip o[0] -pin MUX4TO1 o[0] -pin REGISTERFILE writedata[0]
load net writedata_top[10] -attr @rip o[10] -pin MUX4TO1 o[10] -pin REGISTERFILE writedata[10]
load net writedata_top[11] -attr @rip o[11] -pin MUX4TO1 o[11] -pin REGISTERFILE writedata[11]
load net writedata_top[12] -attr @rip o[12] -pin MUX4TO1 o[12] -pin REGISTERFILE writedata[12]
load net writedata_top[13] -attr @rip o[13] -pin MUX4TO1 o[13] -pin REGISTERFILE writedata[13]
load net writedata_top[14] -attr @rip o[14] -pin MUX4TO1 o[14] -pin REGISTERFILE writedata[14]
load net writedata_top[15] -attr @rip o[15] -pin MUX4TO1 o[15] -pin REGISTERFILE writedata[15]
load net writedata_top[16] -attr @rip o[16] -pin MUX4TO1 o[16] -pin REGISTERFILE writedata[16]
load net writedata_top[17] -attr @rip o[17] -pin MUX4TO1 o[17] -pin REGISTERFILE writedata[17]
load net writedata_top[18] -attr @rip o[18] -pin MUX4TO1 o[18] -pin REGISTERFILE writedata[18]
load net writedata_top[19] -attr @rip o[19] -pin MUX4TO1 o[19] -pin REGISTERFILE writedata[19]
load net writedata_top[1] -attr @rip o[1] -pin MUX4TO1 o[1] -pin REGISTERFILE writedata[1]
load net writedata_top[20] -attr @rip o[20] -pin MUX4TO1 o[20] -pin REGISTERFILE writedata[20]
load net writedata_top[21] -attr @rip o[21] -pin MUX4TO1 o[21] -pin REGISTERFILE writedata[21]
load net writedata_top[22] -attr @rip o[22] -pin MUX4TO1 o[22] -pin REGISTERFILE writedata[22]
load net writedata_top[23] -attr @rip o[23] -pin MUX4TO1 o[23] -pin REGISTERFILE writedata[23]
load net writedata_top[24] -attr @rip o[24] -pin MUX4TO1 o[24] -pin REGISTERFILE writedata[24]
load net writedata_top[25] -attr @rip o[25] -pin MUX4TO1 o[25] -pin REGISTERFILE writedata[25]
load net writedata_top[26] -attr @rip o[26] -pin MUX4TO1 o[26] -pin REGISTERFILE writedata[26]
load net writedata_top[27] -attr @rip o[27] -pin MUX4TO1 o[27] -pin REGISTERFILE writedata[27]
load net writedata_top[28] -attr @rip o[28] -pin MUX4TO1 o[28] -pin REGISTERFILE writedata[28]
load net writedata_top[29] -attr @rip o[29] -pin MUX4TO1 o[29] -pin REGISTERFILE writedata[29]
load net writedata_top[2] -attr @rip o[2] -pin MUX4TO1 o[2] -pin REGISTERFILE writedata[2]
load net writedata_top[30] -attr @rip o[30] -pin MUX4TO1 o[30] -pin REGISTERFILE writedata[30]
load net writedata_top[31] -attr @rip o[31] -pin MUX4TO1 o[31] -pin REGISTERFILE writedata[31]
load net writedata_top[3] -attr @rip o[3] -pin MUX4TO1 o[3] -pin REGISTERFILE writedata[3]
load net writedata_top[4] -attr @rip o[4] -pin MUX4TO1 o[4] -pin REGISTERFILE writedata[4]
load net writedata_top[5] -attr @rip o[5] -pin MUX4TO1 o[5] -pin REGISTERFILE writedata[5]
load net writedata_top[6] -attr @rip o[6] -pin MUX4TO1 o[6] -pin REGISTERFILE writedata[6]
load net writedata_top[7] -attr @rip o[7] -pin MUX4TO1 o[7] -pin REGISTERFILE writedata[7]
load net writedata_top[8] -attr @rip o[8] -pin MUX4TO1 o[8] -pin REGISTERFILE writedata[8]
load net writedata_top[9] -attr @rip o[9] -pin MUX4TO1 o[9] -pin REGISTERFILE writedata[9]
load netBundle @result_top 32 result_top[31] result_top[30] result_top[29] result_top[28] result_top[27] result_top[26] result_top[25] result_top[24] result_top[23] result_top[22] result_top[21] result_top[20] result_top[19] result_top[18] result_top[17] result_top[16] result_top[15] result_top[14] result_top[13] result_top[12] result_top[11] result_top[10] result_top[9] result_top[8] result_top[7] result_top[6] result_top[5] result_top[4] result_top[3] result_top[2] result_top[1] result_top[0] -autobundled
netbloc @result_top 1 8 10 2860 1000 NJ 1000 NJ 1000 NJ 1000 NJ 1000 5100J 840 NJ 840 NJ 840 NJ 840 7120
load netBundle @branchaddr_top 32 branchaddr_top[31] branchaddr_top[30] branchaddr_top[29] branchaddr_top[28] branchaddr_top[27] branchaddr_top[26] branchaddr_top[25] branchaddr_top[24] branchaddr_top[23] branchaddr_top[22] branchaddr_top[21] branchaddr_top[20] branchaddr_top[19] branchaddr_top[18] branchaddr_top[17] branchaddr_top[16] branchaddr_top[15] branchaddr_top[14] branchaddr_top[13] branchaddr_top[12] branchaddr_top[11] branchaddr_top[10] branchaddr_top[9] branchaddr_top[8] branchaddr_top[7] branchaddr_top[6] branchaddr_top[5] branchaddr_top[4] branchaddr_top[3] branchaddr_top[2] branchaddr_top[1] branchaddr_top[0] -autobundled
netbloc @branchaddr_top 1 2 1 630 150n
load netBundle @memdataout_top 32 memdataout_top[31] memdataout_top[30] memdataout_top[29] memdataout_top[28] memdataout_top[27] memdataout_top[26] memdataout_top[25] memdataout_top[24] memdataout_top[23] memdataout_top[22] memdataout_top[21] memdataout_top[20] memdataout_top[19] memdataout_top[18] memdataout_top[17] memdataout_top[16] memdataout_top[15] memdataout_top[14] memdataout_top[13] memdataout_top[12] memdataout_top[11] memdataout_top[10] memdataout_top[9] memdataout_top[8] memdataout_top[7] memdataout_top[6] memdataout_top[5] memdataout_top[4] memdataout_top[3] memdataout_top[2] memdataout_top[1] memdataout_top[0] -autobundled
netbloc @memdataout_top 1 9 1 3320 1660n
load netBundle @addrout3_top 32 addrout3_top[31] addrout3_top[30] addrout3_top[29] addrout3_top[28] addrout3_top[27] addrout3_top[26] addrout3_top[25] addrout3_top[24] addrout3_top[23] addrout3_top[22] addrout3_top[21] addrout3_top[20] addrout3_top[19] addrout3_top[18] addrout3_top[17] addrout3_top[16] addrout3_top[15] addrout3_top[14] addrout3_top[13] addrout3_top[12] addrout3_top[11] addrout3_top[10] addrout3_top[9] addrout3_top[8] addrout3_top[7] addrout3_top[6] addrout3_top[5] addrout3_top[4] addrout3_top[3] addrout3_top[2] addrout3_top[1] addrout3_top[0] -autobundled
netbloc @addrout3_top 1 9 2 NJ 1240 3800
load netBundle @op22_top 4 op22_top[3] op22_top[2] op22_top[1] op22_top[0] -autobundled
netbloc @op22_top 1 9 1 3360 1340n
load netBundle @rd3_top 4 rd3_top[3] rd3_top[2] rd3_top[1] rd3_top[0] -autobundled
netbloc @rd3_top 1 9 2 NJ 1360 3860
load netBundle @result1_top 32 result1_top[31] result1_top[30] result1_top[29] result1_top[28] result1_top[27] result1_top[26] result1_top[25] result1_top[24] result1_top[23] result1_top[22] result1_top[21] result1_top[20] result1_top[19] result1_top[18] result1_top[17] result1_top[16] result1_top[15] result1_top[14] result1_top[13] result1_top[12] result1_top[11] result1_top[10] result1_top[9] result1_top[8] result1_top[7] result1_top[6] result1_top[5] result1_top[4] result1_top[3] result1_top[2] result1_top[1] result1_top[0] -autobundled
netbloc @result1_top 1 9 2 3300 1440 NJ
load netBundle @addrout1_top 32 addrout1_top[31] addrout1_top[30] addrout1_top[29] addrout1_top[28] addrout1_top[27] addrout1_top[26] addrout1_top[25] addrout1_top[24] addrout1_top[23] addrout1_top[22] addrout1_top[21] addrout1_top[20] addrout1_top[19] addrout1_top[18] addrout1_top[17] addrout1_top[16] addrout1_top[15] addrout1_top[14] addrout1_top[13] addrout1_top[12] addrout1_top[11] addrout1_top[10] addrout1_top[9] addrout1_top[8] addrout1_top[7] addrout1_top[6] addrout1_top[5] addrout1_top[4] addrout1_top[3] addrout1_top[2] addrout1_top[1] addrout1_top[0] -autobundled
netbloc @addrout1_top 1 7 9 2410J 310 NJ 310 NJ 310 NJ 310 NJ 310 4670J 370 5140 110 NJ 110 NJ
load netBundle @instruction1_top 32 instruction1_top[31] instruction1_top[30] instruction1_top[29] instruction1_top[28] instruction1_top[27] instruction1_top[26] instruction1_top[25] instruction1_top[24] instruction1_top[23] instruction1_top[22] instruction1_top[21] instruction1_top[20] instruction1_top[19] instruction1_top[18] instruction1_top[17] instruction1_top[16] instruction1_top[15] instruction1_top[14] instruction1_top[13] instruction1_top[12] instruction1_top[11] instruction1_top[10] instruction1_top[9] instruction1_top[8] instruction1_top[7] instruction1_top[6] instruction1_top[5] instruction1_top[4] instruction1_top[3] instruction1_top[2] instruction1_top[1] instruction1_top[0] -autobundled
netbloc @instruction1_top 1 7 7 2530J 590 NJ 590 NJ 590 NJ 590 NJ 590 NJ 590 5060
load netBundle @opcode1_top 5 opcode1_top[4] opcode1_top[3] opcode1_top[2] opcode1_top[1] opcode1_top[0] -autobundled
netbloc @opcode1_top 1 7 9 2550 630 NJ 630 NJ 630 NJ 630 NJ 630 NJ 630 NJ 630 NJ 630 6090
load netBundle @ra1_top 4 ra1_top[3] ra1_top[2] ra1_top[1] ra1_top[0] -autobundled
netbloc @ra1_top 1 7 9 2430 750 NJ 750 NJ 750 NJ 750 NJ 750 4790 730 NJ 730 NJ 730 6130
load netBundle @rd1_top 4 rd1_top[3] rd1_top[2] rd1_top[1] rd1_top[0] -autobundled
netbloc @rd1_top 1 7 9 2470 570 2880J 550 NJ 550 NJ 550 NJ 550 4790 570 NJ 570 NJ 570 6110
load netBundle @rs11_top 4 rs11_top[3] rs11_top[2] rs11_top[1] rs11_top[0] -autobundled
netbloc @rs11_top 1 7 6 2410 730 NJ 730 NJ 730 NJ 730 NJ 730 4670J
load netBundle @rs21_top 4 rs21_top[3] rs21_top[2] rs21_top[1] rs21_top[0] -autobundled
netbloc @rs21_top 1 7 6 N 550 2860J 530 NJ 530 NJ 530 NJ 530 4690J
load netBundle @branchtarget_top 32 branchtarget_top[31] branchtarget_top[30] branchtarget_top[29] branchtarget_top[28] branchtarget_top[27] branchtarget_top[26] branchtarget_top[25] branchtarget_top[24] branchtarget_top[23] branchtarget_top[22] branchtarget_top[21] branchtarget_top[20] branchtarget_top[19] branchtarget_top[18] branchtarget_top[17] branchtarget_top[16] branchtarget_top[15] branchtarget_top[14] branchtarget_top[13] branchtarget_top[12] branchtarget_top[11] branchtarget_top[10] branchtarget_top[9] branchtarget_top[8] branchtarget_top[7] branchtarget_top[6] branchtarget_top[5] branchtarget_top[4] branchtarget_top[3] branchtarget_top[2] branchtarget_top[1] branchtarget_top[0] -autobundled
netbloc @branchtarget_top 1 14 2 5480 130 NJ
load netBundle @immx_top 32 immx_top[31] immx_top[30] immx_top[29] immx_top[28] immx_top[27] immx_top[26] immx_top[25] immx_top[24] immx_top[23] immx_top[22] immx_top[21] immx_top[20] immx_top[19] immx_top[18] immx_top[17] immx_top[16] immx_top[15] immx_top[14] immx_top[13] immx_top[12] immx_top[11] immx_top[10] immx_top[9] immx_top[8] immx_top[7] immx_top[6] immx_top[5] immx_top[4] immx_top[3] immx_top[2] immx_top[1] immx_top[0] -autobundled
netbloc @immx_top 1 14 1 5520 430n
load netBundle @B_top 32 B_top[31] B_top[30] B_top[29] B_top[28] B_top[27] B_top[26] B_top[25] B_top[24] B_top[23] B_top[22] B_top[21] B_top[20] B_top[19] B_top[18] B_top[17] B_top[16] B_top[15] B_top[14] B_top[13] B_top[12] B_top[11] B_top[10] B_top[9] B_top[8] B_top[7] B_top[6] B_top[5] B_top[4] B_top[3] B_top[2] B_top[1] B_top[0] -autobundled
netbloc @B_top 1 15 1 5830 90n
load netBundle @opcode_top 5 opcode_top[4] opcode_top[3] opcode_top[2] opcode_top[1] opcode_top[0] -autobundled
netbloc @opcode_top 1 6 1 1940 450n
load netBundle @ra_top 4 ra_top[3] ra_top[2] ra_top[1] ra_top[0] -autobundled
netbloc @ra_top 1 6 7 2020 940 NJ 940 NJ 940 NJ 940 NJ 940 NJ 940 NJ
load netBundle @rd_top 4 rd_top[3] rd_top[2] rd_top[1] rd_top[0] -autobundled
netbloc @rd_top 1 6 7 2080 920 NJ 920 NJ 920 NJ 920 NJ 920 NJ 920 NJ
load netBundle @rs1_top 4 rs1_top[3] rs1_top[2] rs1_top[1] rs1_top[0] -autobundled
netbloc @rs1_top 1 6 1 1980 510n
load netBundle @rs2_top 4 rs2_top[3] rs2_top[2] rs2_top[1] rs2_top[0] -autobundled
netbloc @rs2_top 1 6 1 2060 530n
load netBundle @instruction_top 32 instruction_top[31] instruction_top[30] instruction_top[29] instruction_top[28] instruction_top[27] instruction_top[26] instruction_top[25] instruction_top[24] instruction_top[23] instruction_top[22] instruction_top[21] instruction_top[20] instruction_top[19] instruction_top[18] instruction_top[17] instruction_top[16] instruction_top[15] instruction_top[14] instruction_top[13] instruction_top[12] instruction_top[11] instruction_top[10] instruction_top[9] instruction_top[8] instruction_top[7] instruction_top[6] instruction_top[5] instruction_top[4] instruction_top[3] instruction_top[2] instruction_top[1] instruction_top[0] -autobundled
netbloc @instruction_top 1 5 2 1620 410 NJ
load netBundle @source1_top 32 source1_top[31] source1_top[30] source1_top[29] source1_top[28] source1_top[27] source1_top[26] source1_top[25] source1_top[24] source1_top[23] source1_top[22] source1_top[21] source1_top[20] source1_top[19] source1_top[18] source1_top[17] source1_top[16] source1_top[15] source1_top[14] source1_top[13] source1_top[12] source1_top[11] source1_top[10] source1_top[9] source1_top[8] source1_top[7] source1_top[6] source1_top[5] source1_top[4] source1_top[3] source1_top[2] source1_top[1] source1_top[0] -autobundled
netbloc @source1_top 1 11 2 4360 1320 NJ
load netBundle @rd4_top 4 rd4_top[3] rd4_top[2] rd4_top[1] rd4_top[0] -autobundled
netbloc @rd4_top 1 11 1 4240 1420n
load netBundle @result2_top 32 result2_top[31] result2_top[30] result2_top[29] result2_top[28] result2_top[27] result2_top[26] result2_top[25] result2_top[24] result2_top[23] result2_top[22] result2_top[21] result2_top[20] result2_top[19] result2_top[18] result2_top[17] result2_top[16] result2_top[15] result2_top[14] result2_top[13] result2_top[12] result2_top[11] result2_top[10] result2_top[9] result2_top[8] result2_top[7] result2_top[6] result2_top[5] result2_top[4] result2_top[3] result2_top[2] result2_top[1] result2_top[0] -autobundled
netbloc @result2_top 1 11 2 4260 1300 NJ
load netBundle @read_address_top 32 read_address_top[31] read_address_top[30] read_address_top[29] read_address_top[28] read_address_top[27] read_address_top[26] read_address_top[25] read_address_top[24] read_address_top[23] read_address_top[22] read_address_top[21] read_address_top[20] read_address_top[19] read_address_top[18] read_address_top[17] read_address_top[16] read_address_top[15] read_address_top[14] read_address_top[13] read_address_top[12] read_address_top[11] read_address_top[10] read_address_top[9] read_address_top[8] read_address_top[7] read_address_top[6] read_address_top[5] read_address_top[4] read_address_top[3] read_address_top[2] read_address_top[1] read_address_top[0] -autobundled
netbloc @read_address_top 1 8 3 2960 1800 NJ 1800 3800
load netBundle @source_top 32 source_top[31] source_top[30] source_top[29] source_top[28] source_top[27] source_top[26] source_top[25] source_top[24] source_top[23] source_top[22] source_top[21] source_top[20] source_top[19] source_top[18] source_top[17] source_top[16] source_top[15] source_top[14] source_top[13] source_top[12] source_top[11] source_top[10] source_top[9] source_top[8] source_top[7] source_top[6] source_top[5] source_top[4] source_top[3] source_top[2] source_top[1] source_top[0] -autobundled
netbloc @source_top 1 10 1 3880 1380n
load netBundle @write_data_top 32 write_data_top[31] write_data_top[30] write_data_top[29] write_data_top[28] write_data_top[27] write_data_top[26] write_data_top[25] write_data_top[24] write_data_top[23] write_data_top[22] write_data_top[21] write_data_top[20] write_data_top[19] write_data_top[18] write_data_top[17] write_data_top[16] write_data_top[15] write_data_top[14] write_data_top[13] write_data_top[12] write_data_top[11] write_data_top[10] write_data_top[9] write_data_top[8] write_data_top[7] write_data_top[6] write_data_top[5] write_data_top[4] write_data_top[3] write_data_top[2] write_data_top[1] write_data_top[0] -autobundled
netbloc @write_data_top 1 8 3 2880 1820 NJ 1820 3760
load netBundle @mux1_top 4 mux1_top[3] mux1_top[2] mux1_top[1] mux1_top[0] -autobundled
netbloc @mux1_top 1 13 1 5020 510n
load netBundle @mux2_top 4 mux2_top[3] mux2_top[2] mux2_top[1] mux2_top[0] -autobundled
netbloc @mux2_top 1 13 1 5040 810n
load netBundle @mux3_top 4 mux3_top[3] mux3_top[2] mux3_top[1] mux3_top[0] -autobundled
netbloc @mux3_top 1 13 1 5000 940n
load netBundle @writedata_top 32 writedata_top[31] writedata_top[30] writedata_top[29] writedata_top[28] writedata_top[27] writedata_top[26] writedata_top[25] writedata_top[24] writedata_top[23] writedata_top[22] writedata_top[21] writedata_top[20] writedata_top[19] writedata_top[18] writedata_top[17] writedata_top[16] writedata_top[15] writedata_top[14] writedata_top[13] writedata_top[12] writedata_top[11] writedata_top[10] writedata_top[9] writedata_top[8] writedata_top[7] writedata_top[6] writedata_top[5] writedata_top[4] writedata_top[3] writedata_top[2] writedata_top[1] writedata_top[0] -autobundled
netbloc @writedata_top 1 13 1 5160 1020n
load netBundle @op11_top 4 op11_top[3] op11_top[2] op11_top[1] op11_top[0] -autobundled
netbloc @op11_top 1 1 16 310 250 NJ 250 NJ 250 NJ 250 NJ 250 NJ 250 NJ 250 NJ 250 NJ 250 NJ 250 NJ 250 NJ 250 NJ 250 NJ 250 5810J 490 6730
load netBundle @B1_top 4 B1_top[3] B1_top[2] B1_top[1] B1_top[0] -autobundled
netbloc @B1_top 1 16 1 6790 110n
load netBundle @addrout2_top 32 addrout2_top[31] addrout2_top[30] addrout2_top[29] addrout2_top[28] addrout2_top[27] addrout2_top[26] addrout2_top[25] addrout2_top[24] addrout2_top[23] addrout2_top[22] addrout2_top[21] addrout2_top[20] addrout2_top[19] addrout2_top[18] addrout2_top[17] addrout2_top[16] addrout2_top[15] addrout2_top[14] addrout2_top[13] addrout2_top[12] addrout2_top[11] addrout2_top[10] addrout2_top[9] addrout2_top[8] addrout2_top[7] addrout2_top[6] addrout2_top[5] addrout2_top[4] addrout2_top[3] addrout2_top[2] addrout2_top[1] addrout2_top[0] -autobundled
netbloc @addrout2_top 1 8 9 2900 1080 NJ 1080 NJ 1080 NJ 1080 NJ 1080 NJ 1080 NJ 1080 NJ 1080 6710
load netBundle @branchtarget1_top 32 branchtarget1_top[31] branchtarget1_top[30] branchtarget1_top[29] branchtarget1_top[28] branchtarget1_top[27] branchtarget1_top[26] branchtarget1_top[25] branchtarget1_top[24] branchtarget1_top[23] branchtarget1_top[22] branchtarget1_top[21] branchtarget1_top[20] branchtarget1_top[19] branchtarget1_top[18] branchtarget1_top[17] branchtarget1_top[16] branchtarget1_top[15] branchtarget1_top[14] branchtarget1_top[13] branchtarget1_top[12] branchtarget1_top[11] branchtarget1_top[10] branchtarget1_top[9] branchtarget1_top[8] branchtarget1_top[7] branchtarget1_top[6] branchtarget1_top[5] branchtarget1_top[4] branchtarget1_top[3] branchtarget1_top[2] branchtarget1_top[1] branchtarget1_top[0] -autobundled
netbloc @branchtarget1_top 1 1 16 370 10 NJ 10 NJ 10 NJ 10 NJ 10 NJ 10 NJ 10 NJ 10 NJ 10 NJ 10 NJ 10 NJ 10 NJ 10 NJ 10 NJ 10 6550
load netBundle @op21_top 4 op21_top[3] op21_top[2] op21_top[1] op21_top[0] -autobundled
netbloc @op21_top 1 8 9 2840 1480 3320J 1380 3780J 1200 NJ 1200 NJ 1200 NJ 1200 NJ 1200 NJ 1200 6650
load netBundle @opcode2_top 5 opcode2_top[4] opcode2_top[3] opcode2_top[2] opcode2_top[1] opcode2_top[0] -autobundled
netbloc @opcode2_top 1 16 1 6750 310n
load netBundle @ra2_top 4 ra2_top[3] ra2_top[2] ra2_top[1] ra2_top[0] -autobundled
netbloc @ra2_top 1 8 9 2880 1500 3340J 1400 3820J 1220 NJ 1220 NJ 1220 NJ 1220 NJ 1220 NJ 1220 6610
load netBundle @rd2_top 4 rd2_top[3] rd2_top[2] rd2_top[1] rd2_top[0] -autobundled
netbloc @rd2_top 1 8 9 2900 1520 3380J 1420 3840J 1240 NJ 1240 NJ 1240 NJ 1240 NJ 1240 NJ 1240 6530
load netBundle @addrout_top 32 addrout_top[31] addrout_top[30] addrout_top[29] addrout_top[28] addrout_top[27] addrout_top[26] addrout_top[25] addrout_top[24] addrout_top[23] addrout_top[22] addrout_top[21] addrout_top[20] addrout_top[19] addrout_top[18] addrout_top[17] addrout_top[16] addrout_top[15] addrout_top[14] addrout_top[13] addrout_top[12] addrout_top[11] addrout_top[10] addrout_top[9] addrout_top[8] addrout_top[7] addrout_top[6] addrout_top[5] addrout_top[4] addrout_top[3] addrout_top[2] addrout_top[1] addrout_top[0] -autobundled
netbloc @addrout_top 1 4 3 1290 430 NJ 430 1900
load netBundle @pcplus4_top 32 pcplus4_top[31] pcplus4_top[30] pcplus4_top[29] pcplus4_top[28] pcplus4_top[27] pcplus4_top[26] pcplus4_top[25] pcplus4_top[24] pcplus4_top[23] pcplus4_top[22] pcplus4_top[21] pcplus4_top[20] pcplus4_top[19] pcplus4_top[18] pcplus4_top[17] pcplus4_top[16] pcplus4_top[15] pcplus4_top[14] pcplus4_top[13] pcplus4_top[12] pcplus4_top[11] pcplus4_top[10] pcplus4_top[9] pcplus4_top[8] pcplus4_top[7] pcplus4_top[6] pcplus4_top[5] pcplus4_top[4] pcplus4_top[3] pcplus4_top[2] pcplus4_top[1] pcplus4_top[0] -autobundled
netbloc @pcplus4_top 1 2 3 690 510 NJ 510 1230
load netBundle @pcplus45_top 32 pcplus45_top[31] pcplus45_top[30] pcplus45_top[29] pcplus45_top[28] pcplus45_top[27] pcplus45_top[26] pcplus45_top[25] pcplus45_top[24] pcplus45_top[23] pcplus45_top[22] pcplus45_top[21] pcplus45_top[20] pcplus45_top[19] pcplus45_top[18] pcplus45_top[17] pcplus45_top[16] pcplus45_top[15] pcplus45_top[14] pcplus45_top[13] pcplus45_top[12] pcplus45_top[11] pcplus45_top[10] pcplus45_top[9] pcplus45_top[8] pcplus45_top[7] pcplus45_top[6] pcplus45_top[5] pcplus45_top[4] pcplus45_top[3] pcplus45_top[2] pcplus45_top[1] pcplus45_top[0] -autobundled
netbloc @pcplus45_top 1 12 1 4670 1340n
load netBundle @addrin_top 32 addrin_top[31] addrin_top[30] addrin_top[29] addrin_top[28] addrin_top[27] addrin_top[26] addrin_top[25] addrin_top[24] addrin_top[23] addrin_top[22] addrin_top[21] addrin_top[20] addrin_top[19] addrin_top[18] addrin_top[17] addrin_top[16] addrin_top[15] addrin_top[14] addrin_top[13] addrin_top[12] addrin_top[11] addrin_top[10] addrin_top[9] addrin_top[8] addrin_top[7] addrin_top[6] addrin_top[5] addrin_top[4] addrin_top[3] addrin_top[2] addrin_top[1] addrin_top[0] -autobundled
netbloc @addrin_top 1 3 1 960 410n
load netBundle @op1_top 32 op1_top[31] op1_top[30] op1_top[29] op1_top[28] op1_top[27] op1_top[26] op1_top[25] op1_top[24] op1_top[23] op1_top[22] op1_top[21] op1_top[20] op1_top[19] op1_top[18] op1_top[17] op1_top[16] op1_top[15] op1_top[14] op1_top[13] op1_top[12] op1_top[11] op1_top[10] op1_top[9] op1_top[8] op1_top[7] op1_top[6] op1_top[5] op1_top[4] op1_top[3] op1_top[2] op1_top[1] op1_top[0] -autobundled
netbloc @op1_top 1 14 2 5580 510 5790J
load netBundle @op2_top 32 op2_top[31] op2_top[30] op2_top[29] op2_top[28] op2_top[27] op2_top[26] op2_top[25] op2_top[24] op2_top[23] op2_top[22] op2_top[21] op2_top[20] op2_top[19] op2_top[18] op2_top[17] op2_top[16] op2_top[15] op2_top[14] op2_top[13] op2_top[12] op2_top[11] op2_top[10] op2_top[9] op2_top[8] op2_top[7] op2_top[6] op2_top[5] op2_top[4] op2_top[3] op2_top[2] op2_top[1] op2_top[0] -autobundled
netbloc @op2_top 1 14 2 5540 190 5870J
levelinfo -pg 1 0 180 460 770 1060 1400 1740 2210 2650 3100 3580 4050 4500 4870 5280 5660 6300 6940 7160
pagesize -pg 1 -db -bbox -sgen -80 0 7160 1830
show
fullfit
#
# initialize ictrl to current module riscv work:riscv:NOFILE
ictrl init topinfo |
