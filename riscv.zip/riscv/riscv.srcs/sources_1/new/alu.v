`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 13.07.2026 20:42:56
// Design Name: 
// Module Name: alu
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module alu(A,B,aluSignals,result,E,sign,GT,overflow);
    input [31:0] A,B;
    input [4:0] aluSignals;
    output reg [31:0] result;
    output reg E,sign,GT,overflow;
    reg [32:0] temp;
    always @(*)
    begin
        GT=1'b0;
        overflow=1'b0;
        E=1'b1;
        sign=1'b0;
        result=32'b00;
        case(aluSignals)
            5'b00000,5'b01110,5'b01111:
            begin
                temp=A+B;
                result=temp[31:0];
                GT=temp[32];
                if((A[31]==B[31])&&(result[31]!=A[31]))
                    overflow=1;
                end
            5'b00001:
            begin
                temp=A-B;
                result = temp[31:0];
                GT= temp[32];
                if((A[31]!=B[31])&&(result[31]!=A[31]))
                    overflow=1;
            end
            5'b00010:
                result=A*B;
            5'b00011:
                if(B!=0)
                    result=A/B;
                else
                    result=32'b0;
            5'b00100:
                if(B!=0)
                    result=A%B;
                else
                    result=32'b0;
            5'b00101:
            begin
                temp={1'b0,A}-{1'b0,B};
                result=temp[31:0];
                GT=~temp[32];
                overflow=(A[31]^B[31])&(A[31]^result[31]);
            end
            5'b00110:
                result=A&B;
            5'b00111:
                result=A|B;
            5'b01000:
                result=~A;
            5'b01001:
                result=B;
            5'b01010:
                result=A<<B[4:0];
            5'b01011:
                result=A>>B[4:0];
            5'b1000:
                result=$signed(A)>>>B[4:0];
            default:
                result=32'b0;
        endcase
        E=(result==32'b0);
        sign=result[31];
end
endmodule
