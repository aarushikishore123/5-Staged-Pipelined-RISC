`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08.07.2026 19:31:44
// Design Name: 
// Module Name: pc
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pc(clk,reset,addrin,pcplus4,addrout);
    input clk,reset;
    input [31:0] addrin;
    output reg [31:0] addrout;
    output [31:0] pcplus4;
    always @(posedge clk or posedge reset)
    begin
        if(reset)
            addrout<=32'b00;
        else
            addrout<=addrin;    
    end
    assign pcplus4=addrout+4;
endmodule
