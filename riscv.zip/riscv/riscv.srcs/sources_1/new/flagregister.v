`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 13.07.2026 20:43:55
// Design Name: 
// Module Name: flagregister
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module flagregister(clk,reset,E_in,sign_in,GT_in,overflow_in,E,sign,GT,overflow);
    input clk,reset,E_in,sign_in,GT_in,overflow_in;
    output reg E,sign,GT,overflow;
    always @(posedge clk or posedge reset)
    begin
        if(reset)
        begin
            E<=1'b1;
            sign<=1'b0;
            GT<=1'b0;
            overflow<=1'b0;
        end
        else
        begin
            E<=E_in;
            sign<=sign_in;
            GT<=GT_in;
            overflow<=overflow_in;
        end
    end
endmodule
