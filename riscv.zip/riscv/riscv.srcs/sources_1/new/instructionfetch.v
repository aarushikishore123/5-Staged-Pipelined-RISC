`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11.07.2026 00:43:00
// Design Name: 
// Module Name: instructionfetch
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module instructionfetch(clk,reset,isImmediate,instruction,rd,rs2,ra,rs1,opcode);
    input clk,reset;
    output isImmediate;
    input [31:0] instruction;
    output reg [3:0] rd,rs2,ra,rs1;
    output reg [4:0] opcode;
    assign isImmediate=instruction[26];
    always @(posedge clk or posedge reset)
        if (reset)
        begin
            opcode<=5'b0;
            rd<=4'b0;
            rs1<=4'b0;
            rs2<=4'b0;
            ra<=4'b1111;
        end
        else
        begin
            opcode<=instruction[31:27];
            rd<=instruction[25:22];
            rs2<=instruction[17:14];
            ra<=4'b1111;
            rs1<=instruction[21:18];
        end
endmodule
