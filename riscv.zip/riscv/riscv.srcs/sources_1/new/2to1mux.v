`timescale 1ns / 1ps
module 2to1mux(
);
endmodule