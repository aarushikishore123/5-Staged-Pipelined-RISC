`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 13.07.2026 00:27:09
// Design Name: 
// Module Name: branchunit
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module branchunit(clk,reset,isBeq,isBgt,isUBranch,isBranchTaken,E,GT);
    input clk,reset,isBeq,isBgt,isUBranch,E,GT;
    output reg isBranchTaken;
    always @(posedge clk or posedge reset)
    begin
        if(reset)
            isBranchTaken=1'b0;
        else
            isBranchTaken=(isBeq&E)|isUBranch|(isBgt&GT);
    end
endmodule
