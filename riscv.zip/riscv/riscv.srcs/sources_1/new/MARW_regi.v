`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 15.07.2026 01:28:00
// Design Name: 
// Module Name: MARW_regi
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module MARW_regi(clk,reset,
    MAaddrout,
    MAldResult,
    MAresult,
    MAinstruction,MAra,MArd,RWra,RWrd,
    MAisWb,
    MAisCall,
    MAisLd,
    RWaddrout,
    RWldResult,
    RWresult,
    RWinstruction,
    RWisWb,
    RWisCall,
    RWisLd);
    input clk,reset;
    input [3:0] MAra,MArd;
    output reg [3:0] RWra,RWrd;
    input [31:0]
    MAaddrout,
    MAresult,
    MAinstruction,
    MAldResult;
    input 
    MAisWb,
    MAisCall,
    MAisLd;
    output reg [31:0] 
    RWaddrout,
    RWresult,
    RWinstruction,
    RWldResult;
    output reg RWisWb,
    RWisCall,
    RWisLd;
    always @(posedge clk or posedge reset)
    begin
        if(reset)
        begin
            RWaddrout       <=32'b00;
            RWresult        <=32'b00;
            RWinstruction   <=32'b00;
            RWldResult      <=32'b00;
            RWisWb          <=1'b0;
            RWisCall        <=1'b0;
            RWisLd          <=1'b0;
            RWra<=4'b00;
            RWrd<=4'b00;
        end                 
        else                
        begin               
            RWaddrout       <=MAaddrout;
            RWresult        <=MAresult;
            RWinstruction   <=MAinstruction;
            RWldResult      <=MAldResult;
            RWisWb          <=MAisWb;
            RWisCall        <=MAisCall;
            RWisLd          <=MAisLd;
            RWra<=MAra;
            RWrd<=MArd;
        end
    end
endmodule
