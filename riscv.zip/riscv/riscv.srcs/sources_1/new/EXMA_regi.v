`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 15.07.2026 01:09:56
// Design Name: 
// Module Name: EXMA_regi
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module EXMA_regi(clk,reset,
    MAaddrout,
    MAresult,
    MAop2,
    MAisWb,
    MAisSt,
    MAisCall,
    MAisLd,MAra,MArd,EXra,EXrd,
    EXaddrout,
    EXresult,
    EXop2,
    EXisWb,
    EXisSt,
    EXisCall,
    EXisLd);
    input clk,reset;
    input [31:0]
    EXaddrout,
    EXresult,
    EXop2;
    input 
    EXisWb,
    EXisSt,
    EXisCall,
    EXisLd;
    input [3:0] EXra,EXrd;
    output reg [3:0] MAra,MArd;
    output reg [31:0] 
    MAaddrout,
    MAresult,
    MAop2;
    output reg
    MAisWb,
    MAisSt,
    MAisCall,
    MAisLd;
    always @(posedge clk or posedge reset)
    begin
        if(reset)
        begin
            MAaddrout       <=32'b00;
            MAresult        <=32'b00;
            MAop2           <=32'b00;
            MAisWb          <=1'b0;
            MAisSt          <=1'b0;
            MAisCall        <=1'b0;
            MAisLd          <=1'b0;
            MAra<=4'b00;
            MArd<=4'b00;
        end
        else
        begin
            MAaddrout       <=EXaddrout;
            MAresult        <=EXresult;
            MAop2           <=EXop2;
            MAisWb          <=EXisWb;
            MAisSt          <=EXisSt;
            MAisCall        <=EXisCall;
            MAisLd          <=EXisLd;
            MAra<=EXra;
            MArd<=EXrd;
        end
    end
endmodule
