`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 14.07.2026 23:45:27
// Design Name: 
// Module Name: IFOF_regi
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module IFOF_regi(clk,reset,IFrd,IFrs2,IFra,IFrs1,IFaddrout,IFopcode,IFisImmediate,OFrd,OFrs2,OFra,OFrs1,OFisImmediate,OFopcode,IFinstruction,OFaddrout,OFinstruction);
    input clk,reset,IFisImmediate;
    input [31:0] IFaddrout,IFinstruction;
    input [4:0] IFopcode;
    input [3:0] IFrd,IFrs2,IFra,IFrs1;
    output reg [31:0] OFaddrout,OFinstruction;
    output reg OFisImmediate;
    output reg [4:0] OFopcode;
    output reg [3:0] OFrd,OFrs2,OFra,OFrs1;
    always @(posedge clk or posedge reset)
    begin
        if(reset)
        begin
            OFaddrout<=32'b00;
            OFinstruction<=32'b00;
            OFopcode<=5'b00;
            OFisImmediate<=1'b0;
            OFrd    <=4'b00;
            OFrs2   <=4'b00;
            OFra    <=4'b00;
            OFrs1   <=4'b00;
        end
        else
        begin
            OFaddrout<=IFaddrout;
            OFinstruction<=IFinstruction;
            OFopcode<=IFopcode;
            OFisImmediate<=IFisImmediate;
            OFrd    <=IFrd ;
            OFrs2   <=IFrs2;
            OFra    <=IFra ;
            OFrs1   <=IFrs1;
        end
    end
endmodule
