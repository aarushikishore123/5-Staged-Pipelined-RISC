`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12.07.2026 14:14:37
// Design Name: 
// Module Name: registerfile
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module registerfile(clk,reset,isWb,mux2,mux1,mux3,writedata,op1,op2);
    input clk,reset,isWb;
    input [3:0] mux2,mux1,mux3;
    input [31:0] writedata;
    output [31:0] op1,op2;
    integer k=0;
    reg [31:0] registers[31:0];
    always @(posedge clk or posedge reset)
    begin
        if(reset)
        begin
            for(k=0;k<32;k=k+1)
            begin
                registers[k]<=32'b00;
            end
        end
        else if(isWb)
        begin
            registers[mux3]<=writedata;
        end
    end
    assign op1=registers[mux2];
    assign op2=registers[mux1];
endmodule