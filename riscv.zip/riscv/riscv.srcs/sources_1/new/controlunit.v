`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08.07.2026 21:37:07
// Design Name: 
// Module Name: controlunit
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module controlunit(clk,reset,opcode,isRet,isWb,isSt,isBeq,isBgt,isUBranch,isCall,isLd);
    input clk,reset;
    input [4:0] opcode;
    output isRet,isSt,isBeq,isBgt,isCall,isLd,isUBranch,isWb;
    assign isRet=(opcode==5'b10100);
    assign isSt=(opcode==5'b01111);
    assign isBeq=(opcode==5'b10000);
    assign isBgt=(opcode==5'b10001);
    assign isUBranch=(opcode==5'b10010);
    assign isCall=(opcode==5'b10011);
    assign isLd=(opcode==5'b01110);
    assign isWb=(opcode<5'b01110)?1:0;
endmodule