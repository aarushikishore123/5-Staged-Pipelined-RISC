`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09.07.2026 15:43:23
// Design Name: 
// Module Name: riscv
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module riscv(clk,reset); 
    input clk, reset;
    wire [31:0] source1_top,result2_top,result1_top,branchtarget1_top,instruction1_top,addrout5_top,pcplus45_top,addrout1_top,addrout2_top,addrout3_top,source_top,memdataout_top,write_data_top,read_address_top,result_top,addrin_top,B_top,pcplus4_top,addrout_top,branchaddr_top,instruction_top,immx_top,branchtarget_top,writedata_top,op1_top,op2_top;
    wire isWb3_top,isCall3_top,isLd3_top,isWb2_top,isSt2_top,isCall2_top,isLd2_top,isRet1_top,isWb1_top,isSt1_top,isBeq1_top,isBgt1_top,isUBranch1_top,isCall1_top,isLd1_top,isImmediate1_top,MemWrite_top,MemRead_top,isRet_top,E_top,sign_top,GT_top,overflow_top,E_in_top,sign_in_top,GT_in_top,overflow_in_top,isBranchTaken_top,isImmediate_top,isWb_top,isSt_top,isBeq_top,isBgt_top,isUBranch_top,isCall_top,isLd_top;
    wire [3:0] op22_top,op11_top,B1_top,op21_top,rd4_top,ra4_top,rd3_top,ra3_top,rd2_top,ra2_top,rd1_top,rs21_top,ra1_top,rs11_top,rd_top,rs2_top,rs1_top,ra_top,mux1_top,mux2_top,mux3_top;
    wire [4:0] opcode_top,opcode1_top,opcode2_top;
    //PC
    pc PC(.clk(clk),.reset(reset),.addrin(addrin_top),.pcplus4(pcplus4_top),.addrout(addrout_top));
    //PCMUX
    addrmux PCMUX(.i0(pcplus4_top),.i1(branchaddr_top),.s0(isBranchTaken_top),.o(addrin_top));
    //INSTRUCTIONMEMORY
    instructionmemory INSTRUCTIONMEMORY(.clk(clk),.reset(reset),.addrout(addrout_top),.instruction(instruction_top));
    //INSTRUCTIONFETCH
    instructionfetch INSTRUCTIONFETCH(.clk(clk),.reset(reset),.isImmediate(isImmediate_top),.instruction(instruction_top),.rd(rd_top),.rs2(rs2_top),.ra(ra_top),.rs1(rs1_top),.opcode(opcode_top));
    //CONTROLUNIT
    controlunit CONTROLUNIT(.clk(clk),.reset(reset),.opcode(opcode1_top),.isRet(isRet_top),.isWb(isWb_top),.isSt(isSt_top),.isBeq(isBeq_top),.isBgt(isBgt_top),.isUBranch(isUBranch_top),.isCall(isCall_top),.isLd(isLd_top));
    //MUX1
    regmux MUX1(.i0(rs21_top),.i1(rd1_top),.s0(isSt_top),.o(mux1_top));
    //MUX2
    regmux MUX2(.i0(rs11_top),.i1(ra1_top),.s0(isRet_top),.o(mux2_top));
    //MUX3
    regmux MUX3(.i0(rd_top),.i1(ra_top),.s0(isCall_top),.o(mux3_top));
    //BRMUX
    addrmux BRMUX(.i0(branchtarget1_top),.i1(op11_top),.s0(isRet1_top),.o(branchaddr_top));
    //IMMUX
    addrmux IMMUX(.i0(op2_top),.i1(immx_top),.s0(isImmediate1_top),.o(B_top));
    //REGISTERFILE
    registerfile REGISTERFILE(.clk(clk),.reset(reset),.isWb(isWb3_top),.mux2(mux2_top),.mux1(mux1_top),.mux3(mux3_top),.writedata(writedata_top),.op1(op1_top),.op2(op2_top));
    //IMMEDIATEBRANCH
    immediatebranch IMMEDIATEBRANCH(.instruction(instruction1_top),.addrout(addrout1_top),.immx(immx_top),.branchtarget(branchtarget_top));
    //MUX4TO1
    mux4to1 MUX4TO1(.s0(isCall3_top),.s1(isLd3_top),.i0(result2_top),.i1(source1_top),.i2(pcplus45_top),.o(writedata_top));
    //BRANCHUNIT
    branchunit BRANCHUNIT(.clk(clk),.reset(reset),.isBeq(isBeq1_top),.isBgt(isBgt1_top),.isUBranch(isUBranch1_top),.isBranchTaken(isBranchTaken_top),.E(E_top),.GT(GT_top));
    //ALU
    alu ALU(.A(op11_top),.B(B1_top),.aluSignals(opcode2_top),.result(result_top),.E(E_in_top),.sign(sign_in_top),.GT(GT_in_top),.overflow(overflow_in_top));
    //FLAGREGISTER
    flagregister FLAGREGISTER(.clk(clk),.reset(reset),.E_in(E_in_top),.sign_in(sign_in_top),.GT_in(GT_in_top),.overflow_in(overflow_in_top),.E(E_top),.sign(sign_top),.GT(GT_top),.overflow(overflow_top));
    //DATAMEMORY
    datamemory DATAMEMORY(.clk(clk),.reset(reset),.MemWrite(MemWrite_top),.MemRead(MemRead_top),.read_address(read_address_top),.Write_data(write_data_top),.MemData_out(memdataout_top));
    //MEMORYUNIT
    memoryunit MEMORYUNIT(.clk(clk),.reset(reset),.isLd(isLd2_top),.isSt(isSt2_top),.result(result1_top),.op2(op22_top),.memData(memdataout_top),.mar(mar_top),.mdr(mdr_top),.MemRead(MemRead_top),.MemWrite(MemWrite_top),.address(read_address_top),.writeData(write_data_top),.ldResult(source_top));
    //IFOF_REGI
    IFOF_regi IFOF_REGI(.clk(clk),.reset(reset),.IFrd(rd_top),.IFrs2(rs2_top),.IFra(ra_top),.IFrs1(rs1_top),.OFrd(rd1_top),.OFrs2(rs21_top),.OFra(ra1_top),.OFrs1(rs11_top),.IFaddrout(addrout_top),.IFinstruction(instruction_top),.IFopcode(opcode_top),.IFisImmediate(isImmediate_top),.OFisImmediate(isImmediate1_top),.OFopcode(opcode1_top),.OFaddrout(addrout1_top),.OFinstruction(instruction1_top));
    //OPEX_REGI
    OFEX_regi OFEX_REGI(.clk(clk),.reset(reset),.EXrd(rd2_top),.EXra(ra2_top),.OFrd(rd1_top),.OFra(ra1_top),.OFaddrout(addrout1_top),.OFbranchtarget(branchtarget_top),.OFA(op1_top),.OFB(B_top),.OFop2(op2_top),.OFisRet(isRet_top),.OFisWb(isWb_top),.OFisSt(isSt_top),.OFisBeq(isBeq_top),.OFisBgt(isBgt_top),.OFisUBranch(isUBranch_top),.OFisCall(isCall_top),.OFisLd(isLd_top),
    .OFopcode(opcode1_top),.EXopcode(opcode2_top),.EXaddrout(addrout2_top),.EXbranchtarget(branchtarget1_top),.EXA(op11_top),.EXB(B1_top),.EXop2(op21_top),.EXisRet(isRet1_top),.EXisWb(isWb1_top),.EXisSt(isSt1_top),.EXisBeq(isBeq1_top),.EXisBgt(isBgt1_top),.EXisUBranch(isUBranch1_top),.EXisCall(isCall1_top),.EXisLd(isLd1_top));
    //EXMA_REGI
    EXMA_regi EXMA_REGI(.clk(clk),.reset(reset),.EXrd(rd2_top),.EXra(ra2_top),.MArd(rd3_top),.MAra(ra3_top),
    .MAaddrout(addrout3_top),
    .MAop2(op22_top),
    .MAisWb(isWb2_top),
    .MAisSt(isSt2_top),
    .MAisCall(isCall2_top),
    .MAisLd(isLd2_top),
    .MAresult(result1_top),
    .EXresult(result_top),
    .EXaddrout(addrout2_top),
    .EXop2(op21_top),
    .EXisWb(isWb1_top),
    .EXisSt(isSt1_top),
    .EXisCall(isCall1_top),
    .EXisLd(isLd_top));
    //MARW_REGI
    MARW_regi MARW_REGI(.clk(clk),.reset(reset),.RWrd(rd4_top),.RWra(rd4_top),.MArd(rd3_top),.MAra(rd3_top),
    .MAaddrout(addrout3_top),
    .MAldResult(source_top),
    .MAisWb(isWb2_top),
    .MAisCall(isCall2_top),
    .MAresult(result1_top),
    .RWresult(result2_top),
    .RWaddrout(addrout4_top),
    .RWldResult(source1_top),
    .RWisWb(isWb3_top),
    .RWisCall(isCall3_top),
    .RWisLd(isLd3_top),
    .MAisLd(isLd2_top));
    //PC5
    pc PC5(.clk(clk),.reset(reset),.addrin(addrout4_top),.pcplus4(pcplus45_top),.addrout(addrout5_top));
    //HAZARDUNIT
    hazardunit HAZARDUNIT(.reset(reset),.RegWriteM(),.RegWriteW(),.RD_M(),.RD_W(),.Rs1_E(),.Rs2_E(),.ForwardAE(),.ForwardBE());
endmodule