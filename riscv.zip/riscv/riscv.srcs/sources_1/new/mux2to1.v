`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08.07.2026 19:42:41
// Design Name: 
// Module Name: mux2to1
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module addrmux(i0,i1,s0,o);
    input [31:0] i0,i1;
    input s0;
    output [31:0] o;
    assign o=(s0==1'b0)?i0:i1;
endmodule

module regmux(i0,i1,s0,o);
    input [3:0] i0,i1;
    input s0;
    output [3:0] o;
    assign o=(s0==1'b0)?i0:i1;
endmodule
