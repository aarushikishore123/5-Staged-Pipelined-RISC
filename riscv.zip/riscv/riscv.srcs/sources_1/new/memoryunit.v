`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 13.07.2026 00:38:12
// Design Name: 
// Module Name: memoryunit
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module memoryunit(clk,reset,isLd,isSt,result,op2,memData,mar,mdr,MemRead,MemWrite,address,writeData,ldResult);
    input clk,reset,isLd,isSt;
    input [31:0] result,op2,memData;
    output reg [31:0] mar,mdr,address,writeData,ldResult;
    output reg MemRead,MemWrite;
always @(posedge clk or posedge reset)
begin
    if(reset)
    begin
        mar <= 32'b0;
        mdr <= 32'b0;
    end
    else
    begin
        if(isLd)
        begin
            mar <= result;
            mdr <= memData;
        end
        else if(isSt)
        begin
            mar <= result;
            mdr <= op2;
        end
    end
end
always @(*)
begin
    MemRead  = 0;
    MemWrite = 0;
    address = mar;
    writeData = mdr;
    ldResult = mdr;
    if(isLd)
        MemRead = 1;
    if(isSt)
        MemWrite = 1;
end
endmodule
