`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10.07.2026 15:31:35
// Design Name: 
// Module Name: instructionmemory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module instructionmemory(clk,reset,addrout,instruction);
    input clk,reset;
    input [31:0] addrout;
    output reg [31:0] instruction;
    integer k=0;
    reg [31:0] I_Mem[63:0];
    always @(posedge clk or posedge reset)
    begin
        if(reset)
        begin
            for(k=0;k<64;k=k+1)
            begin
                I_Mem[k]<=32'b00;
            end
            instruction<=32'b00;
        end
        else
            instruction<=I_Mem[addrout/4];
    end
endmodule
