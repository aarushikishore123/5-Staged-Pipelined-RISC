`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 09.07.2026 15:46:34
// Design Name: 
// Module Name: mux4to1
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module mux4to1(s0,s1,i0,i1,i2,o);
    input [31:0] i0,i1,i2;
    input s0,s1;
    output reg [31:0] o;
    always @(*)
    begin
        if(s0==1'b0&&s1==1'b0)
            o<=i0;
        else if(s0==1'b0&&s1==1'b1)
            o<=i1;
        else if(s0==1'b1&&s1==1'b0)
            o<=i2;
    end
endmodule
