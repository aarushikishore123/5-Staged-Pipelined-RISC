`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 12.07.2026 20:01:10
// Design Name: 
// Module Name: immediatebranch
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module immediatebranch(instruction,addrout,immx,branchtarget);
input [31:0] instruction,addrout;
output reg [31:0] immx,branchtarget;
always @(*)
    begin
        immx<={{14{instruction[17]}},instruction[17:0]};
        branchtarget<=({{5{instruction[26]}},instruction[26:0]})*4+addrout;
    end
endmodule
