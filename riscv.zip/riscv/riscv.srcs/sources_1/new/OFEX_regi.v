`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 15.07.2026 00:32:24
// Design Name: 
// Module Name: OFEX_regi
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module OFEX_regi(clk,reset,OFra,OFrd,EXra,EXrd,OFaddrout,OFbranchtarget,OFopcode,EXopcode,OFA,OFB,OFop2,OFisRet,OFisWb,OFisSt,OFisBeq,OFisBgt,OFisUBranch,OFisCall,OFisLd,EXaddrout,EXbranchtarget,EXA,EXB,EXop2,EXisRet,EXisWb,EXisSt,EXisBeq,EXisBgt,EXisUBranch,EXisCall,EXisLd);
    input clk,reset;
    input [31:0] OFaddrout,OFbranchtarget,OFA,OFB,OFop2;
    input OFisRet,OFisWb,OFisSt,OFisBeq,OFisBgt,OFisUBranch,OFisCall,OFisLd;
    input [4:0] OFopcode;
    input [3:0] OFra,OFrd;
    output reg [31:0] EXaddrout,EXbranchtarget,EXA,EXB,EXop2;
    output reg EXisRet,EXisWb,EXisSt,EXisBeq,EXisBgt,EXisUBranch,EXisCall,EXisLd;
    output reg [4:0] EXopcode;
    output reg [3:0] EXra,EXrd;
    always @(posedge clk or posedge reset)
    begin
        if(reset)
        begin
            EXaddrout       <=32'b00;
            EXbranchtarget  <=32'b00;
            EXA             <=32'b00;
            EXB             <=32'b00;
            EXop2           <=32'b00;
            EXisRet         <=1'b0;
            EXisWb          <=1'b0;
            EXisSt          <=1'b0;
            EXisBeq         <=1'b0;
            EXisBgt         <=1'b0;
            EXisUBranch     <=1'b0;
            EXisCall        <=1'b0;
            EXisLd          <=1'b0;
            EXopcode<=5'b00;
            EXra<=4'b00;
            EXrd<=4'b00;
        end
        else
        begin
            EXaddrout       <=OFaddrout;
            EXbranchtarget  <=OFbranchtarget;
            EXA             <=OFA;
            EXB             <=OFB;
            EXop2           <=OFop2;
            EXisRet         <=OFisRet;
            EXisWb          <=OFisWb;
            EXisSt          <=OFisSt;
            EXisBeq         <=OFisBeq;
            EXisBgt         <=OFisBgt;
            EXisUBranch     <=OFisUBranch;
            EXisCall        <=OFisCall;
            EXisLd          <=OFisLd;
            EXopcode<=OFopcode;
            EXra<=OFra;
            EXrd<=OFrd;
        end
    end
endmodule
