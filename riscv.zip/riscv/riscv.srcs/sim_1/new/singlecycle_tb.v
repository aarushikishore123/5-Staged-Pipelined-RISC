`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 14.07.2026 13:54:12
// Design Name: 
// Module Name: singlecycle_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module singlecycle_tb;
    reg clk,reset;
    riscv uut(.clk(clk),.reset(reset));
    initial
    begin
        clk=0;
        reset=1;
        #5;
        reset=0;
        #400;
    end
    always
        begin
        #5 clk=~clk;
    end
endmodule
